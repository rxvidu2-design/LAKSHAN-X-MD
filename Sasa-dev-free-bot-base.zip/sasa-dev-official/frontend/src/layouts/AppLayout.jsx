import { useState } from 'react'
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom'
import { Brand } from '../components/Brand.jsx'
import { Icon } from '../components/Icon.jsx'
import { useAuth } from '../context/AuthContext.jsx'
import { useSocket } from '../context/SocketContext.jsx'

const navigation = [
  { to: '/dashboard', label: 'Overview', icon: 'dashboard' },
  { to: '/connect', label: 'Connect', icon: 'connect' },
  { to: '/sessions', label: 'Sessions', icon: 'sessions' },
  { to: '/commands', label: 'Commands', icon: 'commands' },
  { to: '/status', label: 'System status', icon: 'status' },
  { to: '/admin', label: 'Administration', icon: 'shield', adminOnly: true },
  { to: '/logs', label: 'Activity logs', icon: 'logs' },
  { to: '/settings', label: 'Settings', icon: 'settings', adminOnly: true },
  { to: '/about', label: 'About', icon: 'info' }
]

export const AppLayout = () => {
  const [open, setOpen] = useState(false)
  const { user, logout } = useAuth()
  const { connected } = useSocket()
  const navigate = useNavigate()
  const location = useLocation()
  const title = navigation.find(item => location.pathname.startsWith(item.to))?.label || 'Control center'
  const signOut = async () => { await logout(); navigate('/') }
  return (
    <div className="app-shell">
      <button className={`sidebar-backdrop ${open ? 'is-visible' : ''}`} aria-label="Close navigation" onClick={() => setOpen(false)} />
      <aside className={`sidebar ${open ? 'is-open' : ''}`}>
        <div className="sidebar__head"><Brand /><button className="icon-button sidebar__close" onClick={() => setOpen(false)} aria-label="Close menu"><Icon name="close" /></button></div>
        <nav className="sidebar__nav" aria-label="Dashboard navigation">
          <span className="nav-label">Workspace</span>
          {navigation.filter(item => !item.adminOnly || user?.role === 'admin').map(item => (
            <NavLink key={item.to} to={item.to} onClick={() => setOpen(false)} className={({ isActive }) => `nav-item ${isActive ? 'is-active' : ''}`}>
              <Icon name={item.icon} size={19} /><span>{item.label}</span><Icon className="nav-item__arrow" name="chevron" size={15} />
            </NavLink>
          ))}
        </nav>
        <div className="sidebar__foot">
          <div className="profile-chip"><span className="profile-chip__avatar">{(user?.displayName || user?.username || 'A').slice(0, 1).toUpperCase()}</span><span><strong>{user?.displayName || user?.username}</strong><small>{user?.role}</small></span></div>
          <button className="icon-button" onClick={signOut} aria-label="Sign out"><Icon name="logout" size={19} /></button>
        </div>
      </aside>
      <div className="app-main">
        <header className="topbar">
          <button className="icon-button topbar__menu" onClick={() => setOpen(true)} aria-label="Open menu"><Icon name="menu" /></button>
          <div className="topbar__title"><span className="topbar__crumb">Sasa Dev Official</span><strong>{title}</strong></div>
          <div className={`live-indicator ${connected ? 'is-online' : ''}`}><span/><Icon name={connected ? 'wifi' : 'wifioff'} size={15}/>{connected ? 'Live updates' : 'Reconnecting'}</div>
        </header>
        <main className="page"><Outlet /></main>
      </div>
    </div>
  )
}
