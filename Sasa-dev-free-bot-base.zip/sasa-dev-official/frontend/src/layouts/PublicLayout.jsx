import { Link, NavLink, Outlet } from 'react-router-dom'
import { Brand } from '../components/Brand.jsx'
import { Icon } from '../components/Icon.jsx'
import { useAuth } from '../context/AuthContext.jsx'

export const PublicLayout = () => {
  const { user } = useAuth()
  return (
    <div className="public-shell">
      <header className="public-nav">
        <Link to="/" className="public-nav__brand"><Brand /></Link>
        <nav><NavLink to="/">Home</NavLink><NavLink to="/about">About</NavLink></nav>
        <Link className="button button--primary button--sm" to={user ? '/dashboard' : '/login'}><span>{user ? 'Open dashboard' : 'Administrator login'}</span><Icon name="arrow" size={16}/></Link>
      </header>
      <Outlet />
      <footer className="public-footer"><Brand /><p>Responsible WhatsApp Multi-Device automation by Sasa Dev.</p><a href="https://whatsapp.com/channel/0029Vb69K9665yDEFt3DRR0D" target="_blank" rel="noreferrer">Official channel <Icon name="external" size={14}/></a></footer>
    </div>
  )
}
