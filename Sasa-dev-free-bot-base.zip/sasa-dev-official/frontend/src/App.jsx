import { lazy, Suspense } from 'react'
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom'
import { ProtectedRoute } from './components/ProtectedRoute.jsx'
import { AppLayout } from './layouts/AppLayout.jsx'
import { PublicLayout } from './layouts/PublicLayout.jsx'

const LandingPage = lazy(() => import('./pages/LandingPage.jsx'))
const LoginPage = lazy(() => import('./pages/LoginPage.jsx'))
const AboutPage = lazy(() => import('./pages/AboutPage.jsx'))
const DashboardPage = lazy(() => import('./pages/DashboardPage.jsx'))
const ConnectPage = lazy(() => import('./pages/ConnectPage.jsx'))
const SessionsPage = lazy(() => import('./pages/SessionsPage.jsx'))
const CommandsPage = lazy(() => import('./pages/CommandsPage.jsx'))
const LogsPage = lazy(() => import('./pages/LogsPage.jsx'))
const StatusPage = lazy(() => import('./pages/StatusPage.jsx'))
const AdminPage = lazy(() => import('./pages/AdminPage.jsx'))
const SettingsPage = lazy(() => import('./pages/SettingsPage.jsx'))

const Loader = () => <div className="app-loader"><span className="loader-mark"/><p>Loading Sasa Dev Official</p></div>

export default function App() {
  return (
    <BrowserRouter>
      <Suspense fallback={<Loader />}>
        <Routes>
          <Route element={<PublicLayout />}><Route index element={<LandingPage />} /><Route path="about" element={<AboutPage />} /></Route>
          <Route path="login" element={<LoginPage />} />
          <Route element={<ProtectedRoute><AppLayout /></ProtectedRoute>}>
            <Route path="dashboard" element={<DashboardPage />} />
            <Route path="connect" element={<ConnectPage />} />
            <Route path="pair" element={<ConnectPage initialTab="pair" />} />
            <Route path="qr" element={<ConnectPage initialTab="qr" />} />
            <Route path="sessions" element={<SessionsPage />} />
            <Route path="commands" element={<CommandsPage />} />
            <Route path="logs" element={<LogsPage />} />
            <Route path="status" element={<StatusPage />} />
            <Route path="admin" element={<AdminPage />} />
            <Route path="settings" element={<SettingsPage />} />
          </Route>
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Suspense>
    </BrowserRouter>
  )
}
