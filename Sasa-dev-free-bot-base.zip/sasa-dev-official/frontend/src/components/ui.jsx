import { Icon } from './Icon.jsx'

export const Button = ({ children, icon, variant = 'primary', size = 'md', loading = false, className = '', ...props }) => (
  <button className={`button button--${variant} button--${size} ${className}`} disabled={loading || props.disabled} {...props}>
    {loading ? <span className="spinner" /> : icon ? <Icon name={icon} size={size === 'sm' ? 16 : 18} /> : null}
    <span>{loading ? 'Please wait' : children}</span>
  </button>
)

export const Card = ({ children, className = '', ...props }) => <section className={`card ${className}`} {...props}>{children}</section>
export const Badge = ({ children, tone = 'neutral', dot = false }) => <span className={`badge badge--${tone}`}>{dot && <i />}{children}</span>
export const EmptyState = ({ icon = 'layers', title, text, action }) => (
  <div className="empty-state">
    <span className="empty-state__icon"><Icon name={icon} size={28} /></span>
    <h3>{title}</h3><p>{text}</p>{action}
  </div>
)
export const PageHeader = ({ eyebrow, title, description, actions }) => (
  <header className="page-header">
    <div><span className="eyebrow">{eyebrow}</span><h1>{title}</h1><p>{description}</p></div>
    {actions && <div className="page-header__actions">{actions}</div>}
  </header>
)
export const Skeleton = ({ className = '' }) => <span className={`skeleton ${className}`} />
export const Field = ({ label, hint, error, children }) => (
  <label className={`field ${error ? 'field--error' : ''}`}><span className="field__label">{label}</span>{children}{(error || hint) && <small>{error || hint}</small>}</label>
)
export const StatusDot = ({ status }) => <span className={`status-dot status-dot--${String(status || 'unknown').replace('_', '-')}`} />
