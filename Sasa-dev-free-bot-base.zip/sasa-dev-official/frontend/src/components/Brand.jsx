export const Brand = ({ compact = false }) => (
  <div className={`brand ${compact ? 'brand--compact' : ''}`}>
    <span className="brand__mark"><img src="/logo.jpg" alt="" /></span>
    {!compact && <span className="brand__copy"><strong>Sasa Dev</strong><small>Official control center</small></span>}
  </div>
)
