import { Navigate, useLocation } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'

export const ProtectedRoute = ({ children }) => {
  const { user, loading } = useAuth()
  const location = useLocation()
  if (loading) return <div className="app-loader"><span className="loader-mark"/><p>Loading control center</p></div>
  if (!user) return <Navigate to="/login" state={{ from: location.pathname }} replace />
  return children
}
