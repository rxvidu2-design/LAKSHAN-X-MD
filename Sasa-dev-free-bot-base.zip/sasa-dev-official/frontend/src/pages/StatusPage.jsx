import { useEffect, useState } from 'react'
import { Icon } from '../components/Icon.jsx'
import { Badge, Button, Card, PageHeader, Skeleton } from '../components/ui.jsx'
import { useApi } from '../hooks/useApi.js'
import { get } from '../services/api.js'
import { formatDuration, sentenceCase } from '../utils/format.js'

const Service = ({ icon, name, description, status, detail }) => {
  const healthy = ['healthy','connected','available','loaded','active'].includes(status)
  const danger = ['unavailable','failed','disconnected'].includes(status)
  return <div className="status-service"><span className={`status-service__icon ${healthy ? 'is-healthy' : danger ? 'is-danger' : ''}`}><Icon name={icon}/></span><div><strong>{name}</strong><small>{description}</small></div><span><Badge tone={healthy ? 'success' : danger ? 'danger' : 'warning'} dot>{sentenceCase(status)}</Badge>{detail && <small>{detail}</small>}</span></div>
}

export default function StatusPage() {
  const health = useApi('/health', { initialData: null })
  const overview = useApi('/admin/overview', { initialData: null })
  const [apiStatus, setApiStatus] = useState(null)
  const [testing, setTesting] = useState(false)
  useEffect(() => { const timer = setInterval(() => health.execute().catch(()=>{}), 30000); return () => clearInterval(timer) }, [health.execute])
  const testApi = async () => { setTesting(true); try { setApiStatus((await get('/admin/api-status')).data) } catch (error) { setApiStatus({ status: 'unavailable', error: error.message }) } finally { setTesting(false) } }
  const data = health.data
  const config = overview.data?.configuration || data?.configuration || {}
  return (
    <>
      <PageHeader eyebrow="Infrastructure visibility" title="System status" description="Live service readiness, database connectivity, required configuration, and external API diagnostics." actions={<Button variant="secondary" icon="refresh" loading={health.loading} onClick={() => { health.execute().catch(()=>{}); overview.execute().catch(()=>{}) }}>Refresh status</Button>} />
      <Card className={`health-banner ${data?.status === 'healthy' ? 'is-healthy' : 'is-degraded'}`}><span className="health-banner__mark"><Icon name={data?.status === 'healthy' ? 'check' : 'alert'} size={28}/></span><div><span className="eyebrow">Overall readiness</span><h2>{data?.status === 'healthy' ? 'All core systems operational' : 'Server online in degraded mode'}</h2><p>{data?.status === 'healthy' ? 'The API and MongoDB persistence layer are available.' : health.error?.message || 'Review database and secret configuration before connecting a session.'}</p></div><div><strong>{data ? formatDuration(data.uptime) : '—'}</strong><small>Process uptime</small></div></Card>
      <div className="status-layout">
        <Card className="status-services"><div className="card-heading"><div><span className="eyebrow">Core services</span><h2>Runtime components</h2></div><span className="updated-at">Updates every 30 seconds</span></div>{health.loading && !data ? <div className="status-skeleton"><Skeleton/><Skeleton/><Skeleton/><Skeleton/></div> : <div className="service-status-list"><Service icon="server" name="Express API" description="REST routes and static dashboard" status="healthy" detail={`v${data?.version || '1.0.0'}`}/><Service icon="database" name="MongoDB" description="Application data and encrypted auth keys" status={data?.database?.status || 'unknown'} detail={`ready state ${data?.database?.readyState ?? '—'}`}/><Service icon="activity" name="Socket.IO" description="Realtime connection telemetry" status="active" detail="WebSocket and polling"/><Service icon="terminal" name="Command registry" description="Validated JavaScript command modules" status="loaded" detail="200 commands"/><Service icon="globe" name="Sasa Dev API" description="Primary external command adapter" status={apiStatus?.status || (config.sasaApi ? 'configured' : 'unconfigured')} detail={apiStatus?.responseTime ? `${apiStatus.responseTime} ms` : apiStatus?.error}/></div>}<div className="api-test"><div><Icon name="activity"/><span><strong>Run an external API check</strong><small>This makes one authenticated status request and may consume provider quota.</small></span></div><Button size="sm" variant="secondary" loading={testing} onClick={testApi}>Test Sasa API</Button></div></Card>
        <Card className="configuration-card"><div className="card-heading"><div><span className="eyebrow">Deployment check</span><h2>Required configuration</h2></div></div><div className="config-list">{Object.entries({ database: 'MongoDB connection', sessionEncryption: 'Session encryption', authentication: 'JWT authentication', administrator: 'Administrator account', sasaApi: 'Sasa Dev API key' }).map(([key, label]) => <div key={key}><span className={config[key] ? 'is-ready' : ''}><Icon name={config[key] ? 'check' : 'close'}/></span><p><strong>{label}</strong><small>{config[key] ? 'Configured on server' : 'Missing or placeholder value'}</small></p><Badge tone={config[key] ? 'success' : 'warning'}>{config[key] ? 'Ready' : 'Required'}</Badge></div>)}</div><div className="configuration-note"><Icon name="lock"/><p>Secret values are never returned to this dashboard. Only boolean readiness checks are exposed.</p></div></Card>
        <Card className="deployment-card"><span className="eyebrow">Deployment profile</span><h2>Production runtime</h2><div className="deployment-grid"><div><Icon name="server"/><span><small>Node runtime</small><strong>20 or newer</strong></span></div><div><Icon name="layers"/><span><small>Architecture</small><strong>ES modules</strong></span></div><div><Icon name="database"/><span><small>Persistence</small><strong>MongoDB</strong></span></div><div><Icon name="shield"/><span><small>Auth cipher</small><strong>AES-256-GCM</strong></span></div></div></Card>
      </div>
    </>
  )
}
