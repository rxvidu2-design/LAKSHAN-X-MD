import { useEffect, useMemo, useState } from 'react'
import { Icon } from '../components/Icon.jsx'
import { Badge, Button, Card, Field, PageHeader, StatusDot } from '../components/ui.jsx'
import { useSocket } from '../context/SocketContext.jsx'
import { useToast } from '../context/ToastContext.jsx'
import { get, post } from '../services/api.js'
import { sentenceCase } from '../utils/format.js'

const countries = [
  { code: '94', label: 'Sri Lanka (+94)' }, { code: '91', label: 'India (+91)' }, { code: '44', label: 'United Kingdom (+44)' },
  { code: '1', label: 'United States (+1)' }, { code: '61', label: 'Australia (+61)' }, { code: '971', label: 'United Arab Emirates (+971)' }, { code: '65', label: 'Singapore (+65)' }
]
const pendingStates = new Set(['initializing', 'waiting_qr', 'waiting_pair', 'connecting', 'reconnecting'])

export default function ConnectPage({ initialTab = 'qr' }) {
  const [tab, setTab] = useState(initialTab)
  const [label, setLabel] = useState('Primary bot')
  const [country, setCountry] = useState('94')
  const [phone, setPhone] = useState('')
  const [session, setSession] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const { sessionUpdates, subscribe, unsubscribe } = useSocket()
  const { notify } = useToast()
  const live = session ? { ...session, ...(sessionUpdates[session.sessionId] || {}) } : null
  const pairCode = live?.pairCode ? String(live.pairCode).replace(/\s/g, '').match(/.{1,4}/g)?.join(' ') : null

  useEffect(() => {
    if (!session?.sessionId) return
    subscribe(session.sessionId)
    const timer = setInterval(async () => {
      try {
        const response = await get(`/session/${session.sessionId}`)
        setSession(current => ({ ...current, ...response.data }))
        if (!pendingStates.has(response.data.status)) clearInterval(timer)
      } catch {}
    }, 5000)
    return () => { unsubscribe(session.sessionId); clearInterval(timer) }
  }, [session?.sessionId, subscribe, unsubscribe])

  useEffect(() => { setTab(initialTab) }, [initialTab])

  const startQr = async () => {
    setLoading(true); setError(''); setSession(null)
    try {
      const response = await post('/session/qr', { label: label.trim() || 'QR session' })
      setSession(response.data)
      notify('QR session created. Waiting for WhatsApp.', 'info')
    } catch (requestError) { setError(requestError.message) }
    finally { setLoading(false) }
  }

  const startPair = async event => {
    event.preventDefault(); setLoading(true); setError(''); setSession(null)
    const local = phone.replace(/\D/g, '').replace(/^0+/, '')
    if (local.length < 7) { setError('Enter a valid phone number without the leading zero.'); setLoading(false); return }
    try {
      const response = await post('/session/pair', { label: label.trim() || 'Pair session', phoneNumber: `${country}${local}` })
      setSession(response.data)
      notify('Pair code generated securely.', 'success')
    } catch (requestError) { setError(requestError.message) }
    finally { setLoading(false) }
  }

  const refreshQr = async () => {
    if (!session) return
    setLoading(true); setError('')
    try { const response = await post(`/session/${session.sessionId}/refresh-qr`); setSession(response.data); notify('QR refresh requested.', 'info') }
    catch (requestError) { setError(requestError.message) }
    finally { setLoading(false) }
  }

  const copyCode = async () => { if (pairCode) { await navigator.clipboard.writeText(pairCode.replace(/\s/g, '')); notify('Pair code copied.', 'success') } }
  const reset = () => { setSession(null); setError('') }
  const statusTone = live?.status === 'connected' ? 'success' : live?.status === 'failed' || live?.status === 'logged_out' ? 'danger' : 'warning'

  return (
    <>
      <PageHeader eyebrow="WhatsApp authentication" title="Connect a new session" description="Choose QR scanning or an eight-digit pair code. Both methods create a real encrypted, persistent WhatsApp session." />
      <div className="connect-layout">
        <Card className="connect-card">
          <div className="connect-tabs" role="tablist"><button className={tab === 'qr' ? 'is-active' : ''} onClick={() => { setTab('qr'); reset() }}><Icon name="qr"/>QR code</button><button className={tab === 'pair' ? 'is-active' : ''} onClick={() => { setTab('pair'); reset() }}><Icon name="phone"/>Pair code</button></div>
          {error && <div className="form-alert"><Icon name="alert"/><span>{error}</span></div>}
          {tab === 'qr' ? (
            <div className="connect-method">
              {!live ? <div className="connect-intro"><span className="connect-intro__icon"><Icon name="qr" size={34}/></span><h2>Scan with WhatsApp</h2><p>Create a one-time QR code, then scan it from WhatsApp under Linked Devices. Credentials are saved only after WhatsApp confirms the link.</p><Field label="Session label" hint="A private label used only in this dashboard."><div className="input-wrap"><Icon name="sessions"/><input value={label} onChange={event => setLabel(event.target.value)} maxLength={80} placeholder="Primary bot"/></div></Field><Button loading={loading} icon="qr" onClick={startQr} className="button--full">Generate live QR code</Button></div> : <div className="credential-stage"><div className="credential-stage__head"><div><StatusDot status={live.status}/><span><strong>{live.label}</strong><small>{live.sessionId}</small></span></div><Badge tone={statusTone}>{sentenceCase(live.status)}</Badge></div>{live.status === 'connected' ? <ConnectionSuccess session={live} reset={reset}/> : <><div className="qr-frame">{live.qr ? <img src={live.qr} alt="Live WhatsApp linking QR code"/> : <div className="qr-wait"><span className="spinner spinner--large"/><strong>Waiting for WhatsApp QR</strong><small>The backend is negotiating a secure connection.</small></div>}<span className="qr-corner qr-corner--one"/><span className="qr-corner qr-corner--two"/><span className="qr-corner qr-corner--three"/><span className="qr-corner qr-corner--four"/></div><div className="credential-actions"><Button variant="secondary" icon="refresh" loading={loading} onClick={refreshQr}>Refresh QR</Button><Button variant="ghost" onClick={reset}>Start over</Button></div><small className="security-note"><Icon name="shield"/>The QR payload is held only in server memory and expires automatically.</small></>}</div>}
            </div>
          ) : (
            <div className="connect-method">
              {!live ? <form className="connect-intro" onSubmit={startPair}><span className="connect-intro__icon"><Icon name="phone" size={34}/></span><h2>Link with phone number</h2><p>Enter the WhatsApp number with its country code. The generated code must be entered in WhatsApp under Link with phone number instead.</p><Field label="Session label"><div className="input-wrap"><Icon name="sessions"/><input value={label} onChange={event => setLabel(event.target.value)} maxLength={80} placeholder="Primary bot"/></div></Field><div className="phone-grid"><Field label="Country code"><select value={country} onChange={event => setCountry(event.target.value)}>{countries.map(item => <option key={item.code} value={item.code}>{item.label}</option>)}</select></Field><Field label="Phone number" hint="Do not include the leading zero."><div className="input-wrap"><span className="dial-code">+{country}</span><input inputMode="numeric" value={phone} onChange={event => setPhone(event.target.value.replace(/\D/g, '').slice(0, 15))} placeholder="781234567" required/></div></Field></div><Button loading={loading} icon="key" className="button--full">Generate secure pair code</Button></form> : <div className="credential-stage"><div className="credential-stage__head"><div><StatusDot status={live.status}/><span><strong>{live.label}</strong><small>{live.ownerNumber}</small></span></div><Badge tone={statusTone}>{sentenceCase(live.status)}</Badge></div>{live.status === 'connected' ? <ConnectionSuccess session={live} reset={reset}/> : <><div className="pair-display"><small>YOUR PAIR CODE</small>{pairCode ? <button onClick={copyCode} aria-label="Copy pair code"><strong>{pairCode}</strong><span><Icon name="copy"/>Copy code</span></button> : <div className="pair-wait"><span className="spinner spinner--large"/><strong>Generating secure code</strong></div>}<p>WhatsApp → Linked devices → Link a device → Link with phone number instead</p></div><div className="credential-actions"><Button variant="secondary" icon="copy" onClick={copyCode} disabled={!pairCode}>Copy code</Button><Button variant="ghost" onClick={reset}>Start over</Button></div><small className="security-note"><Icon name="shield"/>Pair codes expire and are never persisted to MongoDB.</small></>}</div>}
            </div>
          )}
        </Card>
        <aside className="connect-guide"><span className="eyebrow">Connection checklist</span><h2>Link safely in four steps.</h2><ol><li className={live ? 'is-complete' : 'is-active'}><span>1</span><div><strong>Create session</strong><p>The API initializes an encrypted MongoDB auth state.</p></div></li><li className={live && pendingStates.has(live.status) ? 'is-active' : live?.status === 'connected' ? 'is-complete' : ''}><span>2</span><div><strong>Authenticate</strong><p>Scan the QR or enter the pair code inside WhatsApp.</p></div></li><li className={live?.status === 'connecting' || live?.status === 'reconnecting' ? 'is-active' : live?.status === 'connected' ? 'is-complete' : ''}><span>3</span><div><strong>Verify connection</strong><p>Baileys negotiates Signal credentials and reconnects.</p></div></li><li className={live?.status === 'connected' ? 'is-complete' : ''}><span>4</span><div><strong>Session active</strong><p>The bot loads commands and survives process restarts.</p></div></li></ol><div className="guide-notice"><Icon name="info"/><p>Use a dedicated number where possible. Never share QR or pair credentials with another person.</p></div></aside>
      </div>
    </>
  )
}

const ConnectionSuccess = ({ session, reset }) => <div className="connection-success"><span><Icon name="check" size={36}/></span><h2>WhatsApp connected</h2><p>The encrypted session is active and will be restored after a server restart.</p><div><small>Connected number</small><strong>{session.connectedNumber || session.ownerNumber}</strong></div><Button variant="secondary" onClick={reset}>Connect another session</Button></div>
