import { useMemo, useState } from 'react'
import { Icon } from '../components/Icon.jsx'
import { Badge, Button, Card, EmptyState, PageHeader, Skeleton } from '../components/ui.jsx'
import { useApi } from '../hooks/useApi.js'
import { formatDate, sentenceCase } from '../utils/format.js'

const levels = ['all', 'info', 'warn', 'error', 'audit']
const tone = level => level === 'error' ? 'danger' : level === 'warn' ? 'warning' : level === 'audit' ? 'violet' : 'success'

export default function LogsPage() {
  const [page, setPage] = useState(1)
  const [level, setLevel] = useState('all')
  const [command, setCommand] = useState('')
  const path = useMemo(() => `/logs?page=${page}&limit=30${level !== 'all' ? `&level=${level}` : ''}${command ? `&command=${encodeURIComponent(command.replace(/^\./, ''))}` : ''}`, [page, level, command])
  const logs = useApi(path, { initialData: [] })
  const exportCsv = () => {
    const rows = [['Timestamp','Level','Session','User','Group','Command','Status','Response Time','Error'], ...(logs.data || []).map(log => [log.timestamp,log.level,log.sessionId,log.user,log.group,log.command,log.status,log.responseTime,log.error])]
    const csv = rows.map(row => row.map(value => `"${String(value ?? '').replaceAll('"','""')}"`).join(',')).join('\n')
    const link = document.createElement('a'); link.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); link.download = `sasa-dev-logs-page-${page}.csv`; link.click(); URL.revokeObjectURL(link.href)
  }
  return (
    <>
      <PageHeader eyebrow="Auditing and diagnostics" title="Activity logs" description="Review command outcomes, response times, session events, and safely normalized errors retained by MongoDB." actions={<Button variant="secondary" icon="external" onClick={exportCsv} disabled={!logs.data?.length}>Export current page</Button>} />
      <Card className="table-card log-table-card">
        <div className="table-toolbar table-toolbar--wrap"><div className="search-input"><Icon name="search"/><input value={command} onChange={event => { setCommand(event.target.value); setPage(1) }} placeholder="Filter exact command name"/></div><div className="level-filter">{levels.map(item => <button className={level === item ? 'is-active' : ''} key={item} onClick={() => { setLevel(item); setPage(1) }}>{sentenceCase(item)}</button>)}</div><Button size="sm" variant="secondary" icon="refresh" loading={logs.loading} onClick={() => logs.execute().catch(()=>{})}>Refresh</Button></div>
        {logs.loading && !logs.data?.length ? <div className="table-skeleton">{[1,2,3,4,5].map(item => <Skeleton key={item}/>)}</div> : logs.data?.length ? <><div className="responsive-table"><table><thead><tr><th>Event</th><th>Session and sender</th><th>Result</th><th>Latency</th><th>Timestamp</th></tr></thead><tbody>{logs.data.map(log => <tr key={log._id}><td><div className="log-event"><span className={`log-event__icon log-event__icon--${log.level}`}><Icon name={log.level === 'error' ? 'alert' : log.command ? 'terminal' : 'activity'}/></span><span><strong>{log.command ? `.${log.command}` : log.message || 'System event'}</strong><small>{sentenceCase(log.level)}</small></span></div></td><td><div className="stacked-cell"><strong>{log.sessionId?.slice(0, 8) || 'System'}</strong><small>{log.user || log.group || 'Server runtime'}</small></div></td><td><div className="stacked-cell"><Badge tone={tone(log.level)}>{sentenceCase(log.status || log.level)}</Badge>{log.error && <small className="error-text" title={log.error}>{log.error}</small>}</div></td><td><span className="latency">{log.responseTime !== undefined && log.responseTime !== null ? `${log.responseTime} ms` : '—'}</span></td><td><span className="date-cell">{formatDate(log.timestamp)}</span></td></tr>)}</tbody></table></div><div className="pagination"><span>Page {logs.meta?.page || page} of {logs.meta?.pages || 1} · {logs.meta?.total || 0} entries</span><div><Button size="sm" variant="secondary" disabled={page <= 1} onClick={() => setPage(value => value - 1)}>Previous</Button><Button size="sm" variant="secondary" disabled={page >= (logs.meta?.pages || 1)} onClick={() => setPage(value => value + 1)}>Next</Button></div></div></> : <EmptyState icon="logs" title="No matching log entries" text="Events will appear as sessions connect and commands execute." />}
      </Card>
    </>
  )
}
