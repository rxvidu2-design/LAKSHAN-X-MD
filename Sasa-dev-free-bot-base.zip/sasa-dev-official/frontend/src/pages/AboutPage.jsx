import { Link } from 'react-router-dom'
import { Icon } from '../components/Icon.jsx'
import { Badge, Button, Card } from '../components/ui.jsx'
import { useAuth } from '../context/AuthContext.jsx'

export default function AboutPage() {
  const { user } = useAuth()
  return (
    <main className="about-page">
      <section className="about-hero"><Badge tone="success">Sasa Dev Official v1.0</Badge><h1>A reliable foundation for responsible WhatsApp automation.</h1><p>The platform combines a Baileys-compatible Multi-Device runtime with encrypted MongoDB persistence, a modular command engine, protected APIs, and a realtime React operations dashboard.</p><Link to={user ? '/dashboard' : '/login'}><Button icon="arrow">{user ? 'Return to dashboard' : 'Open control center'}</Button></Link></section>
      <section className="about-principles"><Card><Icon name="shield"/><h3>Secure by configuration</h3><p>Long-lived credentials are encrypted at rest. API keys remain server-side, administrator passwords are hashed, and management routes require authentication.</p></Card><Card><Icon name="activity"/><h3>Truthful system state</h3><p>The interface displays real QR, pair, database, API, reconnect, and WhatsApp states. It does not generate fake success responses.</p></Card><Card><Icon name="globe"/><h3>Responsible operation</h3><p>Broadcasts are disabled by default and limited to opted-in groups. Use the software in accordance with WhatsApp terms and applicable law.</p></Card></section>
      <section className="architecture-panel"><div><span className="eyebrow">Architecture</span><h2>Built as maintainable modules, not a single-file bot.</h2><p>Every layer can evolve independently while retaining a consistent error and response contract.</p></div><div className="architecture-flow"><span><Icon name="globe"/>React dashboard</span><i/><span><Icon name="server"/>Express and Socket.IO</span><i/><span><Icon name="layers"/>Command and service layer</span><i/><span><Icon name="database"/>MongoDB encrypted auth</span></div></section>
      <section className="disclaimer"><Icon name="info"/><div><strong>Independent software notice</strong><p>Baileys is an unofficial WhatsApp Web library. Sasa Dev Official is not affiliated, associated, authorized, endorsed by, or officially connected with WhatsApp or Meta. Avoid spam, stalkerware, unauthorized access, and abusive automation.</p></div></section>
    </main>
  )
}
