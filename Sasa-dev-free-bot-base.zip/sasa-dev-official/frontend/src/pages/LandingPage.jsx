import { Link } from 'react-router-dom'
import { Icon } from '../components/Icon.jsx'
import { Badge, Button, Card } from '../components/ui.jsx'
import { useApi } from '../hooks/useApi.js'
import { formatDuration, formatNumber } from '../utils/format.js'

const features = [
  { icon: 'qr', title: 'Live QR authentication', text: 'Generate a real WhatsApp linking QR and follow every connection state in real time.' },
  { icon: 'phone', title: 'Secure pair codes', text: 'Link a phone number with an eight-digit pair code through the same protected session runtime.' },
  { icon: 'database', title: 'Encrypted persistence', text: 'Credentials and Signal keys persist in MongoDB with authenticated encryption at rest.' },
  { icon: 'terminal', title: '200 real commands', text: 'A modular command registry spans media, AI, search, groups, utilities, owner controls, and more.' },
  { icon: 'shield', title: 'Production safeguards', text: 'Rate limits, validation, SSRF protection, permissions, cooldowns, safe logs, and graceful recovery.' },
  { icon: 'activity', title: 'Realtime operations', text: 'Track sessions, commands, message statistics, logs, API health, and server status from one workspace.' }
]

export default function LandingPage() {
  const { data } = useApi('/status', { initialData: null })
  return (
    <main className="landing">
      <section className="hero">
        <div className="hero__glow hero__glow--one"/><div className="hero__glow hero__glow--two"/>
        <div className="hero__content">
          <Badge tone="success" dot>WhatsApp Multi-Device control center</Badge>
          <h1>Connect, automate, and operate with <span>confidence.</span></h1>
          <p>Sasa Dev Official brings real QR and pair-code authentication, encrypted MongoDB sessions, 200 modular commands, and a responsive operations dashboard into one production-oriented platform.</p>
          <div className="hero__actions"><Link to="/login"><Button icon="arrow">Open control center</Button></Link><Link to="/about"><Button variant="secondary" icon="info">Explore the platform</Button></Link></div>
          <div className="hero__proof"><span><Icon name="shield" size={16}/>Encrypted auth state</span><span><Icon name="database" size={16}/>MongoDB persistence</span><span><Icon name="bolt" size={16}/>Realtime updates</span></div>
        </div>
        <div className="hero-console">
          <div className="hero-console__top"><span className="window-dots"><i/><i/><i/></span><span>Connection overview</span><Badge tone={data?.sessions?.connected ? 'success' : 'neutral'} dot>{data?.sessions?.connected ? 'Operational' : 'Ready'}</Badge></div>
          <div className="hero-console__bot"><span className="brand__mark brand__mark--large"><img src="/logo.jpg" alt="Sasa Dev Official"/></span><div><small>BOT IDENTITY</small><strong>Sasa Dev Official</strong><span>Managed WhatsApp runtime</span></div><span className="pulse-orbit"><i/></span></div>
          <div className="hero-console__grid"><div><span>Active sessions</span><strong>{formatNumber(data?.sessions?.total)}</strong><small>Managed securely</small></div><div><span>Connected</span><strong>{formatNumber(data?.sessions?.connected)}</strong><small>Realtime state</small></div><div><span>Commands</span><strong>200</strong><small>Loaded modules</small></div><div><span>Server uptime</span><strong>{data ? formatDuration(data.uptime) : 'Checking'}</strong><small>Current process</small></div></div>
          <div className="signal-line"><div/><span><Icon name="activity" size={15}/>Session events stream through Socket.IO</span></div>
        </div>
      </section>
      <section className="trust-strip"><span>Built for operational clarity</span><div><strong>QR</strong><i/>PAIR CODE<i/>MONGODB<i/>BAILEYS v7<i/>REACT</div></section>
      <section className="feature-section"><div className="section-heading"><span className="eyebrow">Platform capabilities</span><h2>Everything required to run the bot properly.</h2><p>Not a static mock-up. Each surface is connected to the API and the live WhatsApp session manager.</p></div><div className="feature-grid">{features.map(feature => <Card key={feature.title} className="feature-card"><span className="feature-card__icon"><Icon name={feature.icon} size={22}/></span><h3>{feature.title}</h3><p>{feature.text}</p><span className="feature-card__line"/></Card>)}</div></section>
      <section className="cta-panel"><div><span className="eyebrow">Sasa Dev Official</span><h2>Your bot operations, finally in one clear workspace.</h2><p>Configure the server secrets, connect MongoDB, and link your first WhatsApp session.</p></div><Link to="/login"><Button icon="arrow">Continue to login</Button></Link></section>
    </main>
  )
}
