import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { Icon } from '../components/Icon.jsx'
import { Badge, Button, Card, EmptyState, PageHeader, Skeleton, StatusDot } from '../components/ui.jsx'
import { useApi } from '../hooks/useApi.js'
import { useSocket } from '../context/SocketContext.jsx'
import { useToast } from '../context/ToastContext.jsx'
import { post, remove } from '../services/api.js'
import { formatDate, sentenceCase } from '../utils/format.js'

const tone = status => status === 'connected' ? 'success' : ['failed','logged_out'].includes(status) ? 'danger' : ['waiting_qr','waiting_pair','connecting','reconnecting'].includes(status) ? 'warning' : 'neutral'

export default function SessionsPage() {
  const sessions = useApi('/sessions', { initialData: [] })
  const { sessionUpdates } = useSocket()
  const { notify } = useToast()
  const [query, setQuery] = useState('')
  const [working, setWorking] = useState('')
  const data = useMemo(() => (sessions.data || []).map(item => ({ ...item, ...(sessionUpdates[item.sessionId] || {}) })).filter(item => `${item.label} ${item.connectedNumber || ''} ${item.sessionId}`.toLowerCase().includes(query.toLowerCase())), [sessions.data, sessionUpdates, query])

  const action = async (session, operation) => {
    if (operation === 'delete' && !window.confirm(`Delete ${session.label}? This permanently removes its encrypted WhatsApp credentials.`)) return
    setWorking(`${session.sessionId}:${operation}`)
    try {
      if (operation === 'delete') await remove(`/session/${session.sessionId}`)
      else await post(`/session/${session.sessionId}/${operation}`)
      notify(operation === 'delete' ? 'Session deleted securely.' : `${sentenceCase(operation)} requested.`, 'success')
      await sessions.execute()
    } catch (error) { notify(error.message, 'error') }
    finally { setWorking('') }
  }

  return (
    <>
      <PageHeader eyebrow="Session management" title="WhatsApp sessions" description="Inspect each persistent bot runtime, recover a connection, stop its socket, or securely delete its credentials." actions={<Link to="/connect"><Button icon="plus">New session</Button></Link>} />
      <Card className="table-card">
        <div className="table-toolbar"><div className="search-input"><Icon name="search"/><input value={query} onChange={event => setQuery(event.target.value)} placeholder="Search label, number, or session ID"/></div><Button variant="secondary" size="sm" icon="refresh" onClick={() => sessions.execute().catch(()=>{})} loading={sessions.loading}>Refresh</Button></div>
        {sessions.loading && !sessions.data?.length ? <div className="table-skeleton">{[1,2,3].map(item => <Skeleton key={item}/>)}</div> : data.length ? <div className="responsive-table"><table><thead><tr><th>Session</th><th>Connection</th><th>Method</th><th>Last activity</th><th className="align-right">Actions</th></tr></thead><tbody>{data.map(session => <tr key={session.sessionId}><td><div className="table-primary"><span className="session-method"><Icon name={session.method === 'pair' ? 'phone' : 'qr'}/></span><span><strong>{session.label}</strong><small>{session.sessionId.slice(0, 8)}…{session.sessionId.slice(-6)}</small></span></div></td><td><div className="connection-cell"><Badge tone={tone(session.status)} dot>{sentenceCase(session.status)}</Badge><small>{session.connectedNumber || 'No connected number'}</small></div></td><td><span className="method-label">{session.method === 'pair' ? 'Pair code' : 'QR code'}</span></td><td><span className="date-cell">{formatDate(session.lastConnectedAt || session.updatedAt)}</span></td><td><div className="row-actions"><button title="Reconnect" disabled={Boolean(working)} onClick={() => action(session, 'reconnect')}><Icon name="refresh"/></button><button title="Stop" disabled={Boolean(working)} onClick={() => action(session, 'stop')}><Icon name="stop"/></button><button className="danger" title="Delete" disabled={Boolean(working)} onClick={() => action(session, 'delete')}><Icon name="trash"/></button></div></td></tr>)}</tbody></table></div> : <EmptyState icon="sessions" title={query ? 'No matching sessions' : 'No sessions yet'} text={query ? 'Try another search term.' : 'Connect with QR or a pair code to create your first persistent session.'} action={!query && <Link to="/connect"><Button size="sm" icon="plus">Connect first session</Button></Link>} />}
      </Card>
      <div className="session-security"><Icon name="shield"/><div><strong>Credential deletion is permanent</strong><p>Deleting a session closes its socket, attempts a WhatsApp logout, erases encrypted credentials and Signal keys, and removes the bot record. A new QR or pair code is required afterward.</p></div></div>
    </>
  )
}
