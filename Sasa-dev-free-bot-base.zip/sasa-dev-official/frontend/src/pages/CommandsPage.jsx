import { useMemo, useState } from 'react'
import { Icon } from '../components/Icon.jsx'
import { Badge, Button, Card, EmptyState, PageHeader, Skeleton } from '../components/ui.jsx'
import { useApi } from '../hooks/useApi.js'
import { useAuth } from '../context/AuthContext.jsx'
import { useToast } from '../context/ToastContext.jsx'
import { patch } from '../services/api.js'
import { sentenceCase } from '../utils/format.js'

export default function CommandsPage() {
  const commands = useApi('/commands', { initialData: [] })
  const { user } = useAuth()
  const { notify } = useToast()
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState('all')
  const [page, setPage] = useState(1)
  const [working, setWorking] = useState('')
  const categories = useMemo(() => ['all', ...new Set((commands.data || []).map(command => command.category))], [commands.data])
  const filtered = useMemo(() => (commands.data || []).filter(command => (category === 'all' || command.category === category) && `${command.name} ${command.description} ${command.category}`.toLowerCase().includes(query.toLowerCase())), [commands.data, category, query])
  const pageSize = 30
  const visible = filtered.slice(0, page * pageSize)

  const toggle = async command => {
    setWorking(command.name)
    try {
      await patch(`/commands/${command.name}`, { enabled: !command.enabled })
      commands.setData(current => current.map(item => item.name === command.name ? { ...item, enabled: !item.enabled } : item))
      notify(`.${command.name} ${command.enabled ? 'disabled' : 'enabled'}.`, 'success')
    } catch (error) { notify(error.message, 'error') }
    finally { setWorking('') }
  }

  const chooseCategory = value => { setCategory(value); setPage(1) }
  return (
    <>
      <PageHeader eyebrow="Command registry" title="200 modular commands" description="Search every validated command, review permissions and cooldowns, and control availability without changing source code." actions={<Button variant="secondary" icon="refresh" loading={commands.loading} onClick={() => commands.execute().catch(()=>{})}>Reload registry</Button>} />
      <div className="command-summary"><span><strong>{commands.data?.length || 200}</strong>Total modules</span><i/><span><strong>{categories.length - 1}</strong>Categories</span><i/><span><strong>{commands.data?.filter(command => command.enabled).length || 0}</strong>Enabled</span><i/><span><strong>{commands.data?.filter(command => command.permission === 'owner').length || 0}</strong>Owner restricted</span></div>
      <Card className="command-browser"><div className="command-filters"><div className="search-input"><Icon name="search"/><input value={query} onChange={event => { setQuery(event.target.value); setPage(1) }} placeholder="Search command or description"/></div><div className="category-pills">{categories.map(item => <button key={item} className={category === item ? 'is-active' : ''} onClick={() => chooseCategory(item)}>{sentenceCase(item)}<span>{item === 'all' ? commands.data?.length : commands.data?.filter(command => command.category === item).length}</span></button>)}</div></div>
        {commands.loading && !commands.data?.length ? <div className="command-grid">{Array.from({length: 9}, (_, index) => <Skeleton className="command-skeleton" key={index}/>)}</div> : visible.length ? <><div className="command-grid">{visible.map(command => <article className={`command-card ${!command.enabled ? 'is-disabled' : ''}`} key={command.name}><header><span className="command-card__icon"><Icon name={command.category === 'ai' ? 'spark' : command.category === 'group' ? 'users' : command.category === 'owner' ? 'shield' : command.category === 'media' ? 'layers' : 'terminal'} /></span><div><strong>.{command.name}</strong><small>{sentenceCase(command.category)}</small></div><Badge tone={command.enabled ? 'success' : 'neutral'}>{command.enabled ? 'Enabled' : 'Disabled'}</Badge></header><p>{command.description}</p><div className="command-card__meta"><span><Icon name="key"/> {sentenceCase(command.permission)}</span><span><Icon name="clock"/> {command.cooldown}s</span></div><code>.{command.name}{command.usage ? ` ${command.usage}` : ''}</code>{user?.role === 'admin' && <button className="command-toggle" onClick={() => toggle(command)} disabled={working === command.name}><span>{working === command.name ? 'Updating' : command.enabled ? 'Disable command' : 'Enable command'}</span><i className={command.enabled ? 'is-on' : ''}><b/></i></button>}</article>)}</div>{visible.length < filtered.length && <div className="load-more"><Button variant="secondary" onClick={() => setPage(value => value + 1)}>Load {Math.min(pageSize, filtered.length - visible.length)} more</Button><small>Showing {visible.length} of {filtered.length}</small></div>}</> : <EmptyState icon="search" title="No commands found" text="Change the category or search phrase and try again." />}
      </Card>
    </>
  )
}
