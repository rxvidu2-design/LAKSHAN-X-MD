import { Link } from 'react-router-dom'
import { Icon } from '../components/Icon.jsx'
import { Badge, Button, Card, EmptyState, PageHeader, Skeleton, StatusDot } from '../components/ui.jsx'
import { useSocket } from '../context/SocketContext.jsx'
import { useApi } from '../hooks/useApi.js'
import { formatDate, formatNumber, sentenceCase } from '../utils/format.js'

const Metric = ({ icon, label, value, detail, tone }) => <Card className="metric-card"><div className={`metric-card__icon metric-card__icon--${tone}`}><Icon name={icon} size={21}/></div><div><span>{label}</span><strong>{value}</strong><small>{detail}</small></div><span className="metric-card__trace"><i/><i/><i/><i/></span></Card>

export default function DashboardPage() {
  const stats = useApi('/stats', { initialData: null })
  const sessions = useApi('/sessions', { initialData: [] })
  const { sessionUpdates } = useSocket()
  const overview = stats.data?.overview || {}
  const liveSessions = (sessions.data || []).map(session => ({ ...session, ...(sessionUpdates[session.sessionId] || {}) }))
  const connected = liveSessions.filter(session => session.status === 'connected').length
  return (
    <>
      <PageHeader eyebrow="Operations overview" title="Good to see you." description="A realtime view of bot health, connection state, command activity, and recent events." actions={<><Button variant="secondary" icon="refresh" onClick={() => { stats.execute().catch(()=>{}); sessions.execute().catch(()=>{}) }}>Refresh</Button><Link to="/connect"><Button icon="plus">Connect session</Button></Link></>} />
      {stats.error && <div className="inline-notice inline-notice--warning"><Icon name="alert"/><div><strong>Operational data is temporarily unavailable</strong><p>{stats.error.message}. The dashboard will recover automatically when the backend is ready.</p></div></div>}
      <div className="metrics-grid">
        <Metric icon="wifi" label="Connected sessions" value={formatNumber(connected || overview.connected)} detail={`${formatNumber(liveSessions.length || overview.sessions)} active records`} tone="green" />
        <Metric icon="message" label="Command executions" value={formatNumber(overview.commands?.executions)} detail={`${formatNumber(overview.commands?.successes)} successful`} tone="blue" />
        <Metric icon="users" label="Known users" value={formatNumber(overview.users)} detail={`${formatNumber(overview.groups)} active groups`} tone="violet" />
        <Metric icon="activity" label="Events in 24 hours" value={formatNumber(overview.logs24h)} detail={`${formatNumber(overview.errors24h)} errors recorded`} tone="amber" />
      </div>
      <div className="dashboard-grid">
        <Card className="session-overview"><div className="card-heading"><div><span className="eyebrow">Live connections</span><h2>Session health</h2></div><Link to="/sessions">View all <Icon name="arrow" size={15}/></Link></div>
          {sessions.loading ? <div className="session-skeleton"><Skeleton/><Skeleton/><Skeleton/></div> : liveSessions.length ? <div className="session-list">{liveSessions.slice(0, 4).map(session => <div className="session-row" key={session.sessionId}><span className="session-row__mark"><StatusDot status={session.status}/><Icon name={session.method === 'pair' ? 'phone' : 'qr'} size={18}/></span><div><strong>{session.label}</strong><small>{session.connectedNumber || 'Waiting for connection'}</small></div><Badge tone={session.status === 'connected' ? 'success' : session.status === 'failed' ? 'danger' : 'warning'}>{sentenceCase(session.status)}</Badge><span className="session-row__time">{formatDate(session.lastConnectedAt || session.updatedAt)}</span></div>)}</div> : <EmptyState icon="sessions" title="No sessions connected" text="Create a QR or pair-code session to start the WhatsApp runtime." action={<Link to="/connect"><Button size="sm" icon="plus">Create session</Button></Link>} />}
        </Card>
        <Card className="system-card"><div className="card-heading"><div><span className="eyebrow">System state</span><h2>Runtime services</h2></div><span className="health-ring"><i/></span></div><div className="service-list"><div><span className="service-icon"><Icon name="server"/></span><p><strong>API server</strong><small>Express REST and Socket.IO</small></p><Badge tone="success" dot>Online</Badge></div><div><span className="service-icon"><Icon name="database"/></span><p><strong>MongoDB</strong><small>Application and auth persistence</small></p><Badge tone={stats.error ? 'warning' : 'success'} dot>{stats.error ? 'Degraded' : 'Connected'}</Badge></div><div><span className="service-icon"><Icon name="terminal"/></span><p><strong>Command registry</strong><small>200 validated modules</small></p><Badge tone="success" dot>Loaded</Badge></div><div><span className="service-icon"><Icon name="activity"/></span><p><strong>Event channel</strong><small>Realtime browser telemetry</small></p><Badge tone="success" dot>Active</Badge></div></div><Link className="system-card__link" to="/status">Open detailed status <Icon name="arrow" size={15}/></Link></Card>
        <Card className="activity-card"><div className="card-heading"><div><span className="eyebrow">Audit trail</span><h2>Recent activity</h2></div><Link to="/logs">All logs <Icon name="arrow" size={15}/></Link></div>{stats.data?.recentLogs?.length ? <div className="timeline">{stats.data.recentLogs.map(log => <div className="timeline__item" key={log._id}><span className={`timeline__dot timeline__dot--${log.level}`}/><div><strong>{log.command ? `.${log.command}` : log.message || 'System event'}</strong><small>{log.status || log.level} · {log.responseTime ? `${log.responseTime} ms` : 'system'}</small></div><time>{formatDate(log.timestamp)}</time></div>)}</div> : <EmptyState icon="logs" title="No activity yet" text="Command and system events will appear here." />}</Card>
        <Card className="commands-card"><div className="card-heading"><div><span className="eyebrow">Performance</span><h2>Most used commands</h2></div><Link to="/commands">Command center <Icon name="arrow" size={15}/></Link></div>{stats.data?.topCommands?.length ? <div className="command-bars">{stats.data.topCommands.map((command, index) => <div key={command.name}><span><strong>.{command.name}</strong><small>{formatNumber(command.executions)} runs</small></span><div><i style={{ width: `${Math.max(10, (command.executions / stats.data.topCommands[0].executions) * 100)}%` }}/></div><b>#{index + 1}</b></div>)}</div> : <EmptyState icon="chart" title="No command statistics" text="Usage rankings will populate after commands run." />}</Card>
      </div>
    </>
  )
}
