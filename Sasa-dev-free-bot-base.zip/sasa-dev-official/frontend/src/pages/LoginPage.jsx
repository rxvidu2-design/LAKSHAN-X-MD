import { useState } from 'react'
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom'
import { Brand } from '../components/Brand.jsx'
import { Icon } from '../components/Icon.jsx'
import { Button, Field } from '../components/ui.jsx'
import { useAuth } from '../context/AuthContext.jsx'

export default function LoginPage() {
  const { user, login } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [form, setForm] = useState({ username: '', password: '' })
  const [visible, setVisible] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  if (user) return <Navigate to="/dashboard" replace />
  const submit = async event => {
    event.preventDefault(); setLoading(true); setError('')
    try { await login(form); navigate(location.state?.from || '/dashboard', { replace: true }) }
    catch (requestError) { setError(requestError.message) }
    finally { setLoading(false) }
  }
  return (
    <main className="login-page">
      <div className="login-page__visual"><Link to="/"><Brand /></Link><div className="login-visual__copy"><span className="eyebrow">Protected operations</span><h1>One secure workspace for every bot session.</h1><p>Monitor live connections, issue pairing credentials, review command activity, and manage system configuration without exposing backend secrets.</p><div className="login-assurances"><span><Icon name="lock"/>HTTP-only authentication</span><span><Icon name="shield"/>Role-protected operations</span><span><Icon name="activity"/>Live session telemetry</span></div></div><small>WhatsApp is a trademark of Meta. This project is not affiliated with Meta.</small></div>
      <div className="login-page__form"><div className="login-card"><span className="login-card__icon"><Icon name="key" size={24}/></span><span className="eyebrow">Administrator access</span><h2>Welcome back</h2><p>Enter the administrator credentials configured on your server.</p>{error && <div className="form-alert"><Icon name="alert" size={17}/><span>{error}</span></div>}<form onSubmit={submit}><Field label="Username"><div className="input-wrap"><Icon name="users" size={18}/><input autoComplete="username" value={form.username} onChange={event => setForm({ ...form, username: event.target.value })} placeholder="Administrator username" required minLength={3}/></div></Field><Field label="Password"><div className="input-wrap"><Icon name="lock" size={18}/><input type={visible ? 'text' : 'password'} autoComplete="current-password" value={form.password} onChange={event => setForm({ ...form, password: event.target.value })} placeholder="Administrator password" required minLength={8}/><button type="button" onClick={() => setVisible(value => !value)} aria-label={visible ? 'Hide password' : 'Show password'}><Icon name={visible ? 'eyeoff' : 'eye'} size={18}/></button></div></Field><Button loading={loading} icon="arrow" className="button--full">Sign in securely</Button></form><Link className="back-link" to="/"><Icon name="chevron" size={15}/>Return to website</Link></div></div>
    </main>
  )
}
