import { useState } from 'react'
import { Navigate } from 'react-router-dom'
import { Icon } from '../components/Icon.jsx'
import { Badge, Button, Card, EmptyState, PageHeader, Skeleton } from '../components/ui.jsx'
import { useApi } from '../hooks/useApi.js'
import { useToast } from '../context/ToastContext.jsx'
import { useAuth } from '../context/AuthContext.jsx'
import { get, patch } from '../services/api.js'
import { formatDate, sentenceCase } from '../utils/format.js'

const sections = {
  users: { icon: 'users', title: 'Users', description: 'Administrator and operator accounts' },
  bots: { icon: 'terminal', title: 'Bots', description: 'Configured WhatsApp bot records' },
  groups: { icon: 'layers', title: 'Groups', description: 'Known WhatsApp group records' }
}

export default function AdminPage() {
  const [section, setSection] = useState('users')
  const [working, setWorking] = useState('')
  const [apiState, setApiState] = useState(null)
  const records = useApi(`/admin/${section}?page=1&limit=100`, { initialData: [] })
  const overview = useApi('/admin/overview', { initialData: null })
  const { notify } = useToast()
  const { user } = useAuth()

  const update = async (id, body) => {
    setWorking(id)
    try {
      const response = await patch(`/admin/${section}/${id}`, body)
      records.setData(current => current.map(item => item._id === id ? response.data : item))
      notify(`${sections[section].title.slice(0, -1)} updated.`, 'success')
    } catch (error) { notify(error.message, 'error') }
    finally { setWorking('') }
  }

  const testApi = async () => {
    setApiState({ loading: true })
    try { setApiState((await get('/admin/api-status')).data) }
    catch (error) { setApiState({ status: 'unavailable', error: error.message }) }
  }

  if (user?.role !== 'admin') return <Navigate to="/dashboard" replace />

  return (
    <>
      <PageHeader eyebrow="Administrator workspace" title="Administration" description="View and manage users, bot runtimes, groups, database readiness, and the external API adapter." actions={<Button variant="secondary" icon="refresh" loading={records.loading} onClick={() => { records.execute().catch(()=>{}); overview.execute().catch(()=>{}) }}>Refresh records</Button>} />
      <div className="admin-metrics"><Card><Icon name="users"/><span><small>Users</small><strong>{overview.data?.counts?.users ?? '—'}</strong></span></Card><Card><Icon name="sessions"/><span><small>Sessions</small><strong>{overview.data?.counts?.sessions ?? '—'}</strong></span></Card><Card><Icon name="terminal"/><span><small>Bots</small><strong>{overview.data?.counts?.bots ?? '—'}</strong></span></Card><Card><Icon name="layers"/><span><small>Groups</small><strong>{overview.data?.counts?.groups ?? '—'}</strong></span></Card></div>
      <div className="admin-layout">
        <Card className="admin-records"><div className="admin-tabs">{Object.entries(sections).map(([key, item]) => <button key={key} className={section === key ? 'is-active' : ''} onClick={() => setSection(key)}><Icon name={item.icon}/><span><strong>{item.title}</strong><small>{item.description}</small></span></button>)}</div><div className="admin-table-head"><div><span className="eyebrow">{sections[section].title}</span><h2>{sections[section].description}</h2></div><Badge tone="neutral">{records.meta?.total ?? records.data?.length ?? 0} records</Badge></div>{records.loading && !records.data?.length ? <div className="table-skeleton">{[1,2,3].map(item => <Skeleton key={item}/>)}</div> : records.data?.length ? <div className="responsive-table">{section === 'users' ? <UsersTable data={records.data} working={working} update={update}/> : section === 'bots' ? <BotsTable data={records.data} working={working} update={update}/> : <GroupsTable data={records.data} working={working} update={update}/>}</div> : <EmptyState icon={sections[section].icon} title={`No ${section} found`} text="Records appear after the corresponding runtime activity occurs." />}</Card>
        <aside className="admin-aside"><Card><span className="eyebrow">Database</span><h3>MongoDB connection</h3><div className="admin-health"><span className={overview.data?.database?.status === 'connected' ? 'is-ready' : ''}><Icon name="database"/></span><div><strong>{sentenceCase(overview.data?.database?.status || 'checking')}</strong><small>{overview.data?.database?.host || 'Host is not exposed'}</small></div></div><dl><div><dt>Ready state</dt><dd>{overview.data?.database?.readyState ?? '—'}</dd></div><div><dt>Connected at</dt><dd>{formatDate(overview.data?.database?.connectedAt)}</dd></div></dl></Card><Card><span className="eyebrow">External provider</span><h3>Sasa Dev API</h3><p>Run an explicit authenticated health test. This can consume provider quota.</p>{apiState && !apiState.loading && <div className={`api-result ${apiState.status === 'available' ? 'is-ready' : ''}`}><Icon name={apiState.status === 'available' ? 'check' : 'alert'}/><span><strong>{sentenceCase(apiState.status)}</strong><small>{apiState.responseTime ? `${apiState.responseTime} ms` : apiState.error}</small></span></div>}<Button size="sm" variant="secondary" loading={apiState?.loading} onClick={testApi} className="button--full">Test API adapter</Button></Card></aside>
      </div>
    </>
  )
}

const Toggle = ({ active, disabled, onClick }) => <button className={`admin-toggle ${active ? 'is-on' : ''}`} disabled={disabled} onClick={onClick} aria-label={active ? 'Disable' : 'Enable'}><i/></button>

const UsersTable = ({ data, working, update }) => <table><thead><tr><th>User</th><th>Role</th><th>Last login</th><th className="align-right">Active</th></tr></thead><tbody>{data.map(user => <tr key={user._id}><td><div className="table-primary"><span className="session-method"><Icon name="users"/></span><span><strong>{user.displayName || user.username}</strong><small>{user.username} · {user.phoneNumber || 'No number'}</small></span></div></td><td><select className="table-select" value={user.role} disabled={working === user._id} onChange={event => update(user._id, { role: event.target.value })}><option value="admin">Admin</option><option value="operator">Operator</option><option value="viewer">Viewer</option></select></td><td><span className="date-cell">{formatDate(user.lastLoginAt)}</span></td><td><div className="align-action"><Toggle active={user.active} disabled={working === user._id} onClick={() => update(user._id, { active: !user.active })}/></div></td></tr>)}</tbody></table>
const BotsTable = ({ data, working, update }) => <table><thead><tr><th>Bot</th><th>Owner</th><th>Status</th><th className="align-right">Enabled</th></tr></thead><tbody>{data.map(bot => <tr key={bot._id}><td><div className="table-primary"><span className="session-method"><Icon name="terminal"/></span><span><strong>{bot.name}</strong><small>{bot.botId}</small></span></div></td><td><div className="stacked-cell"><strong>{bot.ownerName}</strong><small>{bot.ownerNumber}</small></div></td><td><Badge tone={bot.status === 'online' ? 'success' : 'neutral'} dot>{sentenceCase(bot.status)}</Badge></td><td><div className="align-action"><Toggle active={bot.enabled} disabled={working === bot._id} onClick={() => update(bot._id, { enabled: !bot.enabled })}/></div></td></tr>)}</tbody></table>
const GroupsTable = ({ data, working, update }) => <table><thead><tr><th>Group</th><th>Session</th><th>Participants</th><th className="align-right">Tracked</th></tr></thead><tbody>{data.map(group => <tr key={group._id}><td><div className="table-primary"><span className="session-method"><Icon name="layers"/></span><span><strong>{group.subject || 'Unnamed group'}</strong><small>{group.jid}</small></span></div></td><td><span className="date-cell">{group.sessionId?.slice(0, 12)}…</span></td><td><span className="latency">{group.participantsCount || 0}</span></td><td><div className="align-action"><Toggle active={group.active} disabled={working === group._id} onClick={() => update(group._id, { active: !group.active })}/></div></td></tr>)}</tbody></table>
