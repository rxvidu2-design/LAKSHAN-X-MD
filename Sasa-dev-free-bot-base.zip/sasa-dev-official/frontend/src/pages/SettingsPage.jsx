import { useEffect, useState } from 'react'
import { Navigate } from 'react-router-dom'
import { Icon } from '../components/Icon.jsx'
import { Button, Card, Field, PageHeader } from '../components/ui.jsx'
import { useApi } from '../hooks/useApi.js'
import { useToast } from '../context/ToastContext.jsx'
import { useAuth } from '../context/AuthContext.jsx'
import { put } from '../services/api.js'

const defaults = { dashboardTitle: 'Sasa Dev Official', defaultPrefix: '.', supportMessage: 'Contact the official Sasa Dev channel for support.', maintenanceMode: false }

export default function SettingsPage() {
  const settings = useApi('/settings', { initialData: null })
  const [form, setForm] = useState(defaults)
  const [saving, setSaving] = useState(false)
  const { notify } = useToast()
  const { user } = useAuth()
  useEffect(() => { if (settings.data) setForm({ ...defaults, ...settings.data }) }, [settings.data])
  const save = async event => {
    event.preventDefault(); setSaving(true)
    try {
      await Promise.all(Object.entries(form).map(([key, value]) => put('/settings', { key, value })))
      notify('Dashboard settings saved.', 'success')
      await settings.execute()
    } catch (error) { notify(error.message, 'error') }
    finally { setSaving(false) }
  }
  if (user?.role !== 'admin') return <Navigate to="/dashboard" replace />

  return (
    <>
      <PageHeader eyebrow="Platform configuration" title="Settings" description="Manage non-secret dashboard defaults. Environment secrets remain server-only and cannot be read or changed here." actions={<Button icon="check" loading={saving} form="settings-form">Save changes</Button>} />
      <form id="settings-form" className="settings-layout" onSubmit={save}>
        <Card className="settings-form-card"><div className="settings-section-head"><span><Icon name="settings"/></span><div><h2>General preferences</h2><p>Shared interface and command defaults.</p></div></div><div className="settings-fields"><Field label="Dashboard title" hint="Displayed to administrators in the management workspace."><input value={form.dashboardTitle} onChange={event => setForm({ ...form, dashboardTitle: event.target.value })} maxLength={100}/></Field><Field label="Default command prefix" hint="Group-specific prefixes can override this value."><input value={form.defaultPrefix} onChange={event => setForm({ ...form, defaultPrefix: event.target.value.replace(/\s/g, '').slice(0, 5) })} maxLength={5}/></Field><Field label="Support message" hint="A short message operators can reference when handling reports."><textarea value={form.supportMessage} onChange={event => setForm({ ...form, supportMessage: event.target.value })} rows={4} maxLength={2000}/></Field><label className="toggle-row"><span><strong>Maintenance mode indicator</strong><small>Records the dashboard preference; process control remains environment-managed.</small></span><button type="button" className={form.maintenanceMode ? 'is-on' : ''} onClick={() => setForm({ ...form, maintenanceMode: !form.maintenanceMode })} aria-pressed={form.maintenanceMode}><i/></button></label></div></Card>
        <aside className="settings-aside"><Card><div className="settings-section-head"><span><Icon name="shield"/></span><div><h2>Security boundaries</h2><p>Protected by server configuration.</p></div></div><ul className="security-list"><li><Icon name="check"/><span><strong>Secrets stay in environment variables</strong><small>No API keys are bundled into React.</small></span></li><li><Icon name="check"/><span><strong>Credentials are encrypted at rest</strong><small>Session and Signal data use AES-256-GCM.</small></span></li><li><Icon name="check"/><span><strong>Dangerous commands default off</strong><small>Shell, update, and evaluation require explicit configuration.</small></span></li><li><Icon name="check"/><span><strong>Broadcasts require opt-in</strong><small>Disabled globally unless intentionally enabled.</small></span></li></ul></Card><Card className="env-card"><span className="env-card__icon"><Icon name="terminal"/></span><h3>Environment-managed settings</h3><p>MongoDB URI, session secrets, JWT secret, API keys, CORS, maximum sessions, media limits, and provider timeouts must be updated in your deployment environment.</p><code>.env.example</code></Card></aside>
      </form>
    </>
  )
}
