export const formatDuration = totalSeconds => {
  const seconds = Math.max(0, Number(totalSeconds) || 0)
  const days = Math.floor(seconds / 86400)
  const hours = Math.floor((seconds % 86400) / 3600)
  const minutes = Math.floor((seconds % 3600) / 60)
  if (days) return `${days}d ${hours}h`
  if (hours) return `${hours}h ${minutes}m`
  return `${minutes}m ${Math.floor(seconds % 60)}s`
}
export const formatDate = value => value ? new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)) : 'Not available'
export const formatNumber = value => new Intl.NumberFormat().format(Number(value) || 0)
export const sentenceCase = value => String(value || '').replace(/[_-]/g, ' ').replace(/\b\w/g, letter => letter.toUpperCase())
