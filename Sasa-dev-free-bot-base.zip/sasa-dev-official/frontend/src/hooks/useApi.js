import { useCallback, useEffect, useState } from 'react'
import { get } from '../services/api.js'

export const useApi = (path, options = {}) => {
  const [data, setData] = useState(options.initialData ?? null)
  const [meta, setMeta] = useState(null)
  const [loading, setLoading] = useState(options.immediate !== false)
  const [error, setError] = useState(null)

  const execute = useCallback(async overridePath => {
    setLoading(true)
    setError(null)
    try {
      const response = await get(overridePath || path)
      setData(response.data)
      setMeta(response.meta || null)
      return response
    } catch (requestError) {
      setError(requestError)
      throw requestError
    } finally {
      setLoading(false)
    }
  }, [path])

  useEffect(() => {
    if (options.immediate !== false) execute().catch(() => {})
  }, [execute, options.immediate])

  return { data, setData, meta, loading, error, execute }
}
