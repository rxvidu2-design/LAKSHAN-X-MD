import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react'
import { io } from 'socket.io-client'
import { useAuth } from './AuthContext.jsx'

const SocketContext = createContext(null)

export const SocketProvider = ({ children }) => {
  const { user } = useAuth()
  const socketRef = useRef(null)
  const [connected, setConnected] = useState(false)
  const [sessionUpdates, setSessionUpdates] = useState({})

  useEffect(() => {
    if (!user) {
      socketRef.current?.disconnect()
      socketRef.current = null
      setConnected(false)
      setSessionUpdates({})
      return
    }
    const socketOrigin = String(import.meta.env.VITE_SOCKET_URL || import.meta.env.VITE_API_URL || '').replace(/\/$/, '')
    const socket = io(socketOrigin || undefined, { withCredentials: true, transports: ['websocket', 'polling'], reconnectionDelayMax: 8000 })
    socketRef.current = socket
    socket.on('connect', () => setConnected(true))
    socket.on('disconnect', () => setConnected(false))
    socket.on('session:update', update => setSessionUpdates(current => ({ ...current, [update.sessionId]: { ...(current[update.sessionId] || {}), ...update } })))
    socket.on('session:deleted', ({ sessionId }) => setSessionUpdates(current => {
      const next = { ...current }
      delete next[sessionId]
      return next
    }))
    return () => { socket.disconnect(); socketRef.current = null }
  }, [user])

  const subscribe = useCallback(sessionId => socketRef.current?.emit('session:subscribe', sessionId), [])
  const unsubscribe = useCallback(sessionId => socketRef.current?.emit('session:unsubscribe', sessionId), [])
  const value = useMemo(() => ({ connected, sessionUpdates, subscribe, unsubscribe }), [connected, sessionUpdates, subscribe, unsubscribe])
  return <SocketContext.Provider value={value}>{children}</SocketContext.Provider>
}

export const useSocket = () => useContext(SocketContext)
