import { createContext, useCallback, useContext, useMemo, useState } from 'react'
import { Icon } from '../components/Icon.jsx'

const ToastContext = createContext(null)

export const ToastProvider = ({ children }) => {
  const [items, setItems] = useState([])
  const notify = useCallback((message, tone = 'success') => {
    const id = crypto.randomUUID()
    setItems(current => [...current, { id, message, tone }])
    setTimeout(() => setItems(current => current.filter(item => item.id !== id)), 4500)
  }, [])
  const dismiss = useCallback(id => setItems(current => current.filter(item => item.id !== id)), [])
  const value = useMemo(() => ({ notify }), [notify])
  return (
    <ToastContext.Provider value={value}>
      {children}
      <div className="toast-stack" aria-live="polite">
        {items.map(item => (
          <button className={`toast toast--${item.tone}`} key={item.id} onClick={() => dismiss(item.id)}>
            <span className="toast__icon"><Icon name={item.tone === 'error' ? 'alert' : item.tone === 'info' ? 'info' : 'check'} size={17} /></span>
            <span>{item.message}</span>
            <Icon name="close" size={15} />
          </button>
        ))}
      </div>
    </ToastContext.Provider>
  )
}

export const useToast = () => useContext(ToastContext)
