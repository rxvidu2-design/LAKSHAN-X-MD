export class ApiError extends Error {
  constructor(message, code = 'REQUEST_FAILED', status = 500, details) {
    super(message)
    this.name = 'ApiError'
    this.code = code
    this.status = status
    this.details = details
  }
}

const apiOrigin = String(import.meta.env.VITE_API_URL || '').replace(/\/$/, '')

export const api = async (path, options = {}) => {
  const headers = { accept: 'application/json', ...(options.body ? { 'content-type': 'application/json' } : {}), ...(options.headers || {}) }
  let response
  try {
    response = await fetch(`${apiOrigin}/api${path}`, { ...options, headers, credentials: 'include', body: options.body && typeof options.body !== 'string' ? JSON.stringify(options.body) : options.body })
  } catch {
    throw new ApiError('Could not reach the server', 'NETWORK_ERROR', 0)
  }
  const payload = await response.json().catch(() => null)
  if (!response.ok || !payload?.success) throw new ApiError(payload?.message || `Request failed with HTTP ${response.status}`, payload?.error || 'REQUEST_FAILED', response.status, payload?.details)
  return payload
}

export const get = path => api(path)
export const post = (path, body = {}) => api(path, { method: 'POST', body })
export const put = (path, body = {}) => api(path, { method: 'PUT', body })
export const patch = (path, body = {}) => api(path, { method: 'PATCH', body })
export const remove = path => api(path, { method: 'DELETE' })
