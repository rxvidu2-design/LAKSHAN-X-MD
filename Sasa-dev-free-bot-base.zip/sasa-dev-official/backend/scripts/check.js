import { readdir } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'src')
const files = []
const walk = async directory => {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const target = path.join(directory, entry.name)
    if (entry.isDirectory() && entry.name !== 'tests') await walk(target)
    else if (!entry.isDirectory() && entry.name.endsWith('.js') && entry.name !== 'index.js') files.push(target)
  }
}
await walk(root)
for (const file of files) await import(pathToFileURL(file).href)
console.log(`Validated ${files.length} JavaScript modules`)
