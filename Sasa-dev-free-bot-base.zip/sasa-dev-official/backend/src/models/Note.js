import mongoose from 'mongoose'

const schema = new mongoose.Schema({
  sessionId: { type: String, required: true, index: true },
  userJid: { type: String, required: true, index: true },
  title: { type: String, required: true, trim: true, maxlength: 100 },
  content: { type: String, required: true, maxlength: 10000 },
  tags: [{ type: String, trim: true, lowercase: true }]
}, { timestamps: true, collection: 'notes' })

schema.index({ sessionId: 1, userJid: 1, title: 1 })

export const Note = mongoose.models.Note || mongoose.model('Note', schema)
