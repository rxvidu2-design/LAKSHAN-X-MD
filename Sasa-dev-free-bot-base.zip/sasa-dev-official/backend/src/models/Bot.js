import mongoose from 'mongoose'

const schema = new mongoose.Schema({
  botId: { type: String, required: true, unique: true, index: true },
  sessionId: { type: String, required: true, unique: true, index: true },
  name: { type: String, required: true, trim: true, maxlength: 100 },
  ownerName: { type: String, required: true, trim: true },
  ownerNumber: { type: String, required: true, index: true },
  prefix: { type: String, default: '.', maxlength: 5 },
  logoUrl: String,
  channelUrl: String,
  status: { type: String, default: 'offline', index: true },
  enabled: { type: Boolean, default: true }
}, { timestamps: true, collection: 'bots' })

export const Bot = mongoose.models.Bot || mongoose.model('Bot', schema)
