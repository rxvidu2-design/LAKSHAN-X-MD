import mongoose from 'mongoose'

const schema = new mongoose.Schema({
  sessionId: { type: String, required: true, index: true },
  targetJid: { type: String, required: true, index: true },
  scope: { type: String, enum: ['session', 'group', 'global'], default: 'session', index: true },
  groupJid: { type: String, default: null, index: true },
  reason: { type: String, default: 'No reason provided', maxlength: 500 },
  active: { type: Boolean, default: true, index: true },
  expiresAt: { type: Date, default: null, index: true },
  createdBy: String
}, { timestamps: true, collection: 'bans' })

schema.index({ sessionId: 1, targetJid: 1, scope: 1, groupJid: 1 })

export const Ban = mongoose.models.Ban || mongoose.model('Ban', schema)
