import mongoose from 'mongoose'

const schema = new mongoose.Schema({
  scope: { type: String, enum: ['global', 'session', 'user'], default: 'global', index: true },
  scopeId: { type: String, default: 'global', index: true },
  key: { type: String, required: true, trim: true },
  value: { type: mongoose.Schema.Types.Mixed, default: null },
  updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
}, { timestamps: true, collection: 'settings' })

schema.index({ scope: 1, scopeId: 1, key: 1 }, { unique: true })

export const Setting = mongoose.models.Setting || mongoose.model('Setting', schema)
