import mongoose from 'mongoose'

const schema = new mongoose.Schema({
  sessionId: { type: String, required: true, index: true },
  jid: { type: String, required: true, index: true },
  phoneNumber: { type: String, index: true },
  displayName: String,
  messages: { type: Number, default: 0 },
  commands: { type: Number, default: 0 },
  lastSeenAt: Date,
  metadata: { type: mongoose.Schema.Types.Mixed, default: {} }
}, { timestamps: true, collection: 'usersData' })

schema.index({ sessionId: 1, jid: 1 }, { unique: true })

export const UserData = mongoose.models.UserData || mongoose.model('UserData', schema)
