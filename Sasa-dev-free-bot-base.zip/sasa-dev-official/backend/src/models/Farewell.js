import mongoose from 'mongoose'

const schema = new mongoose.Schema({
  sessionId: { type: String, required: true, index: true },
  groupJid: { type: String, required: true, index: true },
  enabled: { type: Boolean, default: false },
  message: { type: String, default: 'Goodbye {user} from {group}.', maxlength: 2000 },
  imageUrl: String
}, { timestamps: true, collection: 'farewell' })

schema.index({ sessionId: 1, groupJid: 1 }, { unique: true })

export const Farewell = mongoose.models.Farewell || mongoose.model('Farewell', schema)
