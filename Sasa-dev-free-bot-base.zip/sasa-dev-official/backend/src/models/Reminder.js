import mongoose from 'mongoose'

const schema = new mongoose.Schema({
  sessionId: { type: String, required: true, index: true },
  userJid: { type: String, required: true, index: true },
  chatJid: { type: String, required: true },
  text: { type: String, required: true, maxlength: 2000 },
  dueAt: { type: Date, required: true, index: true },
  deliveredAt: Date,
  status: { type: String, enum: ['pending', 'delivered', 'cancelled', 'failed'], default: 'pending', index: true }
}, { timestamps: true, collection: 'reminders' })

schema.index({ status: 1, dueAt: 1 })

export const Reminder = mongoose.models.Reminder || mongoose.model('Reminder', schema)
