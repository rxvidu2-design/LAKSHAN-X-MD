import mongoose from 'mongoose'

const schema = new mongoose.Schema({
  username: { type: String, required: true, unique: true, trim: true, lowercase: true, minlength: 3, maxlength: 64 },
  passwordHash: { type: String, required: true, select: false },
  displayName: { type: String, trim: true, maxlength: 100 },
  phoneNumber: { type: String, trim: true, index: true },
  role: { type: String, enum: ['admin', 'operator', 'viewer'], default: 'viewer', index: true },
  active: { type: Boolean, default: true, index: true },
  lastLoginAt: Date,
  lastLoginIp: String
}, { timestamps: true, collection: 'users' })

export const User = mongoose.models.User || mongoose.model('User', schema)
