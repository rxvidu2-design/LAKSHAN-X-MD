import mongoose from 'mongoose'

const schema = new mongoose.Schema({
  sessionId: { type: String, required: true, index: true },
  groupJid: { type: String, required: true, index: true },
  userJid: { type: String, required: true, index: true },
  url: { type: String, required: true },
  action: { type: String, enum: ['allowed', 'deleted', 'warned', 'removed'], required: true },
  reason: String
}, { timestamps: true, collection: 'antiLink' })

schema.index({ sessionId: 1, groupJid: 1, createdAt: -1 })

export const AntiLink = mongoose.models.AntiLink || mongoose.model('AntiLink', schema)
