import mongoose from 'mongoose'
import { SESSION_STATUSES } from '../config/constants.js'

const encryptedSchema = new mongoose.Schema({
  iv: String,
  tag: String,
  data: String,
  version: { type: Number, default: 1 }
}, { _id: false })

const schema = new mongoose.Schema({
  sessionId: { type: String, required: true, unique: true, index: true },
  botId: { type: String, required: true, index: true },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', index: true },
  ownerNumber: { type: String, required: true, index: true },
  label: { type: String, trim: true, maxlength: 80, default: 'Primary session' },
  method: { type: String, enum: ['qr', 'pair', 'restore'], required: true },
  status: { type: String, enum: SESSION_STATUSES, default: 'initializing', index: true },
  active: { type: Boolean, default: true, index: true },
  connectedNumber: { type: String, default: null, index: true },
  connectedJid: { type: String, default: null },
  platform: { type: String, default: null },
  credentials: { type: encryptedSchema, select: false },
  reconnectAttempts: { type: Number, default: 0 },
  lastConnectedAt: Date,
  lastDisconnectedAt: Date,
  disconnectReason: String,
  stats: {
    messagesReceived: { type: Number, default: 0 },
    messagesSent: { type: Number, default: 0 },
    commandsExecuted: { type: Number, default: 0 },
    commandsFailed: { type: Number, default: 0 }
  }
}, { timestamps: true, collection: 'sessions', optimisticConcurrency: true })

schema.index({ active: 1, status: 1 })
schema.index({ userId: 1, createdAt: -1 })

export const Session = mongoose.models.Session || mongoose.model('Session', schema)
