import mongoose from 'mongoose'
import { PERMISSIONS } from '../config/constants.js'

const schema = new mongoose.Schema({
  name: { type: String, required: true, unique: true, index: true },
  aliases: [{ type: String }],
  description: { type: String, required: true },
  category: { type: String, required: true, index: true },
  usage: { type: String, default: '' },
  permission: { type: String, enum: PERMISSIONS, default: 'public', index: true },
  cooldown: { type: Number, default: 3, min: 0, max: 3600 },
  enabled: { type: Boolean, default: true, index: true },
  executions: { type: Number, default: 0 },
  successes: { type: Number, default: 0 },
  failures: { type: Number, default: 0 },
  averageResponseTime: { type: Number, default: 0 },
  lastUsedAt: Date
}, { timestamps: true, collection: 'commands' })

schema.index({ category: 1, enabled: 1 })

export const Command = mongoose.models.Command || mongoose.model('Command', schema)
