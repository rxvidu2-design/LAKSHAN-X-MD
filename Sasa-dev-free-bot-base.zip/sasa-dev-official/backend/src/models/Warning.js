import mongoose from 'mongoose'

const schema = new mongoose.Schema({
  sessionId: { type: String, required: true, index: true },
  groupJid: { type: String, required: true, index: true },
  userJid: { type: String, required: true, index: true },
  reason: { type: String, required: true, maxlength: 500 },
  issuedBy: { type: String, required: true },
  active: { type: Boolean, default: true, index: true }
}, { timestamps: true, collection: 'warnings' })

schema.index({ sessionId: 1, groupJid: 1, userJid: 1, active: 1 })

export const Warning = mongoose.models.Warning || mongoose.model('Warning', schema)
