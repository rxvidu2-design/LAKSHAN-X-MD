import mongoose from 'mongoose'
import { env } from '../config/env.js'

const schema = new mongoose.Schema({
  timestamp: { type: Date, default: Date.now, index: true },
  level: { type: String, enum: ['info', 'warn', 'error', 'audit'], default: 'info', index: true },
  sessionId: { type: String, index: true },
  user: { type: String, index: true },
  group: { type: String, index: true },
  command: { type: String, index: true },
  status: { type: String, index: true },
  responseTime: Number,
  error: String,
  message: String,
  metadata: { type: mongoose.Schema.Types.Mixed, default: {} },
  expiresAt: { type: Date, default: () => new Date(Date.now() + env.logRetentionDays * 86400000), index: true }
}, { timestamps: true, collection: 'logs' })

schema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 })
schema.index({ sessionId: 1, timestamp: -1 })
schema.index({ command: 1, timestamp: -1 })

export const Log = mongoose.models.Log || mongoose.model('Log', schema)
