import mongoose from 'mongoose'

const schema = new mongoose.Schema({
  key: { type: String, required: true, unique: true, index: true },
  sessionId: { type: String, index: true },
  mimeType: String,
  size: Number,
  url: String,
  data: { type: Buffer, select: false },
  metadata: { type: mongoose.Schema.Types.Mixed, default: {} },
  expiresAt: { type: Date, required: true, index: true }
}, { timestamps: true, collection: 'mediaCache' })

schema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 })

export const MediaCache = mongoose.models.MediaCache || mongoose.model('MediaCache', schema)
