import mongoose from 'mongoose'

const schema = new mongoose.Schema({
  sessionId: { type: String, required: true, index: true },
  jid: { type: String, required: true, index: true },
  subject: { type: String, trim: true },
  description: String,
  ownerJid: String,
  participantsCount: { type: Number, default: 0 },
  active: { type: Boolean, default: true, index: true },
  lastSeenAt: Date
}, { timestamps: true, collection: 'groups' })

schema.index({ sessionId: 1, jid: 1 }, { unique: true })

export const Group = mongoose.models.Group || mongoose.model('Group', schema)
