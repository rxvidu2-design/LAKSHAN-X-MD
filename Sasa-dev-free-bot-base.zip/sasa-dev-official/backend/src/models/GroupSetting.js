import mongoose from 'mongoose'

const schema = new mongoose.Schema({
  sessionId: { type: String, required: true, index: true },
  groupJid: { type: String, required: true, index: true },
  prefix: { type: String, default: '.', maxlength: 5 },
  welcome: { type: Boolean, default: false },
  farewell: { type: Boolean, default: false },
  antiLink: { type: Boolean, default: false },
  antiSpam: { type: Boolean, default: false },
  antiBadWord: { type: Boolean, default: false },
  antiDelete: { type: Boolean, default: false },
  antiViewOnce: { type: Boolean, default: false },
  antiMention: { type: Boolean, default: false },
  antiFlood: { type: Boolean, default: false },
  autoReact: { type: Boolean, default: false },
  autoRead: { type: Boolean, default: false },
  autoTyping: { type: Boolean, default: false },
  autoRecord: { type: Boolean, default: false },
  chatbot: { type: Boolean, default: false },
  welcomeImage: { type: Boolean, default: false },
  farewellImage: { type: Boolean, default: false },
  badWords: [{ type: String, lowercase: true, trim: true }],
  allowedDomains: [{ type: String, lowercase: true, trim: true }],
  broadcastOptIn: { type: Boolean, default: false },
  updatedBy: String
}, { timestamps: true, collection: 'groupSettings' })

schema.index({ sessionId: 1, groupJid: 1 }, { unique: true })

export const GroupSetting = mongoose.models.GroupSetting || mongoose.model('GroupSetting', schema)
