import mongoose from 'mongoose'

const schema = new mongoose.Schema({
  userJid: { type: String, required: true, index: true },
  sessionId: { type: String, required: true, index: true },
  plan: { type: String, default: 'premium' },
  active: { type: Boolean, default: true, index: true },
  startsAt: { type: Date, default: Date.now },
  expiresAt: { type: Date, required: true, index: true },
  grantedBy: String
}, { timestamps: true, collection: 'premium' })

schema.index({ sessionId: 1, userJid: 1 }, { unique: true })

export const Premium = mongoose.models.Premium || mongoose.model('Premium', schema)
