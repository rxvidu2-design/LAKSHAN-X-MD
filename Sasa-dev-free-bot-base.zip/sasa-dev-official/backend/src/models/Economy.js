import mongoose from 'mongoose'

const schema = new mongoose.Schema({
  sessionId: { type: String, required: true, index: true },
  userJid: { type: String, required: true, index: true },
  balance: { type: Number, default: 0, min: 0 },
  bank: { type: Number, default: 0, min: 0 },
  experience: { type: Number, default: 0, min: 0 },
  level: { type: Number, default: 1, min: 1 },
  lastDailyAt: Date
}, { timestamps: true, collection: 'economy' })

schema.index({ sessionId: 1, userJid: 1 }, { unique: true })

export const Economy = mongoose.models.Economy || mongoose.model('Economy', schema)
