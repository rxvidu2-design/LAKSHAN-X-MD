import mongoose from 'mongoose'

const schema = new mongoose.Schema({
  sessionId: { type: String, required: true, index: true },
  userJid: { type: String, required: true, index: true },
  reason: { type: String, default: 'AFK', maxlength: 300 },
  since: { type: Date, default: Date.now },
  active: { type: Boolean, default: true }
}, { timestamps: true, collection: 'afk' })

schema.index({ sessionId: 1, userJid: 1 }, { unique: true })

export const Afk = mongoose.models.Afk || mongoose.model('Afk', schema)
