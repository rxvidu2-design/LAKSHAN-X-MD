import mongoose from 'mongoose'

const encryptedSchema = new mongoose.Schema({
  iv: { type: String, required: true },
  tag: { type: String, required: true },
  data: { type: String, required: true },
  version: { type: Number, default: 1 }
}, { _id: false })

const schema = new mongoose.Schema({
  sessionId: { type: String, required: true, index: true },
  type: { type: String, required: true, index: true },
  keyId: { type: String, required: true },
  value: { type: encryptedSchema, required: true, select: false }
}, { timestamps: true, collection: 'authKeys' })

schema.index({ sessionId: 1, type: 1, keyId: 1 }, { unique: true })

export const AuthKey = mongoose.models.AuthKey || mongoose.model('AuthKey', schema)
