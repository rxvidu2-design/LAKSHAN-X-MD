import mongoose from 'mongoose'

const schema = new mongoose.Schema({
  sessionId: { type: String, required: true, index: true },
  groupJid: { type: String, required: true, index: true },
  enabled: { type: Boolean, default: false },
  message: { type: String, default: 'Welcome {user} to {group}.', maxlength: 2000 },
  imageUrl: String
}, { timestamps: true, collection: 'welcome' })

schema.index({ sessionId: 1, groupJid: 1 }, { unique: true })

export const Welcome = mongoose.models.Welcome || mongoose.model('Welcome', schema)
