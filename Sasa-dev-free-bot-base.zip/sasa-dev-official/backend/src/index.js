import http from 'node:http'
import { Server as SocketServer } from 'socket.io'
import { createApplication } from './app.js'
import { env } from './config/env.js'
import { logger } from './config/logger.js'
import { connectDatabase, closeDatabase, databaseEvents, isDatabaseReady } from './database/connection.js'
import { bootstrapAdministrator } from './services/adminService.js'
import { commandRegistry } from './services/commandRegistry.js'
import { SessionManager } from './services/sessionManager.js'
import { configureSocketServer } from './services/socketServer.js'

await commandRegistry.load()
const sessionManager = new SessionManager({ io: null, registry: commandRegistry })
const app = createApplication({ registry: commandRegistry, sessionManager })
const server = http.createServer(app)
const io = new SocketServer(server, {
  cors: { origin: env.isProduction ? env.corsOrigins : true, credentials: true },
  transports: ['websocket', 'polling'],
  maxHttpBufferSize: 100000
})
sessionManager.io = io
configureSocketServer(io)

let serverReady = false
let databaseInitialization = null
const initializeDatabaseServices = async () => {
  if (databaseInitialization) return databaseInitialization
  databaseInitialization = (async () => {
    await bootstrapAdministrator().catch(error => logger.error({ err: error }, 'Administrator bootstrap failed'))
    await commandRegistry.syncDatabase().catch(error => logger.error({ err: error }, 'Command database synchronization failed'))
    if (serverReady) await sessionManager.restoreSessions().catch(error => logger.error({ err: error }, 'Session restoration failed'))
  })().finally(() => { databaseInitialization = null })
  return databaseInitialization
}
databaseEvents.on('connected', () => initializeDatabaseServices().catch(error => logger.error({ err: error }, 'Database service initialization failed')))
const databaseConnected = await connectDatabase()
if (databaseConnected) await initializeDatabaseServices()

await new Promise((resolve, reject) => {
  server.once('error', reject)
  server.listen(env.port, '0.0.0.0', resolve)
})
serverReady = true
logger.info({ port: env.port, environment: env.nodeEnv }, 'Sasa Dev Official server started')

if (isDatabaseReady()) await sessionManager.restoreSessions().catch(error => logger.error({ err: error }, 'Session restoration failed'))

let shuttingDown = false
const shutdown = async signal => {
  if (shuttingDown) return
  shuttingDown = true
  logger.info({ signal }, 'Graceful shutdown started')
  const forceTimer = setTimeout(() => process.exit(1), 15000)
  forceTimer.unref()
  await sessionManager.shutdown().catch(error => logger.error({ err: error }, 'Session shutdown failed'))
  await new Promise(resolve => io.close(resolve))
  await new Promise(resolve => server.close(resolve))
  await closeDatabase().catch(error => logger.error({ err: error }, 'Database shutdown failed'))
  clearTimeout(forceTimer)
  logger.info('Graceful shutdown complete')
  process.exit(0)
}

process.on('SIGTERM', () => shutdown('SIGTERM'))
process.on('SIGINT', () => shutdown('SIGINT'))
process.on('unhandledRejection', error => logger.error({ err: error }, 'Unhandled promise rejection'))
process.on('uncaughtException', error => {
  logger.fatal({ err: error }, 'Uncaught exception')
  shutdown('uncaughtException')
})
