import { normalizeJid } from './validation.js'

export const unwrapMessage = message => {
  let current = message
  for (let depth = 0; depth < 5 && current; depth += 1) {
    if (current.ephemeralMessage?.message) current = current.ephemeralMessage.message
    else if (current.viewOnceMessage?.message) current = current.viewOnceMessage.message
    else if (current.viewOnceMessageV2?.message) current = current.viewOnceMessageV2.message
    else if (current.documentWithCaptionMessage?.message) current = current.documentWithCaptionMessage.message
    else break
  }
  return current || {}
}

export const messageType = message => Object.keys(unwrapMessage(message)).find(key => !['messageContextInfo', 'senderKeyDistributionMessage'].includes(key)) || null

export const contextInfo = message => {
  const content = unwrapMessage(message)
  for (const value of Object.values(content)) {
    if (value && typeof value === 'object' && value.contextInfo) return value.contextInfo
  }
  return null
}

export const extractText = message => {
  const content = unwrapMessage(message)
  return String(
    content.conversation ||
    content.extendedTextMessage?.text ||
    content.imageMessage?.caption ||
    content.videoMessage?.caption ||
    content.documentMessage?.caption ||
    content.buttonsResponseMessage?.selectedButtonId ||
    content.listResponseMessage?.singleSelectReply?.selectedRowId ||
    content.templateButtonReplyMessage?.selectedId ||
    content.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson ||
    ''
  ).trim()
}

export const getQuotedMessage = message => {
  const info = contextInfo(message)
  if (!info?.quotedMessage) return null
  return {
    key: {
      remoteJid: info.remoteJid,
      fromMe: false,
      id: info.stanzaId,
      participant: info.participant
    },
    message: info.quotedMessage
  }
}

export const getMentions = message => contextInfo(message)?.mentionedJid || []

export const resolveTargets = ({ message, args = [] }) => {
  const targets = new Set(getMentions(message))
  const quoted = getQuotedMessage(message)
  if (quoted?.key?.participant) targets.add(quoted.key.participant)
  for (const arg of args) {
    const digits = arg.replace(/\D/g, '')
    if (digits.length >= 8 && digits.length <= 15) {
      try { targets.add(normalizeJid(digits)) } catch {}
    }
  }
  return [...targets]
}

export const jidNumber = jid => String(jid || '').split('@')[0].split(':')[0].replace(/\D/g, '')
export const isGroupJid = jid => String(jid || '').endsWith('@g.us')

export const participantMatches = (participant, jid) => {
  const candidates = [participant?.id, participant?.phoneNumber, participant?.lid].filter(Boolean)
  return candidates.includes(jid) || candidates.some(candidate => jidNumber(candidate) === jidNumber(jid))
}
