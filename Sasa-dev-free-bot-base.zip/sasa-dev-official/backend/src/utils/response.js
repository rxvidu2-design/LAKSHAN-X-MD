export const success = (res, data = null, message = 'Success', statusCode = 200, meta = undefined) => {
  const body = { success: true, message, data }
  if (meta !== undefined) body.meta = meta
  return res.status(statusCode).json(body)
}

export const failure = (res, message, error, statusCode = 500, details = undefined) => {
  const body = { success: false, message, error }
  if (details !== undefined) body.details = details
  return res.status(statusCode).json(body)
}
