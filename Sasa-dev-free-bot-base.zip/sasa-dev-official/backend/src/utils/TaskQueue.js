export class TaskQueue {
  constructor(concurrency = 2, maxPending = 50) {
    this.concurrency = concurrency
    this.maxPending = maxPending
    this.active = 0
    this.pending = []
  }

  add(task) {
    if (this.pending.length >= this.maxPending) return Promise.reject(new Error('Task queue is full'))
    return new Promise((resolve, reject) => {
      this.pending.push({ task, resolve, reject })
      this.drain()
    })
  }

  drain() {
    while (this.active < this.concurrency && this.pending.length) {
      const entry = this.pending.shift()
      this.active += 1
      Promise.resolve()
        .then(entry.task)
        .then(entry.resolve, entry.reject)
        .finally(() => {
          this.active -= 1
          this.drain()
        })
    }
  }

  get size() {
    return this.pending.length
  }
}
