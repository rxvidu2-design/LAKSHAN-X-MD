import { AppError } from './AppError.js'

export const normalizePhoneNumber = input => {
  const value = String(input || '').replace(/[\s()+-]/g, '')
  if (!/^\d{8,15}$/.test(value)) throw new AppError('Enter a valid phone number with country code', 400, 'INVALID_PHONE_NUMBER')
  return value
}

export const normalizeJid = input => {
  const value = String(input || '').trim()
  if (value.endsWith('@g.us') || value.endsWith('@s.whatsapp.net') || value.endsWith('@lid')) return value
  const number = normalizePhoneNumber(value)
  return `${number}@s.whatsapp.net`
}

export const safeText = (input, max = 4000) => String(input ?? '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '').trim().slice(0, max)
export const isHttpUrl = input => {
  try {
    const url = new URL(input)
    return ['http:', 'https:'].includes(url.protocol)
  } catch {
    return false
  }
}
