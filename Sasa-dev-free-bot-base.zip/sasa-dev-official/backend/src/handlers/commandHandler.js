import { Ban, Command, Group, Session, Setting, UserData, Log } from '../models/index.js'
import { env } from '../config/env.js'
import { logger } from '../config/logger.js'
import { AppError } from '../utils/AppError.js'
import { contextInfo, extractText, isGroupJid, jidNumber, participantMatches, unwrapMessage } from '../utils/message.js'
import { messagePolicy } from '../services/messagePolicy.js'
import { chatCompletion } from '../services/aiService.js'

const tokenize = input => {
  const tokens = []
  const pattern = /"([^"\\]*(?:\\.[^"\\]*)*)"|'([^'\\]*(?:\\.[^'\\]*)*)'|([^\s]+)/g
  let match
  while ((match = pattern.exec(input))) tokens.push((match[1] ?? match[2] ?? match[3]).replace(/\\([\\"'])/g, '$1'))
  return tokens
}

const senderFor = (sock, message) => {
  if (message.key.fromMe) return message.key.participantAlt || message.key.participant || sock.user?.id || message.key.remoteJid
  if (isGroupJid(message.key.remoteJid)) return message.key.participantAlt || message.key.participant || message.participant || message.key.remoteJid
  return message.key.remoteJidAlt || message.key.remoteJid
}

const splitMessage = (text, limit = 3500) => {
  const parts = []
  let remaining = String(text)
  while (remaining.length > limit) {
    let index = remaining.lastIndexOf('\n', limit)
    if (index < limit * 0.55) index = remaining.lastIndexOf(' ', limit)
    if (index < limit * 0.55) index = limit
    parts.push(remaining.slice(0, index).trim())
    remaining = remaining.slice(index).trim()
  }
  if (remaining) parts.push(remaining)
  return parts
}

const permissionCheck = (command, context) => {
  if (['group', 'admin'].includes(command.permission) && !context.isGroup) throw new AppError('This command can only be used in a group', 403, 'GROUP_ONLY_COMMAND')
  if (command.permission === 'admin' && !context.isAdmin && !context.isOwner) throw new AppError('Group administrator permission is required', 403, 'GROUP_ADMIN_REQUIRED')
  if (command.permission === 'owner' && !context.isOwner) throw new AppError('This command is restricted to the bot owner', 403, 'OWNER_ONLY_COMMAND')
  if (command.permission === 'sudo' && !context.isOwner && !context.isSudo) throw new AppError('This command requires sudo permission', 403, 'SUDO_REQUIRED')
}

const activeBan = async context => {
  if (context.isOwner) return null
  const scopes = [{ scope: 'session', groupJid: null }, { scope: 'global' }]
  if (context.isGroup) scopes.push({ scope: 'group', groupJid: context.chatJid })
  return Ban.findOne({
    sessionId: context.session.sessionId,
    targetJid: { $in: [context.senderJid, context.senderNumber ? `${context.senderNumber}@s.whatsapp.net` : context.senderJid] },
    active: true,
    $and: [
      { $or: scopes },
      { $or: [{ expiresAt: null }, { expiresAt: { $gt: new Date() } }] }
    ]
  }).lean()
}

export class CommandHandler {
  constructor({ registry, sessionManager }) {
    this.registry = registry
    this.sessionManager = sessionManager
    this.cooldowns = new Map()
    this.chatbotCooldowns = new Map()
    this.globalSettingsCache = { value: {}, expiresAt: 0 }
    const timer = setInterval(() => this.cleanupCooldowns(), 5 * 60_000)
    timer.unref()
  }

  cleanupCooldowns() {
    const now = Date.now()
    for (const [key, expires] of this.cooldowns) if (expires <= now) this.cooldowns.delete(key)
    for (const [key, expires] of this.chatbotCooldowns) if (expires <= now) this.chatbotCooldowns.delete(key)
  }

  async getGlobalSettings() {
    if (this.globalSettingsCache.expiresAt > Date.now()) return this.globalSettingsCache.value
    const documents = await Setting.find({ scope: 'global', scopeId: 'global', key: { $in: ['defaultPrefix', 'maintenanceMode', 'supportMessage'] } }).lean()
    const value = Object.fromEntries(documents.map(setting => [setting.key, setting.value]))
    this.globalSettingsCache = { value, expiresAt: Date.now() + 30000 }
    return value
  }

  async handleUpsert(session, sock, event) {
    if (event.type !== 'notify') return
    for (const message of event.messages) {
      try {
        await this.handleMessage(session, sock, message)
      } catch (error) {
        const safe = error instanceof AppError || error.isOperational
        if (safe && message.key?.remoteJid) {
          await sock.sendMessage(message.key.remoteJid, { text: `Command failed: ${error.message}\nCode: ${error.code}` }, { quoted: message }).catch(() => {})
        }
        const fields = { err: error, sessionId: session.sessionId, messageId: message.key?.id }
        if (safe) logger.warn(fields, 'Message request rejected')
        else logger.error(fields, 'Message handler failed')
      }
    }
  }

  async handleMessage(session, sock, message) {
    if (!message.message || message.key.remoteJid === 'status@broadcast' || message.key.remoteJid?.endsWith('@newsletter')) return
    const receivedAt = Date.now()
    const chatJid = message.key.remoteJid
    const senderJid = senderFor(sock, message)
    const senderName = message.pushName || jidNumber(senderJid) || 'WhatsApp user'
    const isGroup = isGroupJid(chatJid)
    let groupMetadata = null
    if (isGroup) groupMetadata = await sock.groupMetadata(chatJid).catch(() => null)

    const protocol = unwrapMessage(message.message).protocolMessage
    if (protocol) {
      await messagePolicy.handleProtocolMessage({ sessionId: session.sessionId, sock, message })
      return
    }

    const policy = await messagePolicy.process({ sessionId: session.sessionId, sock, message, senderJid, groupMetadata })
    if (policy.blocked) return

    const content = extractText(message.message)
    await Promise.allSettled([
      Session.updateOne({ sessionId: session.sessionId }, { $inc: { 'stats.messagesReceived': 1 } }),
      UserData.findOneAndUpdate({ sessionId: session.sessionId, jid: senderJid }, { $set: { phoneNumber: jidNumber(senderJid), displayName: senderName, lastSeenAt: new Date() }, $inc: { messages: 1 } }, { upsert: true, setDefaultsOnInsert: true }),
      isGroup && groupMetadata ? Group.findOneAndUpdate({ sessionId: session.sessionId, jid: chatJid }, { $set: { subject: groupMetadata.subject, description: groupMetadata.desc, ownerJid: groupMetadata.ownerPn || groupMetadata.owner, participantsCount: groupMetadata.participants.length, active: true, lastSeenAt: new Date() } }, { upsert: true }) : Promise.resolve()
    ])

    const globalSettings = await this.getGlobalSettings()
    const prefix = policy.settings?.prefix || globalSettings.defaultPrefix || env.botPrefix
    if (!content.startsWith(prefix)) {
      await this.handleChatbot({ session, sock, message, content, chatJid, senderJid, isGroup, settings: policy.settings })
      return
    }

    const tokens = tokenize(content.slice(prefix.length).trim())
    const invoked = tokens.shift()?.toLowerCase()
    if (!invoked) return
    const command = this.registry.get(invoked)
    if (!command) {
      await sock.sendMessage(chatJid, { text: `Unknown command: ${invoked}. Use ${prefix}menu to view available commands.` }, { quoted: message })
      return
    }
    if (!this.registry.isEnabled(command.name)) throw new AppError('This command is disabled by an administrator', 403, 'COMMAND_DISABLED')

    const participant = groupMetadata?.participants?.find(item => participantMatches(item, senderJid))
    const isAdmin = Boolean(participant && ['admin', 'superadmin'].includes(participant.admin))
    let senderNumber = jidNumber(senderJid)
    if (String(senderJid).endsWith('@lid') && typeof sock.signalRepository?.lidMapping?.getPNForLID === 'function') {
      try {
        const phoneJid = await sock.signalRepository.lidMapping.getPNForLID(senderJid)
        if (phoneJid) senderNumber = jidNumber(phoneJid)
      } catch {}
    }
    const connectedNumber = jidNumber(sock.user?.id)
    const isOwner = message.key.fromMe || senderNumber === env.botOwnerNumber || (connectedNumber && senderNumber === connectedNumber)
    if (globalSettings.maintenanceMode && !isOwner) throw new AppError('The bot is temporarily in maintenance mode', 503, 'MAINTENANCE_MODE')
    const sudoSetting = isOwner ? null : await Setting.findOne({ scope: 'global', scopeId: 'global', key: 'sudoNumbers' }).lean()
    const isSudo = Array.isArray(sudoSetting?.value) && sudoSetting.value.includes(senderNumber)
    const baseContext = { session, sock, message, chatJid, senderJid, senderNumber, senderName, isGroup, groupMetadata, isAdmin, isOwner, isSudo }
    permissionCheck(command, baseContext)
    const ban = await activeBan(baseContext)
    if (ban) throw new AppError(`You are not allowed to use bot commands${ban.reason ? `: ${ban.reason}` : ''}`, 403, 'USER_BANNED')

    const cooldownKey = `${session.sessionId}:${senderJid}:${command.name}`
    const cooldownUntil = this.cooldowns.get(cooldownKey) || 0
    if (cooldownUntil > Date.now() && !isOwner) throw new AppError(`Wait ${Math.ceil((cooldownUntil - Date.now()) / 1000)} second(s) before using this command again`, 429, 'COMMAND_COOLDOWN')
    this.cooldowns.set(cooldownKey, Date.now() + command.cooldown * 1000)

    const send = async payload => {
      const response = await sock.sendMessage(chatJid, payload, { quoted: message })
      await Session.updateOne({ sessionId: session.sessionId }, { $inc: { 'stats.messagesSent': 1 } }).catch(() => {})
      return response
    }
    const reply = async text => {
      let response
      for (const part of splitMessage(text)) response = await send({ text: part })
      return response
    }
    const context = {
      ...baseContext,
      command,
      args: tokens,
      text: tokens.join(' '),
      rawText: content,
      prefix,
      globalSettings,
      receivedAt,
      registry: this.registry,
      sessionManager: this.sessionManager,
      send,
      reply
    }

    const started = Date.now()
    let status = 'success'
    let failure = null
    try {
      await command.execute(context)
    } catch (error) {
      status = 'failed'
      failure = error
      const safe = error instanceof AppError || error.isOperational
      await reply(`Command failed: ${safe ? error.message : 'An unexpected error occurred'}\nCode: ${safe ? error.code : 'COMMAND_FAILED'}`).catch(() => {})
      if (!safe) logger.error({ err: error, command: command.name, sessionId: session.sessionId }, 'Command execution failed')
    }
    const responseTime = Date.now() - started
    await this.recordExecution({ context, status, responseTime, failure })
  }

  async handleChatbot({ session, sock, message, content, chatJid, senderJid, isGroup, settings }) {
    if (!isGroup || !settings?.chatbot || !content || message.key.fromMe) return
    const mentions = contextInfo(message.message)?.mentionedJid || []
    const botNumber = jidNumber(sock.user?.id)
    if (!mentions.some(jid => jidNumber(jid) === botNumber)) return
    const key = `${session.sessionId}:${senderJid}`
    if ((this.chatbotCooldowns.get(key) || 0) > Date.now()) return
    this.chatbotCooldowns.set(key, Date.now() + 15000)
    const prompt = content.replace(/@\d+/g, '').trim()
    if (!prompt) return
    try {
      await sock.sendPresenceUpdate('composing', chatJid)
      const response = await chatCompletion({ prompt })
      await sock.sendMessage(chatJid, { text: response.slice(0, 3500) }, { quoted: message })
    } catch (error) {
      logger.warn({ err: error, sessionId: session.sessionId }, 'Group chatbot response failed')
    }
  }

  async recordExecution({ context, status, responseTime, failure }) {
    const success = status === 'success'
    const error = failure ? String(failure.message || failure).slice(0, 1000) : null
    await Promise.allSettled([
      Log.create({ timestamp: new Date(), level: success ? 'info' : 'error', sessionId: context.session.sessionId, user: context.senderJid, group: context.isGroup ? context.chatJid : null, command: context.command.name, status, responseTime, error }),
      Session.updateOne({ sessionId: context.session.sessionId }, { $inc: { 'stats.commandsExecuted': 1, ...(success ? {} : { 'stats.commandsFailed': 1 }) } }),
      UserData.updateOne({ sessionId: context.session.sessionId, jid: context.senderJid }, { $inc: { commands: 1 } }),
      Command.updateOne({ name: context.command.name }, [{ $set: {
        averageResponseTime: { $divide: [{ $add: [{ $multiply: [{ $ifNull: ['$averageResponseTime', 0] }, { $ifNull: ['$executions', 0] }] }, responseTime] }, { $add: [{ $ifNull: ['$executions', 0] }, 1] }] },
        executions: { $add: [{ $ifNull: ['$executions', 0] }, 1] },
        successes: { $add: [{ $ifNull: ['$successes', 0] }, success ? 1 : 0] },
        failures: { $add: [{ $ifNull: ['$failures', 0] }, success ? 0 : 1] },
        lastUsedAt: new Date()
      } }])
    ])
  }
}
