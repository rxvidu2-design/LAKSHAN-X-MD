import mongoose from 'mongoose'
import { EventEmitter } from 'node:events'
import { env } from '../config/env.js'
import { logger } from '../config/logger.js'

const state = {
  status: 'disconnected',
  connectedAt: null,
  lastError: null,
  host: null,
  retryAttempt: 0
}
let retryTimer = null
let closing = false
export const databaseEvents = new EventEmitter()

mongoose.set('strictQuery', true)
mongoose.set('bufferCommands', false)

export const databaseState = () => ({ ...state, readyState: mongoose.connection.readyState })
export const isDatabaseReady = () => mongoose.connection.readyState === 1

const scheduleRetry = () => {
  if (closing || retryTimer || !env.isConfigured(env.mongodbUri)) return
  state.retryAttempt += 1
  const delay = Math.min(60000, 5000 * (2 ** Math.min(state.retryAttempt - 1, 4)))
  retryTimer = setTimeout(async () => {
    retryTimer = null
    await connectDatabase()
  }, delay)
  retryTimer.unref()
  logger.warn({ attempt: state.retryAttempt, retryInMs: delay }, 'MongoDB reconnect scheduled')
}

export const connectDatabase = async () => {
  if (isDatabaseReady()) return true
  if (state.status === 'connecting') return false
  if (!env.isConfigured(env.mongodbUri)) {
    state.status = 'unconfigured'
    state.lastError = 'MONGODB_URI is not configured'
    logger.warn('MongoDB is not configured; the API will run in degraded mode')
    return false
  }

  state.status = 'connecting'
  try {
    await mongoose.connect(env.mongodbUri, {
      serverSelectionTimeoutMS: 10000,
      connectTimeoutMS: 10000,
      socketTimeoutMS: 45000,
      maxPoolSize: 20,
      minPoolSize: 0,
      maxIdleTimeMS: 60000,
      retryWrites: true
    })
    state.status = 'connected'
    state.connectedAt = new Date().toISOString()
    state.lastError = null
    state.host = mongoose.connection.host
    state.retryAttempt = 0
    if (retryTimer) {
      clearTimeout(retryTimer)
      retryTimer = null
    }
    logger.info({ host: state.host }, 'MongoDB connected')
    databaseEvents.emit('connected')
    return true
  } catch (error) {
    state.status = 'unavailable'
    state.lastError = error.message
    logger.error({ err: error }, 'MongoDB connection failed; continuing in degraded mode')
    scheduleRetry()
    return false
  }
}

mongoose.connection.on('disconnected', () => {
  state.status = 'disconnected'
  logger.warn('MongoDB disconnected')
  scheduleRetry()
})
mongoose.connection.on('reconnected', () => {
  state.status = 'connected'
  state.connectedAt = new Date().toISOString()
  state.lastError = null
  state.retryAttempt = 0
  logger.info('MongoDB reconnected')
  databaseEvents.emit('connected')
})
mongoose.connection.on('error', error => {
  state.lastError = error.message
  logger.error({ err: error }, 'MongoDB runtime error')
})

export const closeDatabase = async () => {
  closing = true
  if (retryTimer) {
    clearTimeout(retryTimer)
    retryTimer = null
  }
  if (mongoose.connection.readyState !== 0) await mongoose.connection.close(false)
  state.status = 'disconnected'
}
