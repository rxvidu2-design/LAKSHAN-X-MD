import dns from 'node:dns/promises'
import net from 'node:net'
import { Agent, fetch as pinnedFetch } from 'undici'
import { AppError } from '../utils/AppError.js'
import { env } from '../config/env.js'

const isPrivateIpv4 = address => {
  const parts = address.split('.').map(Number)
  if (parts.length !== 4 || parts.some(part => !Number.isInteger(part))) return true
  const [a, b] = parts
  return a === 0 || a === 10 || a === 127 || a >= 224 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127)
}

const isPrivateIpv6 = address => {
  const value = address.toLowerCase().split('%')[0]
  return value === '::' || value === '::1' || value.startsWith('fc') || value.startsWith('fd') || value.startsWith('fe8') || value.startsWith('fe9') || value.startsWith('fea') || value.startsWith('feb') || value.startsWith('ff') || value.startsWith('::ffff:127.') || value.startsWith('::ffff:10.') || value.startsWith('::ffff:192.168.')
}

export const assertPublicHostname = async hostname => {
  const normalized = String(hostname).toLowerCase().replace(/\.$/, '')
  if (!normalized || normalized === 'localhost' || normalized.endsWith('.localhost') || normalized.endsWith('.local') || normalized.endsWith('.internal')) {
    throw new AppError('Private network addresses are not allowed', 400, 'PRIVATE_ADDRESS_BLOCKED')
  }
  if (net.isIP(normalized)) {
    const blocked = net.isIPv4(normalized) ? isPrivateIpv4(normalized) : isPrivateIpv6(normalized)
    if (blocked) throw new AppError('Private network addresses are not allowed', 400, 'PRIVATE_ADDRESS_BLOCKED')
    return [normalized]
  }
  let records
  try {
    records = await dns.lookup(normalized, { all: true, verbatim: true })
  } catch {
    throw new AppError('The host name could not be resolved', 400, 'DNS_LOOKUP_FAILED')
  }
  if (!records.length || records.some(record => record.family === 4 ? isPrivateIpv4(record.address) : isPrivateIpv6(record.address))) {
    throw new AppError('Private network addresses are not allowed', 400, 'PRIVATE_ADDRESS_BLOCKED')
  }
  return records.map(record => record.address)
}

export const validatePublicUrl = async input => {
  let url
  try {
    url = new URL(String(input))
  } catch {
    throw new AppError('Enter a valid URL', 400, 'INVALID_URL')
  }
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) {
    throw new AppError('Only public HTTP and HTTPS URLs are allowed', 400, 'INVALID_URL_PROTOCOL')
  }
  await assertPublicHostname(url.hostname)
  return url
}

const createPinnedAgent = addresses => {
  let cursor = 0
  return new Agent({
    connect: {
      lookup(hostname, options, callback) {
        const records = addresses.map(address => ({ address, family: net.isIPv6(address) ? 6 : 4 }))
        if (options?.all) return callback(null, records)
        const record = records[cursor++ % records.length]
        callback(null, record.address, record.family)
      }
    }
  })
}

const withTimeout = (timeoutMs, parentSignal) => {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(new Error('Request timeout')), timeoutMs)
  if (parentSignal) parentSignal.addEventListener('abort', () => controller.abort(parentSignal.reason), { once: true })
  return { signal: controller.signal, done: () => clearTimeout(timer) }
}

export const safeFetch = async (input, options = {}) => {
  let url = await validatePublicUrl(input)
  const maxRedirects = options.maxRedirects ?? 3
  const timeoutMs = options.timeoutMs ?? env.apiTimeoutMs
  for (let redirects = 0; redirects <= maxRedirects; redirects += 1) {
    const addresses = await assertPublicHostname(url.hostname)
    const dispatcher = createPinnedAgent(addresses)
    const timer = withTimeout(timeoutMs, options.signal)
    let response
    try {
      response = await pinnedFetch(url, { ...options, dispatcher, signal: timer.signal, redirect: 'manual' })
    } catch (error) {
      await dispatcher.close().catch(() => {})
      if (timer.signal.aborted) throw new AppError('The remote request timed out', 504, 'REMOTE_TIMEOUT')
      throw new AppError(`Remote request failed: ${error.message}`, 502, 'REMOTE_REQUEST_FAILED')
    } finally {
      timer.done()
    }
    if (![301, 302, 303, 307, 308].includes(response.status)) {
      dispatcher.close().catch(() => {})
      return response
    }
    await response.body?.cancel().catch(() => {})
    await dispatcher.close().catch(() => {})
    const location = response.headers.get('location')
    if (!location || redirects === maxRedirects) throw new AppError('Too many remote redirects', 502, 'REMOTE_REDIRECT_LIMIT')
    url = await validatePublicUrl(new URL(location, url).toString())
  }
  throw new AppError('Remote request failed', 502, 'REMOTE_REQUEST_FAILED')
}

export const fetchBuffer = async (url, options = {}) => {
  const maxBytes = options.maxBytes ?? env.maxMediaMb * 1024 * 1024
  const response = await safeFetch(url, options)
  if (!response.ok) throw new AppError(`Remote server returned HTTP ${response.status}`, 502, 'REMOTE_HTTP_ERROR')
  const declared = Number(response.headers.get('content-length') || 0)
  if (declared > maxBytes) throw new AppError('Remote file exceeds the configured size limit', 413, 'MEDIA_TOO_LARGE')
  const reader = response.body.getReader()
  const chunks = []
  let size = 0
  while (true) {
    const { value, done } = await reader.read()
    if (done) break
    size += value.byteLength
    if (size > maxBytes) {
      await reader.cancel()
      throw new AppError('Remote file exceeds the configured size limit', 413, 'MEDIA_TOO_LARGE')
    }
    chunks.push(Buffer.from(value))
  }
  return { buffer: Buffer.concat(chunks), contentType: response.headers.get('content-type') || 'application/octet-stream', finalUrl: response.url }
}
