import { verifyAccessToken } from './adminService.js'
import { Session, User } from '../models/index.js'
import { logger } from '../config/logger.js'

const cookieValue = (header, name) => {
  const cookies = String(header || '').split(';').map(value => value.trim())
  for (const cookie of cookies) {
    const index = cookie.indexOf('=')
    if (index > 0 && cookie.slice(0, index) === name) return decodeURIComponent(cookie.slice(index + 1))
  }
  return null
}

export const configureSocketServer = io => {
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth?.token || cookieValue(socket.handshake.headers.cookie, 'sasa_access')
      const payload = verifyAccessToken(token)
      const user = await User.findOne({ _id: payload.sub, active: true }).lean()
      if (!user) throw new Error('Invalid user')
      socket.user = user
      next()
    } catch {
      next(new Error('Authentication required'))
    }
  })
  io.on('connection', socket => {
    if (socket.user.role === 'admin') socket.join('administrators')
    socket.on('session:subscribe', async sessionId => {
      if (typeof sessionId !== 'string' || !/^[0-9a-f-]{36}$/i.test(sessionId)) return
      const allowed = socket.user.role === 'admin' || await Session.exists({ sessionId, userId: socket.user._id, active: true })
      if (allowed) socket.join(`session:${sessionId}`)
    })
    socket.on('session:unsubscribe', sessionId => {
      if (typeof sessionId === 'string') socket.leave(`session:${sessionId}`)
    })
    socket.on('disconnect', reason => logger.debug({ socketId: socket.id, reason }, 'Dashboard socket disconnected'))
  })
}
