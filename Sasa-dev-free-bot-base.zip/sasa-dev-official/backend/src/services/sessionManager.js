import { EventEmitter } from 'node:events'
import crypto from 'node:crypto'
import QRCode from 'qrcode'
import { Boom } from '@hapi/boom'
import makeWASocket, { Browsers, DisconnectReason, makeCacheableSignalKeyStore } from '@whiskeysockets/baileys'
import { LRUCache } from 'lru-cache'
import { AuthKey, Bot, Session } from '../models/index.js'
import { env } from '../config/env.js'
import { baileysLogger, logger } from '../config/logger.js'
import { BOT_IDENTITY } from '../config/constants.js'
import { AppError } from '../utils/AppError.js'
import { jidNumber } from '../utils/message.js'
import { normalizePhoneNumber } from '../utils/validation.js'
import { useMongoAuthState } from './mongoAuthState.js'
import { assertSessionEncryption } from './cryptoService.js'
import { CommandHandler } from '../handlers/commandHandler.js'
import { messagePolicy } from './messagePolicy.js'

const reconnectableStatuses = new Set(['connected', 'connecting', 'reconnecting', 'disconnected'])
const wait = milliseconds => new Promise(resolve => setTimeout(resolve, milliseconds))

const disconnectCode = error => {
  if (!error) return null
  try { return new Boom(error).output.statusCode } catch { return error?.output?.statusCode || error?.statusCode || null }
}

export class SessionManager extends EventEmitter {
  constructor({ io, registry }) {
    super()
    this.io = io
    this.registry = registry
    this.runtimes = new Map()
    this.locks = new Map()
    this.recoveryTimers = new Map()
    this.groupCache = new LRUCache({ max: 1000, ttl: 5 * 60_000 })
    this.commandHandler = new CommandHandler({ registry, sessionManager: this })
  }

  async withLock(sessionId, task) {
    const previous = this.locks.get(sessionId) || Promise.resolve()
    let release
    const current = new Promise(resolve => { release = resolve })
    const tail = previous.then(() => current)
    this.locks.set(sessionId, tail)
    await previous
    try { return await task() } finally {
      release()
      if (this.locks.get(sessionId) === tail) this.locks.delete(sessionId)
    }
  }

  runtime(sessionId) {
    return this.runtimes.get(sessionId) || null
  }

  publicSession(document) {
    const source = document?.toObject ? document.toObject() : { ...document }
    delete source.credentials
    delete source.__v
    const runtime = this.runtime(source.sessionId)
    return {
      ...source,
      status: runtime?.status || source.status,
      qr: runtime?.qrDataUrl || null,
      qrExpiresAt: runtime?.qrExpiresAt || null,
      pairCode: runtime?.pairCode || null,
      pairExpiresAt: runtime?.pairExpiresAt || null,
      live: Boolean(runtime?.sock),
      reconnectAttempts: runtime?.reconnectAttempts ?? source.reconnectAttempts
    }
  }

  async listSessions(userId) {
    const filter = userId ? { userId, active: true } : { active: true }
    const sessions = await Session.find(filter).sort({ createdAt: -1 }).select('-credentials').lean()
    return sessions.map(session => this.publicSession(session))
  }

  async getSession(sessionId) {
    const session = await Session.findOne({ sessionId }).select('-credentials').lean()
    if (!session) throw new AppError('Session not found', 404, 'SESSION_NOT_FOUND')
    return this.publicSession(session)
  }

  async createSession({ method, ownerNumber, label, userId }) {
    assertSessionEncryption()
    if (!['qr', 'pair'].includes(method)) throw new AppError('Invalid session method', 400, 'INVALID_SESSION_METHOD')
    const count = await Session.countDocuments({ userId, active: true })
    if (count >= env.maxSessions) throw new AppError(`The maximum of ${env.maxSessions} active sessions has been reached`, 409, 'SESSION_LIMIT_REACHED')
    const sessionId = crypto.randomUUID()
    const botId = `bot_${crypto.randomUUID()}`
    const number = ownerNumber ? normalizePhoneNumber(ownerNumber) : env.botOwnerNumber
    const session = await Session.create({ sessionId, botId, userId, ownerNumber: number, label: label || `${method.toUpperCase()} session`, method, status: method === 'qr' ? 'waiting_qr' : 'waiting_pair', active: true })
    try {
      await Bot.create({ botId, sessionId, name: BOT_IDENTITY.name, ownerName: BOT_IDENTITY.owner, ownerNumber: number, prefix: BOT_IDENTITY.prefix, logoUrl: BOT_IDENTITY.logoUrl, channelUrl: BOT_IDENTITY.channelUrl, status: 'offline' })
    } catch (error) {
      await Session.deleteOne({ sessionId })
      throw error
    }
    return session
  }

  async startQr({ label, ownerNumber, userId }) {
    const session = await this.createSession({ method: 'qr', ownerNumber, label, userId })
    try {
      await this.connect(session.sessionId, { mode: 'qr' })
      return this.getSession(session.sessionId)
    } catch (error) {
      await Session.updateOne({ sessionId: session.sessionId }, { $set: { status: 'failed', disconnectReason: error.message } })
      throw error
    }
  }

  async startPair({ label, phoneNumber, userId }) {
    const phone = normalizePhoneNumber(phoneNumber)
    const session = await this.createSession({ method: 'pair', ownerNumber: phone, label, userId })
    try {
      await this.connect(session.sessionId, { mode: 'pair', phone })
      const pairCode = await this.waitForPairCode(session.sessionId, 35000)
      return { session: await this.getSession(session.sessionId), pairCode }
    } catch (error) {
      await Session.updateOne({ sessionId: session.sessionId }, { $set: { status: 'failed', disconnectReason: error.message } })
      throw error
    }
  }

  waitForPairCode(sessionId, timeoutMs) {
    const runtime = this.runtime(sessionId)
    if (!runtime) throw new AppError('Session runtime is unavailable', 503, 'SESSION_RUNTIME_UNAVAILABLE')
    if (runtime.pairCode) return Promise.resolve(runtime.pairCode)
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        runtime.pairWaiters = runtime.pairWaiters.filter(waiter => waiter.resolve !== resolve)
        reject(new AppError('Pairing code generation timed out', 504, 'PAIR_CODE_TIMEOUT'))
      }, timeoutMs)
      runtime.pairWaiters.push({
        resolve: code => { clearTimeout(timer); resolve(code) },
        reject: error => { clearTimeout(timer); reject(error) }
      })
    })
  }

  async connect(sessionId, { mode = 'restore', phone = null, force = false } = {}) {
    return this.withLock(sessionId, async () => {
      const recoveryTimer = this.recoveryTimers.get(sessionId)
      if (recoveryTimer) {
        clearTimeout(recoveryTimer)
        this.recoveryTimers.delete(sessionId)
      }
      const existing = this.runtime(sessionId)
      if (existing?.sock && !force) return existing
      if (existing) await this.destroyRuntime(existing, false)
      const session = await Session.findOne({ sessionId })
      if (!session || !session.active) throw new AppError('Session not found or inactive', 404, 'SESSION_NOT_FOUND')
      const auth = await useMongoAuthState(sessionId)
      const runtime = {
        sessionId,
        mode,
        phone,
        status: mode === 'pair' ? 'waiting_pair' : mode === 'qr' ? 'waiting_qr' : 'connecting',
        auth,
        sock: null,
        stopped: false,
        generation: crypto.randomUUID(),
        reconnectAttempts: session.reconnectAttempts || 0,
        reconnectTimer: null,
        qrDataUrl: null,
        qrExpiresAt: null,
        pairCode: null,
        pairExpiresAt: null,
        pairRequested: false,
        pairWaiters: []
      }
      this.runtimes.set(sessionId, runtime)

      const sock = makeWASocket({
        auth: { creds: auth.state.creds, keys: makeCacheableSignalKeyStore(auth.state.keys, baileysLogger) },
        logger: baileysLogger,
        browser: Browsers.ubuntu(env.botName),
        markOnlineOnConnect: false,
        syncFullHistory: false,
        emitOwnEvents: true,
        connectTimeoutMs: 60000,
        keepAliveIntervalMs: 20000,
        retryRequestDelayMs: 250,
        generateHighQualityLinkPreview: false,
        getMessage: async () => undefined,
        cachedGroupMetadata: async jid => this.groupCache.get(`${sessionId}:${jid}`)
      })
      runtime.sock = sock
      sock.ev.on('creds.update', () => auth.saveCreds().catch(error => logger.error({ err: error, sessionId }, 'Credential persistence failed')))
      sock.ev.on('connection.update', update => this.handleConnectionUpdate(runtime, update).catch(error => logger.error({ err: error, sessionId }, 'Connection update failed')))
      sock.ev.on('messages.upsert', event => this.commandHandler.handleUpsert(this.publicSession(session.toObject()), sock, event))
      sock.ev.on('group-participants.update', update => messagePolicy.groupParticipants({ sessionId, sock, update }).catch(error => logger.warn({ err: error, sessionId }, 'Group participant event failed')))
      sock.ev.on('groups.update', updates => {
        for (const update of updates) {
          const key = `${sessionId}:${update.id}`
          const cached = this.groupCache.get(key)
          if (cached) this.groupCache.set(key, { ...cached, ...update })
        }
      })
      await Session.updateOne({ sessionId }, { $set: { status: runtime.status, method: mode === 'restore' ? session.method : mode } })
      this.emitSession(runtime)
      return runtime
    })
  }

  async handleConnectionUpdate(runtime, update) {
    if (runtime.stopped || this.runtime(runtime.sessionId)?.generation !== runtime.generation) return
    if (update.connection === 'connecting') {
      runtime.status = runtime.reconnectAttempts ? 'reconnecting' : 'connecting'
      await this.persistStatus(runtime, runtime.status)
    }
    if (update.qr && !runtime.auth.state.creds.registered) {
      if (runtime.mode === 'pair') await this.requestPairCode(runtime)
      else await this.setQr(runtime, update.qr)
    }
    if (update.connection === 'open') {
      runtime.status = 'connected'
      runtime.reconnectAttempts = 0
      runtime.qrDataUrl = null
      runtime.qrExpiresAt = null
      runtime.pairCode = null
      runtime.pairExpiresAt = null
      const jid = runtime.sock.user?.id || null
      const number = jidNumber(jid) || null
      await Promise.all([
        Session.updateOne({ sessionId: runtime.sessionId }, { $set: { status: 'connected', connectedNumber: number, connectedJid: jid, platform: runtime.sock.user?.platform || null, reconnectAttempts: 0, lastConnectedAt: new Date(), disconnectReason: null, active: true } }),
        Bot.updateOne({ sessionId: runtime.sessionId }, { $set: { status: 'online', ownerNumber: number || undefined } })
      ])
      this.resolvePairWaiters(runtime, runtime.pairCode)
      this.emitSession(runtime)
      logger.info({ sessionId: runtime.sessionId, number }, 'WhatsApp session connected')
      return
    }
    if (update.connection === 'close') {
      const code = disconnectCode(update.lastDisconnect?.error)
      const reason = String(update.lastDisconnect?.error?.message || `Disconnect code ${code ?? 'unknown'}`).slice(0, 500)
      if (runtime.stopped) return
      if (code === DisconnectReason.loggedOut) {
        runtime.status = 'logged_out'
        runtime.stopped = true
        this.rejectPairWaiters(runtime, new AppError('WhatsApp session was logged out', 401, 'WHATSAPP_LOGGED_OUT'))
        await Promise.all([
          Session.updateOne({ sessionId: runtime.sessionId }, { $set: { status: 'logged_out', active: true, lastDisconnectedAt: new Date(), disconnectReason: reason } }),
          Bot.updateOne({ sessionId: runtime.sessionId }, { $set: { status: 'logged_out' } })
        ])
        this.emitSession(runtime)
        return
      }
      const immediate = code === DisconnectReason.restartRequired
      runtime.status = 'disconnected'
      await Promise.all([
        Session.updateOne({ sessionId: runtime.sessionId }, { $set: { status: 'disconnected', lastDisconnectedAt: new Date(), disconnectReason: reason } }),
        Bot.updateOne({ sessionId: runtime.sessionId }, { $set: { status: 'offline' } })
      ])
      this.emitSession(runtime)
      await this.scheduleReconnect(runtime, immediate ? 250 : null)
    }
  }

  async setQr(runtime, value) {
    runtime.status = 'waiting_qr'
    runtime.qrDataUrl = await QRCode.toDataURL(value, { width: 420, margin: 2, errorCorrectionLevel: 'M', color: { dark: '#07111f', light: '#ffffff' } })
    runtime.qrExpiresAt = new Date(Date.now() + 60000).toISOString()
    await this.persistStatus(runtime, 'waiting_qr')
    this.emitSession(runtime)
  }

  async requestPairCode(runtime) {
    if (runtime.pairRequested || !runtime.phone) return
    runtime.pairRequested = true
    try {
      await wait(600)
      const code = await runtime.sock.requestPairingCode(runtime.phone)
      runtime.pairCode = String(code)
      runtime.pairExpiresAt = new Date(Date.now() + 5 * 60_000).toISOString()
      runtime.status = 'waiting_pair'
      await this.persistStatus(runtime, 'waiting_pair')
      this.resolvePairWaiters(runtime, runtime.pairCode)
      this.emitSession(runtime)
    } catch (error) {
      runtime.pairRequested = false
      const normalized = new AppError(`Pairing code generation failed: ${error.message}`, 502, 'PAIR_CODE_FAILED')
      this.rejectPairWaiters(runtime, normalized)
      throw normalized
    }
  }

  resolvePairWaiters(runtime, code) {
    if (!code) return
    for (const waiter of runtime.pairWaiters.splice(0)) waiter.resolve(code)
  }

  rejectPairWaiters(runtime, error) {
    for (const waiter of runtime.pairWaiters.splice(0)) waiter.reject(error)
  }

  async persistStatus(runtime, status) {
    runtime.status = status
    await Session.updateOne({ sessionId: runtime.sessionId }, { $set: { status, reconnectAttempts: runtime.reconnectAttempts } })
    this.emitSession(runtime)
  }

  emitSession(runtime) {
    const payload = {
      sessionId: runtime.sessionId,
      status: runtime.status,
      qr: runtime.qrDataUrl,
      qrExpiresAt: runtime.qrExpiresAt,
      pairCode: runtime.pairCode,
      pairExpiresAt: runtime.pairExpiresAt,
      reconnectAttempts: runtime.reconnectAttempts,
      live: Boolean(runtime.sock)
    }
    this.io?.to(`session:${runtime.sessionId}`).emit('session:update', payload)
    this.io?.to('administrators').emit('session:update', payload)
    this.emit('session:update', payload)
  }

  async scheduleReconnect(runtime, customDelay = null) {
    if (runtime.stopped || runtime.reconnectTimer) return
    if (runtime.reconnectAttempts >= 8) {
      runtime.status = 'failed'
      await this.persistStatus(runtime, 'failed')
      this.rejectPairWaiters(runtime, new AppError('Reconnect limit reached', 503, 'RECONNECT_LIMIT_REACHED'))
      return
    }
    runtime.reconnectAttempts += 1
    runtime.status = 'reconnecting'
    const delayMs = customDelay ?? Math.min(60000, 1000 * (2 ** (runtime.reconnectAttempts - 1))) + Math.floor(Math.random() * 500)
    await this.persistStatus(runtime, 'reconnecting')
    runtime.reconnectTimer = setTimeout(async () => {
      runtime.reconnectTimer = null
      if (runtime.stopped) return
      try {
        await this.connect(runtime.sessionId, { mode: 'restore', force: true })
      } catch (error) {
        logger.warn({ err: error, sessionId: runtime.sessionId }, 'WhatsApp reconnect attempt failed')
        const current = this.runtime(runtime.sessionId)
        if (current && !current.stopped) await this.scheduleReconnect(current)
        else await this.scheduleColdReconnect(runtime.sessionId, runtime.reconnectAttempts + 1)
      }
    }, delayMs)
    runtime.reconnectTimer.unref()
  }

  async scheduleColdReconnect(sessionId, attempt) {
    if (this.recoveryTimers.has(sessionId)) return
    if (attempt > 8) {
      await Session.updateOne({ sessionId }, { $set: { status: 'failed', reconnectAttempts: attempt - 1, disconnectReason: 'Reconnect limit reached' } }).catch(() => {})
      return
    }
    await Session.updateOne({ sessionId }, { $set: { status: 'reconnecting', reconnectAttempts: attempt } }).catch(() => {})
    const delayMs = Math.min(60000, 1000 * (2 ** (attempt - 1))) + Math.floor(Math.random() * 500)
    const timer = setTimeout(async () => {
      this.recoveryTimers.delete(sessionId)
      try {
        await this.connect(sessionId, { mode: 'restore', force: true })
      } catch (error) {
        logger.warn({ err: error, sessionId, attempt }, 'Cold reconnect attempt failed')
        await this.scheduleColdReconnect(sessionId, attempt + 1)
      }
    }, delayMs)
    timer.unref()
    this.recoveryTimers.set(sessionId, timer)
  }

  async reconnectSession(sessionId) {
    const session = await Session.findOne({ sessionId })
    if (!session || !session.active) throw new AppError('Session not found or inactive', 404, 'SESSION_NOT_FOUND')
    if (session.status === 'logged_out') throw new AppError('This session was logged out and must be linked again', 409, 'WHATSAPP_LOGGED_OUT')
    const runtime = this.runtime(sessionId)
    if (runtime) runtime.reconnectAttempts = 0
    await this.connect(sessionId, { mode: 'restore', force: true })
    return this.getSession(sessionId)
  }

  async refreshQr(sessionId) {
    const session = await Session.findOne({ sessionId })
    if (!session || session.method !== 'qr' || !session.active) throw new AppError('Active QR session not found', 404, 'QR_SESSION_NOT_FOUND')
    const runtime = this.runtime(sessionId)
    if (runtime?.auth?.state?.creds?.registered) throw new AppError('This session is already registered', 409, 'SESSION_ALREADY_REGISTERED')
    await this.connect(sessionId, { mode: 'qr', force: true })
    return this.getSession(sessionId)
  }

  async stopSession(sessionId) {
    const runtime = this.runtime(sessionId)
    if (runtime) await this.destroyRuntime(runtime, false)
    await Promise.all([
      Session.updateOne({ sessionId }, { $set: { status: 'stopped', active: true, lastDisconnectedAt: new Date() } }),
      Bot.updateOne({ sessionId }, { $set: { status: 'offline' } })
    ])
    return this.getSession(sessionId)
  }

  async destroyRuntime(runtime, logout = false) {
    runtime.stopped = true
    if (runtime.reconnectTimer) clearTimeout(runtime.reconnectTimer)
    this.rejectPairWaiters(runtime, new AppError('Session runtime stopped', 409, 'SESSION_STOPPED'))
    if (runtime.sock) {
      try {
        if (logout && runtime.auth.state.creds.registered) await Promise.race([runtime.sock.logout(), wait(5000)])
        else runtime.sock.end(new Error('Session runtime stopped'))
      } catch {}
      runtime.sock.ev.removeAllListeners()
    }
    this.runtimes.delete(runtime.sessionId)
  }

  async deleteSession(sessionId) {
    const recoveryTimer = this.recoveryTimers.get(sessionId)
    if (recoveryTimer) {
      clearTimeout(recoveryTimer)
      this.recoveryTimers.delete(sessionId)
    }
    const session = await Session.findOne({ sessionId })
    if (!session) throw new AppError('Session not found', 404, 'SESSION_NOT_FOUND')
    const runtime = this.runtime(sessionId)
    if (runtime) await this.destroyRuntime(runtime, true)
    await Promise.all([Bot.deleteOne({ sessionId }), AuthKey.deleteMany({ sessionId }), Session.deleteOne({ sessionId })])
    this.io?.to(`session:${sessionId}`).emit('session:deleted', { sessionId })
    return true
  }

  async restoreSessions() {
    const sessions = await Session.find({ active: true, status: { $in: [...reconnectableStatuses] } }).select('sessionId').lean()
    const results = await Promise.allSettled(sessions.map(session => this.connect(session.sessionId, { mode: 'restore' })))
    const restored = results.filter(result => result.status === 'fulfilled').length
    logger.info({ restored, total: sessions.length }, 'Session restoration complete')
    return { restored, total: sessions.length }
  }

  async shutdown() {
    for (const timer of this.recoveryTimers.values()) clearTimeout(timer)
    this.recoveryTimers.clear()
    const runtimes = [...this.runtimes.values()]
    await Promise.allSettled(runtimes.map(runtime => this.destroyRuntime(runtime, false)))
  }
}
