import { LRUCache } from 'lru-cache'
import { AntiLink, Farewell, Group, GroupSetting, Welcome } from '../models/index.js'
import { extractText, isGroupJid, jidNumber, participantMatches, unwrapMessage } from '../utils/message.js'
import { logger } from '../config/logger.js'
import { createQuoteCard } from './mediaService.js'

const linkPattern = /https?:\/\/[^\s]+|(?:chat\.whatsapp\.com|whatsapp\.com\/channel)\/[^\s]+/i
const recentMessages = new LRUCache({ max: 5000, ttl: 30 * 60 * 1000 })
const activity = new Map()

const keyFor = (sessionId, messageId) => `${sessionId}:${messageId}`
const isAdministrator = (metadata, jid) => metadata?.participants?.some(participant => participantMatches(participant, jid) && ['admin', 'superadmin'].includes(participant.admin))

export class MessagePolicy {
  async settings(sessionId, groupJid) {
    return await GroupSetting.findOne({ sessionId, groupJid }).lean() || null
  }

  cache(sessionId, message) {
    if (message.key?.id && message.message) recentMessages.set(keyFor(sessionId, message.key.id), message)
  }

  async process({ sessionId, sock, message, senderJid, groupMetadata }) {
    if (!isGroupJid(message.key.remoteJid)) return { blocked: false, settings: null }
    const settings = await this.settings(sessionId, message.key.remoteJid)
    if (!settings) {
      this.cache(sessionId, message)
      return { blocked: false, settings: null }
    }
    const admin = isAdministrator(groupMetadata, senderJid)
    const text = extractText(message.message)
    if (settings.autoRead) await sock.readMessages([message.key]).catch(() => {})
    if (settings.autoTyping) await sock.sendPresenceUpdate('composing', message.key.remoteJid).catch(() => {})
    if (settings.autoRecord) await sock.sendPresenceUpdate('recording', message.key.remoteJid).catch(() => {})
    if (settings.autoReact && !message.key.fromMe) await sock.sendMessage(message.key.remoteJid, { react: { text: '👍', key: message.key } }).catch(() => {})

    let violation = null
    if (!admin && settings.antiLink && linkPattern.test(text)) violation = 'Links are not allowed in this group.'
    if (!admin && settings.antiBadWord && settings.badWords?.some(word => new RegExp(`\\b${word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i').test(text))) violation = 'This message contains a blocked word.'
    const mentions = Object.values(unwrapMessage(message.message)).find(value => value?.contextInfo)?.contextInfo?.mentionedJid || []
    if (!admin && settings.antiMention && mentions.length >= 8) violation = 'Mass mentions are not allowed in this group.'
    if (!admin && (settings.antiSpam || settings.antiFlood)) {
      const key = `${sessionId}:${message.key.remoteJid}:${senderJid}`
      const now = Date.now()
      const timestamps = (activity.get(key) || []).filter(timestamp => now - timestamp < 10000)
      timestamps.push(now)
      activity.set(key, timestamps)
      if (timestamps.length > (settings.antiFlood ? 6 : 9)) violation = 'Message flooding is not allowed in this group.'
    }
    const rawContent = message.message?.ephemeralMessage?.message || message.message
    const hasViewOnce = Boolean(rawContent?.viewOnceMessage || rawContent?.viewOnceMessageV2)
    if (!admin && settings.antiViewOnce && hasViewOnce) violation = 'View-once media is disabled in this group.'

    if (violation) {
      await sock.sendMessage(message.key.remoteJid, { delete: message.key }).catch(() => {})
      await sock.sendMessage(message.key.remoteJid, { text: `@${jidNumber(senderJid)}: ${violation}`, mentions: [senderJid] }).catch(() => {})
      if (linkPattern.test(text)) await AntiLink.create({ sessionId, groupJid: message.key.remoteJid, userJid: senderJid, url: text.match(linkPattern)?.[0] || '', action: 'deleted', reason: violation }).catch(() => {})
      return { blocked: true, settings }
    }
    this.cache(sessionId, message)
    return { blocked: false, settings }
  }

  async handleProtocolMessage({ sessionId, sock, message }) {
    const protocol = unwrapMessage(message.message).protocolMessage
    if (!protocol?.key?.id) return false
    const cached = recentMessages.get(keyFor(sessionId, protocol.key.id))
    if (!cached || !isGroupJid(cached.key.remoteJid)) return false
    const settings = await this.settings(sessionId, cached.key.remoteJid)
    if (!settings?.antiDelete) return false
    const text = extractText(cached.message)
    if (!text) return false
    await sock.sendMessage(cached.key.remoteJid, { text: `Deleted message recovered\nFrom: @${jidNumber(cached.key.participant || cached.key.remoteJid)}\n\n${text}`, mentions: [cached.key.participant].filter(Boolean) })
    return true
  }

  async groupParticipants({ sessionId, sock, update }) {
    if (!['add', 'remove'].includes(update.action)) return
    const settings = await this.settings(sessionId, update.id)
    const enabled = update.action === 'add' ? settings?.welcome : settings?.farewell
    if (!enabled) return
    const metadata = await sock.groupMetadata(update.id).catch(() => null)
    if (!metadata) return
    await Group.findOneAndUpdate({ sessionId, jid: update.id }, { $set: { subject: metadata.subject, description: metadata.desc, ownerJid: metadata.ownerPn || metadata.owner, participantsCount: metadata.participants.length, active: true, lastSeenAt: new Date() } }, { upsert: true })
    const Model = update.action === 'add' ? Welcome : Farewell
    const template = await Model.findOne({ sessionId, groupJid: update.id }).lean()
    const fallback = update.action === 'add' ? 'Welcome {user} to {group}.' : 'Goodbye {user} from {group}.'
    const imageEnabled = update.action === 'add' ? settings.welcomeImage : settings.farewellImage
    for (const participant of update.participants) {
      const text = (template?.message || fallback).replaceAll('{user}', `@${jidNumber(participant)}`).replaceAll('{group}', metadata.subject)
      const payload = imageEnabled
        ? { image: await createQuoteCard({ quote: text, author: metadata.subject }), caption: text, mentions: [participant] }
        : { text, mentions: [participant] }
      await sock.sendMessage(update.id, payload).catch(error => logger.warn({ err: error, groupJid: update.id }, 'Greeting delivery failed'))
    }
  }
}

export const messagePolicy = new MessagePolicy()
