import { env } from '../config/env.js'
import { AppError } from '../utils/AppError.js'
import { logger } from '../config/logger.js'

const adapters = Object.freeze({
  facebook: [{ path: '/api/facebook2', params: input => ({ url: input.url }) }, { path: '/api/facebook3', params: input => ({ url: input.url }) }],
  instagram: [{ path: '/api/instagram', params: input => ({ url: input.url }) }, { path: '/api/instagram2', params: input => ({ url: input.url }) }],
  tiktok: [{ path: '/api/tiktok', params: input => ({ url: input.url }) }, { path: '/api/tiktokv2', params: input => ({ url: input.url }) }],
  twitter: [{ path: '/api/twitter', params: input => ({ url: input.url }) }, { path: '/api/twitter_v2', params: input => ({ url: input.url }) }],
  youtubeAudio: [{ path: '/api/ytmp3', params: input => ({ url: input.url }) }, { path: '/api/mp3_v2', params: input => ({ url: input.url }) }, { path: '/api/mp3_v3', params: input => ({ url: input.url }) }],
  youtubeVideo: [{ path: '/api/ytmp4', params: input => ({ url: input.url }) }, { path: '/api/mp4_v2', params: input => ({ url: input.url }) }, { path: '/api/mp4_v3', params: input => ({ url: input.url }) }],
  youtubeSearch: [{ path: '/api/youtube/search', params: input => ({ q: input.query }) }],
  pinterestDownload: [{ path: '/api/pinterest', params: input => ({ url: input.url }) }],
  pinterestSearch: [{ path: '/api/search/pinterest', params: input => ({ q: input.query }) }],
  mediafire: [{ path: '/api/mediafire', params: input => ({ url: input.url }) }],
  gdrive: [{ path: '/api/download/gdrive', params: input => ({ url: input.url }) }],
  apk: [{ path: '/api/apk/get', params: input => ({ q: input.query }) }, { path: '/api/search/apk', params: input => ({ q: input.query, mode: 'search_dl' }) }],
  google: [{ path: '/api/search/google', params: input => ({ q: input.query }) }],
  image: [{ path: '/api/search/google/image', params: input => ({ q: input.query }) }, { path: '/api/search/img', params: input => ({ q: input.query }) }],
  news: [{ path: '/api/news/all', params: input => ({ q: input.query }) }],
  movie: [{ path: '/api/movie/search', params: input => ({ q: input.query, provider: input.provider }) }],
  anime: [{ path: '/api/anime/search', params: input => ({ q: input.query }) }],
  shortUrl: [{ path: '/api/tools/tinyurl', params: input => ({ url: input.url }) }],
  qrCode: [{ path: '/api/qrcode', params: input => ({ text: input.text, format: input.format || 'png' }) }],
  textToSpeech: [{ path: '/api/tools/tts', params: input => ({ text: input.text, lang: input.language || 'en' }) }, { path: '/api/sasaaiplus/tts', params: input => ({ text: input.text, language: input.language || 'en' }) }],
  aiChat: [{ path: '/api/ai/gpt4o', params: input => ({ text: input.text }) }, { path: '/api/ai/gemini', params: input => ({ text: input.text }) }, { path: '/api/ai/deepseek', params: input => ({ text: input.text }) }],
  aiGemini: [{ path: '/api/ai/gemini', params: input => ({ text: input.text }) }],
  aiGroq: [{ path: '/api/ai/deepseek', params: input => ({ text: input.text }) }],
  aiCode: [{ path: '/api/sasaai/code', params: input => ({ text: input.text }) }, { path: '/api/ai/blackbox', params: input => ({ text: input.text }) }],
  aiImage: [{ path: '/api/ai/image/zoner', params: input => ({ prompt: input.text }) }, { path: '/api/sasaai/image', params: input => ({ prompt: input.text }) }],
  summarize: [{ path: '/api/sasaaiplus/summarise', params: input => ({ text: input.text }) }],
  translate: [{ path: '/api/sasaaiplus/translate', params: input => ({ text: input.text, target: input.target }) }],
  rewrite: [{ path: '/api/sasaaiplus/rewrite', params: input => ({ text: input.text, tone: input.tone }) }],
  vision: [{ path: '/api/sasaaiplus/vision', params: input => ({ image: input.imageUrl, text: input.text }) }],
  speechToText: [{ path: '/api/sasaaiplus/stt', params: input => ({ url: input.url, language: input.language }) }],
  json: [{ path: '/api/sasaaiplus/json', params: input => ({ text: input.text }) }]
})

const sleep = delay => new Promise(resolve => setTimeout(resolve, delay))
const cleanParams = params => Object.fromEntries(Object.entries(params || {}).filter(([, value]) => value !== undefined && value !== null && value !== ''))

export const normalizeSasaResponse = payload => {
  const successful = payload?.status === true || payload?.success === true || payload?.status === 'success'
  if (!successful) {
    const message = payload?.error?.message || payload?.error || payload?.message || 'Sasa Dev API rejected the request'
    throw new AppError(String(message), 502, 'SASA_API_RESPONSE_ERROR')
  }
  return {
    success: true,
    creator: payload.creator || 'Sasa Dev',
    data: payload.result ?? payload.data ?? payload.response ?? null,
    raw: payload
  }
}

export class SasaApiService {
  constructor({ baseUrl = env.sasaApiBaseUrl, apiKey = env.sasaApiKey, timeout = env.apiTimeoutMs, retries = env.apiRetryLimit } = {}) {
    this.baseUrl = baseUrl.replace(/\/$/, '')
    this.apiKey = apiKey
    this.timeout = timeout
    this.retries = retries
  }

  isConfigured() {
    return env.isConfigured(this.apiKey)
  }

  async request(path, { method = 'GET', params = {}, body } = {}) {
    if (!this.isConfigured()) throw new AppError('Sasa Dev API key is not configured', 503, 'SASA_API_NOT_CONFIGURED')
    const url = new URL(path, `${this.baseUrl}/`)
    const query = cleanParams({ ...params, apikey: this.apiKey })
    for (const [key, value] of Object.entries(query)) url.searchParams.set(key, String(value))

    let lastError
    for (let attempt = 0; attempt <= this.retries; attempt += 1) {
      const controller = new AbortController()
      const timeout = setTimeout(() => controller.abort(), this.timeout)
      try {
        const response = await fetch(url, {
          method,
          signal: controller.signal,
          headers: {
            accept: 'application/json',
            'content-type': 'application/json',
            'x-api-key': this.apiKey,
            'user-agent': 'Sasa-Dev-Official/1.0'
          },
          body: body === undefined ? undefined : JSON.stringify(body)
        })
        const text = await response.text()
        let payload
        try {
          payload = text ? JSON.parse(text) : {}
        } catch {
          throw new AppError('Sasa Dev API returned a non-JSON response', 502, 'SASA_API_INVALID_RESPONSE')
        }
        if (response.ok) return normalizeSasaResponse(payload)
        const message = payload?.error?.message || payload?.error || payload?.message || `Sasa Dev API returned HTTP ${response.status}`
        const retryable = response.status === 429 || response.status >= 500
        const error = new AppError(String(message), response.status === 429 ? 429 : 502, response.status === 429 ? 'SASA_API_RATE_LIMIT' : 'SASA_API_HTTP_ERROR')
        if (!retryable) throw error
        lastError = error
      } catch (error) {
        if (error instanceof AppError && !['SASA_API_HTTP_ERROR'].includes(error.code)) throw error
        lastError = error.name === 'AbortError'
          ? new AppError('Sasa Dev API request timed out', 504, 'SASA_API_TIMEOUT')
          : error
      } finally {
        clearTimeout(timeout)
      }
      if (attempt < this.retries) await sleep(Math.min(3000, 300 * (2 ** attempt) + Math.floor(Math.random() * 200)))
    }
    logger.warn({ path, error: lastError?.message }, 'Sasa Dev API request exhausted retries')
    throw lastError instanceof AppError ? lastError : new AppError('Sasa Dev API is unavailable', 502, 'SASA_API_UNAVAILABLE')
  }

  async call(adapterName, input = {}) {
    const definitions = adapters[adapterName]
    if (!definitions) throw new AppError(`Unknown Sasa Dev API adapter: ${adapterName}`, 500, 'SASA_ADAPTER_NOT_FOUND')
    let lastError
    for (const definition of definitions) {
      try {
        return await this.request(definition.path, { params: definition.params(input) })
      } catch (error) {
        lastError = error
        if (['SASA_API_NOT_CONFIGURED', 'SASA_API_RATE_LIMIT'].includes(error.code)) break
      }
    }
    throw lastError
  }

  async health() {
    if (!this.isConfigured()) return { configured: false, status: 'unconfigured' }
    const started = Date.now()
    try {
      await this.request('/api/aiassist/status')
      return { configured: true, status: 'available', responseTime: Date.now() - started }
    } catch (error) {
      return { configured: true, status: 'unavailable', responseTime: Date.now() - started, error: error.code }
    }
  }
}

export const sasaApi = new SasaApiService()
export const sasaAdapters = Object.freeze(Object.keys(adapters))
