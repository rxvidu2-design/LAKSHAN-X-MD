import crypto from 'node:crypto'
import { BufferJSON } from '@whiskeysockets/baileys'
import { env } from '../config/env.js'
import { AppError } from '../utils/AppError.js'

const keyMaterial = () => {
  if (!env.isConfigured(env.sessionSecret) || env.sessionSecret.length < 32 || !env.isConfigured(env.pairCodeSecret) || env.pairCodeSecret.length < 32) {
    throw new AppError('Session encryption secrets are not configured', 503, 'SESSION_ENCRYPTION_UNAVAILABLE')
  }
  return crypto.createHash('sha256').update(`${env.sessionSecret}:${env.pairCodeSecret}`).digest()
}

export const assertSessionEncryption = () => {
  keyMaterial()
  return true
}

export const encryptObject = (value, aad = '') => {
  const iv = crypto.randomBytes(12)
  const cipher = crypto.createCipheriv('aes-256-gcm', keyMaterial(), iv)
  if (aad) cipher.setAAD(Buffer.from(aad))
  const plaintext = JSON.stringify(value, BufferJSON.replacer)
  const encrypted = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()])
  return {
    iv: iv.toString('base64'),
    tag: cipher.getAuthTag().toString('base64'),
    data: encrypted.toString('base64'),
    version: 1
  }
}

export const decryptObject = (payload, aad = '') => {
  if (!payload?.iv || !payload?.tag || !payload?.data) return null
  try {
    const decipher = crypto.createDecipheriv('aes-256-gcm', keyMaterial(), Buffer.from(payload.iv, 'base64'))
    if (aad) decipher.setAAD(Buffer.from(aad))
    decipher.setAuthTag(Buffer.from(payload.tag, 'base64'))
    const plaintext = Buffer.concat([
      decipher.update(Buffer.from(payload.data, 'base64')),
      decipher.final()
    ]).toString('utf8')
    return JSON.parse(plaintext, BufferJSON.reviver)
  } catch {
    throw new AppError('Stored session data could not be decrypted', 500, 'SESSION_DECRYPTION_FAILED')
  }
}

export const randomToken = (bytes = 24) => crypto.randomBytes(bytes).toString('base64url')
export const secureHash = value => crypto.createHash('sha256').update(String(value)).digest('hex')
