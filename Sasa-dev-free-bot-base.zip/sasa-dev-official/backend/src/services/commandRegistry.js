import { readdir } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { Command } from '../models/index.js'
import { logger } from '../config/logger.js'

class CommandRegistry {
  constructor() {
    this.commands = new Map()
    this.aliases = new Map()
    this.disabled = new Set()
  }

  get size() {
    return this.commands.size
  }

  get(name) {
    const normalized = String(name || '').toLowerCase()
    const canonical = this.aliases.get(normalized) || normalized
    return this.commands.get(canonical) || null
  }

  list() {
    return [...this.commands.values()].sort((a, b) => a.category.localeCompare(b.category) || a.name.localeCompare(b.name))
  }

  isEnabled(name) {
    return !this.disabled.has(name)
  }

  setEnabled(name, enabled) {
    if (enabled) this.disabled.delete(name)
    else this.disabled.add(name)
  }

  register(command) {
    if (this.commands.has(command.name) || this.aliases.has(command.name)) throw new Error(`Duplicate command name: ${command.name}`)
    this.commands.set(command.name, command)
    for (const alias of command.aliases) {
      if (this.commands.has(alias) || this.aliases.has(alias)) throw new Error(`Duplicate command alias: ${alias}`)
      this.aliases.set(alias, command.name)
    }
  }

  async load() {
    this.commands.clear()
    this.aliases.clear()
    const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'commands')
    const directories = (await readdir(root, { withFileTypes: true })).filter(entry => entry.isDirectory() && !entry.name.startsWith('_'))
    for (const directory of directories) {
      const files = (await readdir(path.join(root, directory.name))).filter(file => file.endsWith('.js')).sort()
      for (const file of files) {
        const module = await import(pathToFileURL(path.join(root, directory.name, file)).href)
        this.register(module.default)
      }
    }
    if (this.size !== 200) throw new Error(`Command registry expected 200 commands but loaded ${this.size}`)
    logger.info({ count: this.size }, 'Command registry loaded')
    return this
  }

  async syncDatabase() {
    const operations = this.list().map(command => ({
      updateOne: {
        filter: { name: command.name },
        update: {
          $set: {
            aliases: command.aliases,
            description: command.description,
            category: command.category,
            usage: command.usage,
            permission: command.permission,
            cooldown: command.cooldown
          },
          $setOnInsert: { enabled: true, executions: 0, successes: 0, failures: 0, averageResponseTime: 0 }
        },
        upsert: true
      }
    }))
    await Command.bulkWrite(operations, { ordered: false })
    await this.refreshEnabledState()
  }

  async refreshEnabledState() {
    const documents = await Command.find({ enabled: false }).select('name').lean()
    this.disabled = new Set(documents.map(document => document.name))
  }

  publicList() {
    return this.list().map(({ execute, ...command }) => ({ ...command, enabled: this.isEnabled(command.name) }))
  }
}

export const commandRegistry = new CommandRegistry()
