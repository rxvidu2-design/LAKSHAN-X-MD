import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import os from 'node:os'
import path from 'node:path'
import crypto from 'node:crypto'
import sharp from 'sharp'
import ffmpegPath from 'ffmpeg-static'
import webp from 'node-webpmux'
import jsQR from 'jsqr'
import { downloadMediaMessage } from '@whiskeysockets/baileys'
import { env } from '../config/env.js'
import { AppError } from '../utils/AppError.js'
import { getQuotedMessage, messageType, unwrapMessage } from '../utils/message.js'
import { TaskQueue } from '../utils/TaskQueue.js'

const execFileAsync = promisify(execFile)
const maxBytes = () => env.maxMediaMb * 1024 * 1024
const mediaQueue = new TaskQueue(2, 50)
const escapeXml = value => String(value).replace(/[<>&'\"]/g, character => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;' })[character])

export const mediaSource = message => getQuotedMessage(message) || { message }

export const downloadMessageMedia = async (sock, message) => {
  const source = mediaSource(message)
  const type = messageType(source.message)
  if (!type || !/(image|video|audio|sticker|document)Message/i.test(type)) {
    throw new AppError('Reply to a supported image, video, audio, sticker, or document', 400, 'MEDIA_REQUIRED')
  }
  const buffer = await downloadMediaMessage(source, 'buffer', {}, { reuploadRequest: sock.updateMediaMessage })
  if (!Buffer.isBuffer(buffer) || !buffer.length) throw new AppError('The media could not be downloaded', 502, 'MEDIA_DOWNLOAD_FAILED')
  if (buffer.length > maxBytes()) throw new AppError('Media exceeds the configured size limit', 413, 'MEDIA_TOO_LARGE')
  const content = unwrapMessage(source.message)[type]
  return { buffer, type, mimeType: content?.mimetype || '', fileName: content?.fileName || null, source }
}

const withTempFiles = async task => {
  const directory = await mkdtemp(path.join(os.tmpdir(), 'sasa-media-'))
  try {
    return await task(directory)
  } finally {
    await rm(directory, { recursive: true, force: true })
  }
}

export const transcode = (buffer, inputExtension, outputExtension, args) => mediaQueue.add(() => withTempFiles(async directory => {
  if (!ffmpegPath) throw new AppError('Media transcoder is unavailable on this platform', 503, 'TRANSCODER_UNAVAILABLE')
  const input = path.join(directory, `input.${inputExtension}`)
  const output = path.join(directory, `output.${outputExtension}`)
  await writeFile(input, buffer)
  try {
    await execFileAsync(ffmpegPath, ['-hide_banner', '-loglevel', 'error', '-y', '-i', input, ...args, output], {
      timeout: 120000,
      maxBuffer: 2 * 1024 * 1024
    })
  } catch (error) {
    throw new AppError(`Media conversion failed: ${String(error.stderr || error.message).slice(0, 300)}`, 422, 'MEDIA_CONVERSION_FAILED')
  }
  const result = await readFile(output)
  if (result.length > maxBytes()) throw new AppError('Converted media exceeds the size limit', 413, 'MEDIA_TOO_LARGE')
  return result
})).catch(error => {
  if (error.message === 'Task queue is full') throw new AppError('Media queue is busy; try again shortly', 503, 'MEDIA_QUEUE_FULL')
  throw error
})

const stickerExif = (pack, author) => {
  const metadata = Buffer.from(JSON.stringify({
    'sticker-pack-id': crypto.randomUUID(),
    'sticker-pack-name': pack,
    'sticker-pack-publisher': author,
    emojis: []
  }))
  const exif = Buffer.alloc(22 + metadata.length)
  Buffer.from('49492a00080000000100415707000000', 'hex').copy(exif, 0)
  exif.writeUIntLE(metadata.length, 14, 4)
  metadata.copy(exif, 22)
  return exif
}

export const imageToSticker = async (buffer, pack = env.botName, author = env.botOwnerName) => {
  const sticker = await sharp(buffer, { animated: true })
    .resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
    .webp({ quality: 82, effort: 4 })
    .toBuffer()
  const image = new webp.Image()
  await image.load(sticker)
  image.exif = stickerExif(pack, author)
  return image.save(null)
}

export const videoToSticker = async buffer => transcode(buffer, 'mp4', 'webp', [
  '-t', '10',
  '-vf', 'fps=15,scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000',
  '-loop', '0',
  '-an',
  '-vcodec', 'libwebp',
  '-q:v', '62'
])

export const stickerToImage = buffer => sharp(buffer, { animated: false }).png().toBuffer()
export const resizeImage = (buffer, width, height) => sharp(buffer).rotate().resize(width, height, { fit: 'inside', withoutEnlargement: true }).jpeg({ quality: 88 }).toBuffer()
export const cropImage = buffer => sharp(buffer).rotate().resize(1080, 1080, { fit: 'cover', position: 'centre' }).jpeg({ quality: 90 }).toBuffer()
export const compressImage = (buffer, quality = 70) => sharp(buffer).rotate().jpeg({ quality, mozjpeg: true }).toBuffer()
export const blurImage = (buffer, sigma = 8) => sharp(buffer).rotate().blur(sigma).jpeg({ quality: 88 }).toBuffer()
export const enhanceImage = buffer => sharp(buffer).rotate().normalize().sharpen({ sigma: 1.2 }).modulate({ saturation: 1.08 }).jpeg({ quality: 92 }).toBuffer()

export const createMeme = async (buffer, top, bottom) => {
  const image = sharp(buffer).rotate().resize(1080, 1080, { fit: 'inside', background: '#0b0f18' })
  const metadata = await image.metadata()
  const width = metadata.width || 1080
  const height = metadata.height || 1080
  const text = `<svg width="${width}" height="${height}"><style>.t{fill:white;stroke:black;stroke-width:8;paint-order:stroke;font-family:Arial,sans-serif;font-weight:900;font-size:${Math.max(34, Math.round(width / 14))}px;text-anchor:middle}</style><text class="t" x="50%" y="10%">${escapeXml(top)}</text><text class="t" x="50%" y="92%">${escapeXml(bottom)}</text></svg>`
  return image.composite([{ input: Buffer.from(text), top: 0, left: 0 }]).jpeg({ quality: 92 }).toBuffer()
}

export const createQuoteCard = async ({ quote, author = 'Unknown', avatar }) => {
  const width = 1200
  const height = 630
  const safeQuote = escapeXml(quote.slice(0, 420))
  const safeAuthor = escapeXml(author.slice(0, 80))
  const svg = `<svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#0b1220"/><stop offset="1" stop-color="#151d32"/></linearGradient></defs><rect width="100%" height="100%" rx="40" fill="url(#g)"/><circle cx="90" cy="90" r="8" fill="#25d366"/><text x="70" y="185" fill="#25d366" font-size="92" font-family="Georgia">“</text><foreignObject x="85" y="180" width="1030" height="300"><div xmlns="http://www.w3.org/1999/xhtml" style="color:#f4f7fb;font:600 42px Arial;line-height:1.35;overflow:hidden">${safeQuote}</div></foreignObject><text x="90" y="540" fill="#9aa7bc" font-size="30" font-family="Arial">— ${safeAuthor}</text><text x="1110" y="580" fill="#657086" text-anchor="end" font-size="22" font-family="Arial">${escapeXml(env.botName)}</text></svg>`
  return sharp(Buffer.from(svg)).png().toBuffer()
}

export const readQrFromImage = async buffer => {
  const { data, info } = await sharp(buffer).ensureAlpha().raw().toBuffer({ resolveWithObject: true })
  const code = jsQR(new Uint8ClampedArray(data), info.width, info.height)
  if (!code?.data) throw new AppError('No readable QR code was found in the image', 422, 'QR_NOT_FOUND')
  return code.data
}
