import { env } from '../config/env.js'
import { AppError } from '../utils/AppError.js'
import { sasaApi } from './sasaApi.js'

const requestJson = async (url, options, timeout = env.apiTimeoutMs) => {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeout)
  try {
    const response = await fetch(url, { ...options, signal: controller.signal })
    const text = await response.text()
    let data
    try { data = text ? JSON.parse(text) : {} } catch { throw new AppError('AI provider returned invalid JSON', 502, 'AI_INVALID_RESPONSE') }
    if (!response.ok) throw new AppError(data.error?.message || data.message || `AI provider returned HTTP ${response.status}`, response.status === 429 ? 429 : 502, 'AI_PROVIDER_ERROR')
    return data
  } catch (error) {
    if (error.name === 'AbortError') throw new AppError('AI provider timed out', 504, 'AI_TIMEOUT')
    throw error
  } finally {
    clearTimeout(timer)
  }
}

const openAi = async (prompt, system, image) => {
  if (!env.isConfigured(env.openaiApiKey)) throw new AppError('OpenAI is not configured', 503, 'OPENAI_NOT_CONFIGURED')
  const content = image
    ? [{ type: 'text', text: prompt }, { type: 'image_url', image_url: { url: `data:${image.mimeType};base64,${image.buffer.toString('base64')}` } }]
    : prompt
  const data = await requestJson('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { authorization: `Bearer ${env.openaiApiKey}`, 'content-type': 'application/json' },
    body: JSON.stringify({ model: image ? 'gpt-4o-mini' : 'gpt-4o-mini', messages: [{ role: 'system', content: system }, { role: 'user', content }], temperature: 0.5, max_tokens: 1800 })
  })
  const result = data.choices?.[0]?.message?.content
  if (!result) throw new AppError('OpenAI returned an empty response', 502, 'AI_EMPTY_RESPONSE')
  return result
}

const groq = async (prompt, system) => {
  if (!env.isConfigured(env.groqApiKey)) throw new AppError('Groq is not configured', 503, 'GROQ_NOT_CONFIGURED')
  const data = await requestJson('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: { authorization: `Bearer ${env.groqApiKey}`, 'content-type': 'application/json' },
    body: JSON.stringify({ model: 'llama-3.3-70b-versatile', messages: [{ role: 'system', content: system }, { role: 'user', content: prompt }], temperature: 0.5, max_tokens: 1800 })
  })
  const result = data.choices?.[0]?.message?.content
  if (!result) throw new AppError('Groq returned an empty response', 502, 'AI_EMPTY_RESPONSE')
  return result
}

const gemini = async (prompt, system, image) => {
  if (!env.isConfigured(env.geminiApiKey)) throw new AppError('Gemini is not configured', 503, 'GEMINI_NOT_CONFIGURED')
  const parts = [{ text: `${system}\n\n${prompt}` }]
  if (image) parts.push({ inline_data: { mime_type: image.mimeType, data: image.buffer.toString('base64') } })
  const data = await requestJson(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${encodeURIComponent(env.geminiApiKey)}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ contents: [{ parts }], generationConfig: { temperature: 0.5, maxOutputTokens: 1800 } })
  })
  const result = data.candidates?.[0]?.content?.parts?.map(part => part.text || '').join('')
  if (!result) throw new AppError('Gemini returned an empty response', 502, 'AI_EMPTY_RESPONSE')
  return result
}

const fromSasa = async (adapter, input) => {
  const response = await sasaApi.call(adapter, input)
  const value = response.data
  if (typeof value === 'string') return value
  const candidates = [value?.text, value?.response, value?.answer, value?.message, value?.content, value?.result]
  const result = candidates.find(candidate => typeof candidate === 'string' && candidate.trim())
  if (result) return result
  if (value !== null && value !== undefined) return JSON.stringify(value, null, 2)
  throw new AppError('AI provider returned an empty response', 502, 'AI_EMPTY_RESPONSE')
}

export const chatCompletion = async ({ prompt, system = 'You are Sasa Dev Official, a concise and helpful assistant.', provider = 'auto', image = null }) => {
  const adapter = provider === 'gemini' ? 'aiGemini' : provider === 'groq' ? 'aiGroq' : 'aiChat'
  if (!image) {
    try { return await fromSasa(adapter, { text: `${system}\n\n${prompt}` }) } catch (error) {
      if (!['SASA_API_NOT_CONFIGURED', 'SASA_API_UNAVAILABLE', 'SASA_API_HTTP_ERROR', 'SASA_API_RESPONSE_ERROR', 'SASA_API_TIMEOUT'].includes(error.code)) throw error
    }
  }
  const providers = provider === 'openai' ? [openAi] : provider === 'groq' ? [groq, openAi] : provider === 'gemini' ? [gemini, openAi] : image ? [gemini, openAi] : [groq, gemini, openAi]
  let lastError
  for (const execute of providers) {
    try { return await execute(prompt, system, image) } catch (error) { lastError = error }
  }
  throw lastError || new AppError('No AI provider is configured', 503, 'AI_NOT_CONFIGURED')
}

export const transcribeAudio = async ({ buffer, fileName = 'audio.ogg', mimeType = 'audio/ogg', language }) => {
  if (!env.isConfigured(env.openaiApiKey)) throw new AppError('Speech transcription requires OPENAI_API_KEY or a compatible Sasa Dev API route', 503, 'STT_NOT_CONFIGURED')
  const form = new FormData()
  form.append('file', new Blob([buffer], { type: mimeType }), fileName)
  form.append('model', 'whisper-1')
  if (language) form.append('language', language)
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), 120000)
  try {
    const response = await fetch('https://api.openai.com/v1/audio/transcriptions', { method: 'POST', headers: { authorization: `Bearer ${env.openaiApiKey}` }, body: form, signal: controller.signal })
    const data = await response.json()
    if (!response.ok || !data.text) throw new AppError(data.error?.message || 'Speech transcription failed', 502, 'STT_FAILED')
    return data.text
  } catch (error) {
    if (error.name === 'AbortError') throw new AppError('Speech transcription timed out', 504, 'AI_TIMEOUT')
    throw error
  } finally {
    clearTimeout(timer)
  }
}

export const synthesizeSpeech = async ({ text, voice = 'alloy' }) => {
  if (!env.isConfigured(env.openaiApiKey)) return null
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), 120000)
  try {
    const response = await fetch('https://api.openai.com/v1/audio/speech', {
      method: 'POST', signal: controller.signal,
      headers: { authorization: `Bearer ${env.openaiApiKey}`, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'gpt-4o-mini-tts', voice, input: text, format: 'mp3' })
    })
    if (!response.ok) {
      const data = await response.json().catch(() => ({}))
      throw new AppError(data.error?.message || 'Speech synthesis failed', 502, 'TTS_FAILED')
    }
    return Buffer.from(await response.arrayBuffer())
  } catch (error) {
    if (error.name === 'AbortError') throw new AppError('Speech synthesis timed out', 504, 'AI_TIMEOUT')
    throw error
  } finally {
    clearTimeout(timer)
  }
}
