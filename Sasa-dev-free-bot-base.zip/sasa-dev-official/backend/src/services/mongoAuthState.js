import { BufferJSON, initAuthCreds, proto } from '@whiskeysockets/baileys'
import { AuthKey, Session } from '../models/index.js'
import { decryptObject, encryptObject } from './cryptoService.js'
import { AppError } from '../utils/AppError.js'

const aadFor = (sessionId, type, keyId = '') => `${sessionId}:${type}:${keyId}`

export const useMongoAuthState = async sessionId => {
  const session = await Session.findOne({ sessionId }).select('+credentials').lean()
  if (!session) throw new AppError('Session not found', 404, 'SESSION_NOT_FOUND')

  const creds = session.credentials
    ? decryptObject(session.credentials, aadFor(sessionId, 'credentials'))
    : initAuthCreds()

  const keys = {
    get: async (type, ids) => {
      if (!ids.length) return {}
      const documents = await AuthKey.find({ sessionId, type, keyId: { $in: ids } }).select('+value').lean()
      const result = {}
      for (const document of documents) {
        let value = decryptObject(document.value, aadFor(sessionId, type, document.keyId))
        if (value && type === 'app-state-sync-key') value = proto.Message.AppStateSyncKeyData.create(value)
        result[document.keyId] = value
      }
      return result
    },
    set: async data => {
      const operations = []
      for (const [type, entries] of Object.entries(data)) {
        for (const [keyId, value] of Object.entries(entries || {})) {
          if (value === null || value === undefined) {
            operations.push({ deleteOne: { filter: { sessionId, type, keyId } } })
          } else {
            const normalized = JSON.parse(JSON.stringify(value, BufferJSON.replacer), BufferJSON.reviver)
            operations.push({
              updateOne: {
                filter: { sessionId, type, keyId },
                update: { $set: { value: encryptObject(normalized, aadFor(sessionId, type, keyId)) } },
                upsert: true
              }
            })
          }
        }
      }
      if (operations.length) await AuthKey.bulkWrite(operations, { ordered: false })
    },
    clear: async () => {
      await AuthKey.deleteMany({ sessionId })
    }
  }

  const saveCreds = async () => {
    const credentials = encryptObject(creds, aadFor(sessionId, 'credentials'))
    const result = await Session.updateOne({ sessionId }, { $set: { credentials } })
    if (!result.matchedCount) throw new AppError('Session no longer exists', 404, 'SESSION_NOT_FOUND')
  }

  const wipe = async () => {
    await Promise.all([
      AuthKey.deleteMany({ sessionId }),
      Session.updateOne({ sessionId }, { $unset: { credentials: 1 } })
    ])
  }

  return { state: { creds, keys }, saveCreds, wipe }
}
