import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import { env } from '../config/env.js'
import { User } from '../models/index.js'
import { AppError } from '../utils/AppError.js'
import { logger } from '../config/logger.js'

const assertJwt = () => {
  if (!env.isConfigured(env.jwtSecret) || env.jwtSecret.length < 32) {
    throw new AppError('Administrator authentication is not configured', 503, 'AUTH_UNAVAILABLE')
  }
}

export const bootstrapAdministrator = async () => {
  if (!env.isConfigured(env.adminUsername)) {
    logger.warn('ADMIN_USERNAME is not configured; administrator login is disabled')
    return null
  }
  if (!env.isConfigured(env.adminPassword) && !env.isConfigured(env.adminPasswordHash)) {
    logger.warn('Administrator password is not configured; administrator login is disabled')
    return null
  }
  const username = env.adminUsername.toLowerCase()
  const existing = await User.findOne({ username })
  if (existing) return existing
  const passwordHash = env.isConfigured(env.adminPasswordHash)
    ? env.adminPasswordHash
    : await bcrypt.hash(env.adminPassword, 12)
  const administrator = await User.create({
    username,
    passwordHash,
    displayName: env.botOwnerName,
    phoneNumber: env.botOwnerNumber,
    role: 'admin',
    active: true
  })
  logger.info({ username }, 'Administrator account created with a one-way password hash')
  return administrator
}

export const authenticateAdministrator = async (username, password, ip) => {
  assertJwt()
  const user = await User.findOne({ username: String(username).toLowerCase(), active: true }).select('+passwordHash')
  const valid = user && await bcrypt.compare(String(password), user.passwordHash)
  if (!valid) throw new AppError('Invalid username or password', 401, 'INVALID_CREDENTIALS')
  user.lastLoginAt = new Date()
  user.lastLoginIp = ip
  await user.save()
  return user
}

export const createAccessToken = user => {
  assertJwt()
  return jwt.sign({ sub: user.id, role: user.role, username: user.username }, env.jwtSecret, {
    expiresIn: env.jwtExpiresIn,
    issuer: 'sasa-dev-official',
    audience: 'sasa-dev-dashboard'
  })
}

export const verifyAccessToken = token => {
  assertJwt()
  try {
    return jwt.verify(token, env.jwtSecret, {
      issuer: 'sasa-dev-official',
      audience: 'sasa-dev-dashboard'
    })
  } catch {
    throw new AppError('Authentication is required', 401, 'AUTH_REQUIRED')
  }
}
