import { env } from '../../config/env.js'
import { Log } from '../../models/index.js'
import { AppError } from '../../utils/AppError.js'
import { extractText, getQuotedMessage, jidNumber, resolveTargets } from '../../utils/message.js'
import { fetchBuffer } from '../networkService.js'
import { executeMedia } from './mediaActions.js'
import { requireInput, truncate } from './helpers.js'

const targetFor = context => resolveTargets(context)[0] || context.senderJid

const profileStatus = async (sock, jid) => {
  try {
    const result = await sock.fetchStatus(jid)
    return result?.status || 'No public status'
  } catch {
    throw new AppError('Profile status is unavailable or private', 404, 'PROFILE_STATUS_UNAVAILABLE')
  }
}

export const executeWhatsApp = async (name, context) => {
  const target = targetFor(context)
  if (name === 'jid') return `Chat JID: ${context.chatJid}\nSender JID: ${context.senderJid}\nSelected JID: ${target}`
  if (name === 'number') return jidNumber(target) || 'Phone number is unavailable for this LID.'
  if (name === 'getname') {
    const participant = context.groupMetadata?.participants?.find(item => [item.id, item.phoneNumber, item.lid].filter(Boolean).includes(target))
    return participant?.name || participant?.notify || (target === context.senderJid ? context.senderName : `@${jidNumber(target)}`)
  }
  if (['getbio', 'getstatus'].includes(name)) return await profileStatus(context.sock, target)
  if (name === 'getpp') return executeMedia('getpp', context)
  if (name === 'profile') {
    let picture = 'Unavailable'
    try { picture = await context.sock.profilePictureUrl(target, 'image') } catch {}
    let status = 'Unavailable'
    try { status = await profileStatus(context.sock, target) } catch {}
    return `Profile\nJID: ${target}\nNumber: ${jidNumber(target) || 'Unavailable'}\nName: ${target === context.senderJid ? context.senderName : 'Not available in local message data'}\nBio: ${status}\nPicture: ${picture}`
  }
  if (name === 'quoted') {
    const quoted = getQuotedMessage(context.message)
    if (!quoted) throw new AppError('Reply to a message', 400, 'QUOTED_MESSAGE_REQUIRED')
    const text = extractText(quoted.message)
    return truncate(`Quoted message ID: ${quoted.key.id || 'Unknown'}\nParticipant: ${quoted.key.participant || 'Unknown'}\nType: ${Object.keys(quoted.message || {})[0] || 'Unknown'}\nText: ${text || '[non-text media]'}`)
  }
  if (name === 'save') return executeMedia('save', context)
  if (name === 'report') {
    const issue = requireInput(context, 'Describe the issue you want to report').slice(0, 1500)
    await Log.create({ level: 'audit', sessionId: context.session.sessionId, user: context.senderJid, group: context.isGroup ? context.chatJid : null, command: 'report', status: 'submitted', message: issue })
    const ownerJid = `${env.botOwnerNumber}@s.whatsapp.net`
    if (ownerJid !== context.chatJid) {
      await context.sock.sendMessage(ownerJid, { text: `${env.botName} issue report\nFrom: ${context.senderJid}\nChat: ${context.chatJid}\n\n${issue}` }).catch(() => {})
    }
    return 'Your report was recorded and forwarded to the bot owner when delivery was available.'
  }
  throw new AppError(`WhatsApp action is not implemented: ${name}`, 500, 'COMMAND_ACTION_MISSING')
}
