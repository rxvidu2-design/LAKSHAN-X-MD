import { Farewell, GroupSetting, Welcome } from '../../models/index.js'
import { AppError } from '../../utils/AppError.js'
import { parseToggle, requireInput } from './helpers.js'

const fields = {
  welcome: 'welcome', goodbye: 'farewell', antilink: 'antiLink', antispam: 'antiSpam', antibadword: 'antiBadWord', antidelete: 'antiDelete',
  antiviewonce: 'antiViewOnce', antimention: 'antiMention', antiflood: 'antiFlood', autoreact: 'autoReact', autoread: 'autoRead',
  autotyping: 'autoTyping', autorecord: 'autoRecord', chatbot: 'chatbot', welcomeimg: 'welcomeImage', goodbyeimg: 'farewellImage'
}

export const executeGroupSetting = async (name, context) => {
  const key = { sessionId: context.session.sessionId, groupJid: context.chatJid }
  if (name === 'getprefix') {
    const settings = await GroupSetting.findOne(key).lean()
    return `Group prefix: ${settings?.prefix || context.prefix}`
  }
  if (name === 'setprefix') {
    const prefix = requireInput(context, 'Enter a prefix').trim()
    if (prefix.length > 5 || /\s/.test(prefix)) throw new AppError('Prefix must be 1-5 characters without spaces', 400, 'INVALID_PREFIX')
    await GroupSetting.findOneAndUpdate(key, { $set: { prefix, updatedBy: context.senderJid } }, { upsert: true, new: true, setDefaultsOnInsert: true })
    return `Group prefix updated to ${prefix}`
  }
  if (name === 'resetsettings') {
    await GroupSetting.deleteOne(key)
    await Promise.all([Welcome.deleteOne(key), Farewell.deleteOne(key)])
    return 'Group settings reset to safe defaults.'
  }
  const field = fields[name]
  if (!field) throw new AppError(`Group setting action is not implemented: ${name}`, 500, 'COMMAND_ACTION_MISSING')
  const enabled = parseToggle(context.args[0])
  await GroupSetting.findOneAndUpdate(key, { $set: { [field]: enabled, updatedBy: context.senderJid } }, { upsert: true, new: true, setDefaultsOnInsert: true })
  if (name === 'welcome') await Welcome.findOneAndUpdate(key, { $set: { enabled } }, { upsert: true, setDefaultsOnInsert: true })
  if (name === 'goodbye') await Farewell.findOneAndUpdate(key, { $set: { enabled } }, { upsert: true, setDefaultsOnInsert: true })
  return `${name} is now ${enabled ? 'enabled' : 'disabled'} for this group.`
}
