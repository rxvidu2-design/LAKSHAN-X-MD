import crypto from 'node:crypto'
import { resolveTargets, jidNumber } from '../../utils/message.js'
import { fetchJson, requireInput } from './helpers.js'

const truths = [
  'What is a goal you have not told anyone about?',
  'What habit would you most like to change?',
  'What is the kindest thing someone has done for you?',
  'What is a mistake that taught you something valuable?',
  'What are you most proud of this year?'
]
const dares = [
  'Send a sincere compliment to someone in this chat.',
  'Drink a glass of water before your next message.',
  'Write a four-line poem about today.',
  'Share one useful fact you learned recently.',
  'Do ten stretches and report when you finish.'
]
const roasts = [
  'Your loading screen has a loading screen.',
  'You bring everyone so much joy when the Wi-Fi reconnects.',
  'Your confidence is impressive; the evidence is still pending.',
  'You are not late; you are just operating in a different timezone.',
  'Your plan has excellent presentation and optional functionality.'
]
const compliments = [
  'You make difficult things feel manageable.',
  'Your curiosity is one of your strongest qualities.',
  'You bring thoughtful energy to the conversation.',
  'You are better at learning than you give yourself credit for.',
  'Your consistency is building something meaningful.'
]
const motivations = [
  'Small progress repeated consistently becomes a major result.',
  'Start with the next clear step, not the entire staircase.',
  'A difficult day does not erase the work you have already done.',
  'Discipline is choosing the future you want over the comfort of the moment.',
  'You do not need perfect conditions to make useful progress.'
]

const pick = values => values[crypto.randomInt(values.length)]
const deterministicScore = input => crypto.createHash('sha256').update(input).digest().readUInt32BE(0) % 101

export const executeFun = async (name, context) => {
  if (name === 'joke') {
    try {
      const data = await fetchJson('https://official-joke-api.appspot.com/random_joke')
      return `${data.setup}\n\n${data.punchline}`
    } catch {
      return 'Why did the developer go broke? Because they used up all their cache.'
    }
  }
  if (name === 'fact') {
    try {
      const data = await fetchJson('https://uselessfacts.jsph.pl/api/v2/facts/random?language=en')
      return data.text
    } catch {
      return 'Octopuses have three hearts and blue blood.'
    }
  }
  if (name === 'truth') return pick(truths)
  if (name === 'dare') return pick(dares)
  if (name === 'roast') return pick(roasts)
  if (name === 'compliment') return pick(compliments)
  if (name === 'motivate') return pick(motivations)
  if (['ship', 'love'].includes(name)) {
    const target = resolveTargets(context)[0] || context.args[0] || context.chatJid
    const pair = [context.senderJid, target].sort().join(':')
    return `Compatibility: ${deterministicScore(pair)}%\n@${jidNumber(context.senderJid)} + @${jidNumber(target)}`
  }
  if (name === 'rate') {
    const subject = requireInput(context, 'Enter something to rate')
    return `${subject}: ${deterministicScore(subject.toLowerCase())}/100`
  }
  throw new Error(`Fun action is not implemented: ${name}`)
}
