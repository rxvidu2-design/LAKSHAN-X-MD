import { XMLParser } from 'fast-xml-parser'
import { env } from '../../config/env.js'
import { AppError } from '../../utils/AppError.js'
import { sasaApi } from '../sasaApi.js'
import { apiResult, fetchJson, formatData, requireInput, truncate } from './helpers.js'

const xmlParser = new XMLParser({ ignoreAttributes: false })
const queryUrl = (base, params) => {
  const url = new URL(base)
  for (const [key, value] of Object.entries(params)) if (value !== undefined && value !== '') url.searchParams.set(key, String(value))
  return url.toString()
}

const wikipedia = async query => {
  const data = await fetchJson(queryUrl('https://en.wikipedia.org/w/api.php', {
    action: 'query', generator: 'search', gsrsearch: query, gsrlimit: 5, prop: 'extracts|info', exintro: 1, explaintext: 1, inprop: 'url', format: 'json', origin: '*'
  }))
  const pages = Object.values(data.query?.pages || {}).sort((a, b) => a.index - b.index)
  if (!pages.length) return 'No Wikipedia articles found.'
  return pages.map((page, index) => `${index + 1}. ${page.title}\n${String(page.extract || '').slice(0, 550)}\n${page.fullurl}`).join('\n\n')
}

const bing = async query => {
  const response = await fetch(queryUrl('https://www.bing.com/search', { q: query, format: 'rss' }), { headers: { 'user-agent': 'Sasa-Dev-Official/1.0' } })
  if (!response.ok) throw new AppError(`Bing returned HTTP ${response.status}`, 502, 'BING_SEARCH_ERROR')
  const parsed = xmlParser.parse(await response.text())
  const items = parsed?.rss?.channel?.item || []
  return (Array.isArray(items) ? items : [items]).slice(0, 8).map((item, index) => `${index + 1}. ${item.title}\n${item.description || ''}\n${item.link}`).join('\n\n') || 'No Bing results found.'
}

const lyrics = async query => {
  const results = await fetchJson(queryUrl('https://lrclib.net/api/search', { q: query }))
  if (!Array.isArray(results) || !results.length) return 'No lyrics found.'
  const result = results[0]
  return `${result.trackName || query} — ${result.artistName || 'Unknown'}\n\n${result.plainLyrics || result.syncedLyrics || 'Lyrics unavailable'}`
}

const dictionary = async word => {
  const entries = await fetchJson(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(word)}`)
  if (!Array.isArray(entries) || !entries.length) return 'No definition found.'
  const entry = entries[0]
  const lines = []
  for (const meaning of entry.meanings?.slice(0, 4) || []) {
    lines.push(`${meaning.partOfSpeech}\n${meaning.definitions?.slice(0, 3).map((definition, index) => `${index + 1}. ${definition.definition}${definition.example ? `\nExample: ${definition.example}` : ''}`).join('\n')}`)
  }
  return `${entry.word}${entry.phonetic ? ` — ${entry.phonetic}` : ''}\n\n${lines.join('\n\n')}`
}

const tmdb = async (query, type) => {
  if (!env.isConfigured(env.tmdbApiKey)) return apiResult('Movie search results', await sasaApi.call('movie', { query }))
  const data = await fetchJson(queryUrl(`https://api.themoviedb.org/3/search/${type}`, { api_key: env.tmdbApiKey, query, include_adult: false }))
  const results = data.results?.slice(0, 7) || []
  return results.length ? results.map((item, index) => `${index + 1}. ${item.title || item.name}\nRelease: ${item.release_date || item.first_air_date || 'Unknown'}\nRating: ${item.vote_average ?? 'Unknown'}\n${String(item.overview || '').slice(0, 350)}`).join('\n\n') : 'No titles found.'
}

const jikan = async (query, type) => {
  const data = await fetchJson(queryUrl(`https://api.jikan.moe/v4/${type}`, { q: query, limit: 6, sfw: true }))
  return data.data?.length ? data.data.map((item, index) => `${index + 1}. ${item.title}\nScore: ${item.score ?? 'Unknown'}\nStatus: ${item.status || 'Unknown'}\n${item.url}`).join('\n\n') : `No ${type} results found.`
}

const githubSearch = async query => {
  const data = await fetchJson(queryUrl('https://api.github.com/search/repositories', { q: query, per_page: 7 }), { headers: { 'user-agent': 'Sasa-Dev-Official/1.0', accept: 'application/vnd.github+json' } })
  return data.items?.length ? data.items.map((item, index) => `${index + 1}. ${item.full_name}\nStars: ${item.stargazers_count}  Language: ${item.language || 'Unknown'}\n${item.description || 'No description'}\n${item.html_url}`).join('\n\n') : 'No repositories found.'
}

const npmSearch = async query => {
  const data = await fetchJson(queryUrl('https://registry.npmjs.org/-/v1/search', { text: query, size: 8 }))
  return data.objects?.length ? data.objects.map((item, index) => `${index + 1}. ${item.package.name}@${item.package.version}\n${item.package.description || 'No description'}\n${item.package.links?.npm || ''}`).join('\n\n') : 'No packages found.'
}

const weather = async place => {
  const geo = await fetchJson(queryUrl('https://geocoding-api.open-meteo.com/v1/search', { name: place, count: 1, language: 'en', format: 'json' }))
  const location = geo.results?.[0]
  if (!location) return 'Location not found.'
  const data = await fetchJson(queryUrl('https://api.open-meteo.com/v1/forecast', {
    latitude: location.latitude, longitude: location.longitude, current: 'temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,wind_speed_10m,weather_code', timezone: 'auto'
  }))
  return `${location.name}, ${location.country}\nTemperature: ${data.current?.temperature_2m} ${data.current_units?.temperature_2m}\nFeels like: ${data.current?.apparent_temperature} ${data.current_units?.apparent_temperature}\nHumidity: ${data.current?.relative_humidity_2m}${data.current_units?.relative_humidity_2m}\nWind: ${data.current?.wind_speed_10m} ${data.current_units?.wind_speed_10m}\nPrecipitation: ${data.current?.precipitation} ${data.current_units?.precipitation}\nObserved: ${data.current?.time}`
}

const cryptoPrice = async query => {
  const search = await fetchJson(queryUrl('https://api.coingecko.com/api/v3/search', { query }))
  const coin = search.coins?.[0]
  if (!coin) return 'Cryptocurrency not found.'
  const data = await fetchJson(queryUrl('https://api.coingecko.com/api/v3/simple/price', { ids: coin.id, vs_currencies: 'usd,lkr', include_24hr_change: true, include_last_updated_at: true }))
  const price = data[coin.id]
  return `${coin.name} (${coin.symbol.toUpperCase()})\nUSD: ${price.usd}\nLKR: ${price.lkr}\n24h change: ${Number(price.usd_24h_change || 0).toFixed(2)}%`
}

const currency = async input => {
  const match = input.toUpperCase().match(/^([0-9]+(?:\.[0-9]+)?)\s+([A-Z]{3})\s+(?:TO\s+)?([A-Z]{3})$/)
  if (!match) throw new AppError('Use: amount FROM TO, for example 100 USD LKR', 400, 'INVALID_CURRENCY_INPUT')
  const [, amount, from, to] = match
  const data = await fetchJson(queryUrl('https://api.frankfurter.app/latest', { amount, from, to }))
  if (data.rates?.[to] === undefined) return 'The requested conversion is unavailable.'
  return `${amount} ${from} = ${data.rates[to]} ${to}\nReference date: ${data.date}`
}

const timezone = async zone => {
  const data = await fetchJson(`https://worldtimeapi.org/api/timezone/${encodeURI(zone)}`)
  return `${data.timezone}\nLocal time: ${data.datetime}\nUTC offset: ${data.utc_offset}\nDay of year: ${data.day_of_year}`
}

export const executeSearch = async (name, context) => {
  const query = requireInput(context, `Enter a ${name} search query`)
  if (name === 'google') return apiResult('Google search results', await sasaApi.call('google', { query }))
  if (name === 'bing') return truncate(await bing(query))
  if (['image', 'img'].includes(name)) return apiResult('Image search results', await sasaApi.call('image', { query }))
  if (name === 'news') return apiResult('Current news', await sasaApi.call('news', { query }))
  if (['wiki', 'wikipedia'].includes(name)) return truncate(await wikipedia(query))
  if (name === 'lyrics') return truncate(await lyrics(query))
  if (['define', 'meaning'].includes(name)) return truncate(await dictionary(query.split(/\s+/)[0]))
  if (name === 'movie') return truncate(await tmdb(query, 'movie'))
  if (name === 'tv') return truncate(await tmdb(query, 'tv'))
  if (name === 'anime') return truncate(await jikan(query, 'anime'))
  if (name === 'manga') return truncate(await jikan(query, 'manga'))
  if (name === 'githubsearch') return truncate(await githubSearch(query))
  if (name === 'npm') return truncate(await npmSearch(query))
  if (name === 'weather') return weather(query)
  if (name === 'crypto') return cryptoPrice(query)
  if (name === 'currency') return currency(query)
  if (name === 'time') return timezone(query)
  throw new AppError(`Search action is not implemented: ${name}`, 500, 'COMMAND_ACTION_MISSING')
}
