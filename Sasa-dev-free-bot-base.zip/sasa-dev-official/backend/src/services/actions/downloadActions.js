import { sasaApi } from '../sasaApi.js'
import { AppError } from '../../utils/AppError.js'
import { apiResult, requireInput, requireUrl } from './helpers.js'

const adapters = {
  facebook: 'facebook', instagram: 'instagram', ig: 'instagram', tiktok: 'tiktok', tt: 'tiktok', twitter: 'twitter', xdl: 'twitter',
  ytmp3: 'youtubeAudio', yta: 'youtubeAudio', ytmp4: 'youtubeVideo', ytv: 'youtubeVideo', mediafire: 'mediafire', drive: 'gdrive', pinterest: 'pinterestDownload'
}

const githubArchive = async input => {
  let url
  try { url = new URL(input) } catch { throw new AppError('Enter a valid GitHub repository URL', 400, 'INVALID_GITHUB_URL') }
  if (url.hostname !== 'github.com') throw new AppError('Only github.com repository URLs are accepted', 400, 'INVALID_GITHUB_URL')
  const [owner, repositoryRaw] = url.pathname.split('/').filter(Boolean)
  const repository = repositoryRaw?.replace(/\.git$/, '')
  if (!owner || !repository) throw new AppError('Enter a GitHub repository URL', 400, 'INVALID_GITHUB_URL')
  const response = await fetch(`https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repository)}`, { headers: { accept: 'application/vnd.github+json', 'user-agent': 'Sasa-Dev-Official/1.0' } })
  if (!response.ok) throw new AppError(`GitHub returned HTTP ${response.status}`, response.status === 404 ? 404 : 502, 'GITHUB_API_ERROR')
  const data = await response.json()
  return `Repository: ${data.full_name}\nDescription: ${data.description || 'No description'}\nDefault branch: ${data.default_branch}\nArchive: https://github.com/${data.full_name}/archive/refs/heads/${encodeURIComponent(data.default_branch)}.zip`
}

export const executeDownload = async (name, context) => {
  if (['song', 'play'].includes(name)) {
    const query = requireInput(context, 'Enter a song or video title')
    return apiResult('YouTube search results', await sasaApi.call('youtubeSearch', { query }))
  }
  if (name === 'pin') {
    const query = requireInput(context, 'Enter a Pinterest search query')
    return apiResult('Pinterest search results', await sasaApi.call('pinterestSearch', { query }))
  }
  if (name === 'apk') {
    const query = requireInput(context, 'Enter an application name or package ID')
    return apiResult('APK search results', await sasaApi.call('apk', { query }))
  }
  if (name === 'github') return githubArchive(requireInput(context, 'Enter a GitHub repository URL'))
  if (name === 'mega') {
    await requireUrl(context)
    throw new AppError('No verified Mega download route is currently available from the configured provider', 503, 'DOWNLOAD_PROVIDER_UNAVAILABLE')
  }
  const adapter = adapters[name]
  if (!adapter) throw new AppError(`Download action is not implemented: ${name}`, 500, 'COMMAND_ACTION_MISSING')
  const url = await requireUrl(context)
  return apiResult(`${name.toUpperCase()} result`, await sasaApi.call(adapter, { url }))
}
