import { AppError } from '../../utils/AppError.js'
import { chatCompletion, synthesizeSpeech, transcribeAudio } from '../aiService.js'
import { sasaApi } from '../sasaApi.js'
import { downloadMessageMedia } from '../mediaService.js'
import { apiResult, requireInput, truncate } from './helpers.js'

const splitPipe = (value, fallback) => {
  const parts = value.split('|').map(part => part.trim())
  if (parts.length < 2 || !parts[1]) return [fallback, value.trim()]
  return [parts[0] || fallback, parts.slice(1).join(' | ')]
}

const prompts = {
  debug: input => `Analyze this code or error. Identify the root cause and provide a corrected solution:\n\n${input}`,
  explain: input => `Explain the following clearly with a concise example where useful:\n\n${input}`,
  prompt: input => `Rewrite this draft into a precise, effective AI prompt. Return the improved prompt and a short rationale:\n\n${input}`,
  quiz: input => `Create a five-question quiz about ${input}. Include answers after a clear separator.`,
  story: input => `Write an original, engaging short story about ${input}. Keep it suitable for a general audience.`
}

export const executeAi = async (name, context) => {
  if (name === 'imagine') {
    const text = requireInput(context, 'Enter an image prompt')
    return apiResult('Generated image result', await sasaApi.call('aiImage', { text }))
  }
  if (['vision', 'ocr'].includes(name)) {
    const media = await downloadMessageMedia(context.sock, context.message)
    if (!media.type.toLowerCase().includes('image')) throw new AppError('Reply to an image', 400, 'IMAGE_REQUIRED')
    const prompt = name === 'ocr' ? 'Extract all visible text exactly. Preserve line breaks and identify the language.' : (context.text || 'Describe and analyze this image.')
    return truncate(await chatCompletion({ prompt, image: { buffer: media.buffer, mimeType: media.mimeType || 'image/jpeg' }, provider: 'gemini' }))
  }
  if (name === 'stt') {
    const media = await downloadMessageMedia(context.sock, context.message)
    if (!/(audio|video)/i.test(media.type)) throw new AppError('Reply to an audio or video message', 400, 'AUDIO_REQUIRED')
    return truncate(await transcribeAudio({ buffer: media.buffer, fileName: media.fileName || 'audio.ogg', mimeType: media.mimeType || 'audio/ogg', language: context.args[0] }))
  }
  if (name === 'tts') {
    const [language, text] = splitPipe(requireInput(context, 'Use: language | text'), 'en')
    const localAudio = await synthesizeSpeech({ text: text.slice(0, 3500) })
    if (localAudio) {
      await context.send({ audio: localAudio, mimetype: 'audio/mpeg', ptt: false, fileName: 'sasa-dev-tts.mp3' })
      return null
    }
    return apiResult('Text-to-speech result', await sasaApi.call('textToSpeech', { text, language }))
  }
  if (name === 'summarize') {
    const text = requireInput(context, 'Enter text to summarize')
    try { return truncate((await sasaApi.call('summarize', { text })).data) } catch { return truncate(await chatCompletion({ prompt: `Summarize this into concise key points:\n\n${text}` })) }
  }
  if (name === 'translate') {
    const [target, text] = splitPipe(requireInput(context, 'Use: target language | text'), 'English')
    try { return truncate((await sasaApi.call('translate', { text, target })).data) } catch { return truncate(await chatCompletion({ prompt: `Translate the following into ${target}. Return only the translation:\n\n${text}` })) }
  }
  if (name === 'rewrite') {
    const [tone, text] = splitPipe(requireInput(context, 'Use: tone | text'), 'clear professional')
    try { return truncate((await sasaApi.call('rewrite', { text, tone })).data) } catch { return truncate(await chatCompletion({ prompt: `Rewrite this in a ${tone} tone:\n\n${text}` })) }
  }
  const input = requireInput(context, 'Enter a message or prompt')
  const provider = name === 'gemini' ? 'gemini' : name === 'groq' ? 'groq' : name === 'gpt' ? 'openai' : 'auto'
  const prompt = name === 'code' ? `Provide production-quality coding help for this request:\n\n${input}` : prompts[name]?.(input) || input
  const system = name === 'code' || name === 'debug' ? 'You are Sasa Dev Official, a senior software engineer. Give safe, accurate, production-oriented help.' : 'You are Sasa Dev Official, a concise, accurate, and helpful assistant. Do not invent facts.'
  return truncate(await chatCompletion({ prompt, system, provider }))
}
