import { AppError } from '../../utils/AppError.js'
import { safeFetch, validatePublicUrl } from '../networkService.js'

export const requireInput = (context, message = 'This command requires input') => {
  const value = context.text.trim()
  if (!value) throw new AppError(message, 400, 'COMMAND_INPUT_REQUIRED')
  return value
}

export const requireUrl = async context => {
  const value = requireInput(context, 'Enter a public HTTP or HTTPS URL')
  return (await validatePublicUrl(value)).toString()
}

export const truncate = (value, length = 3900) => {
  const text = String(value ?? '')
  return text.length <= length ? text : `${text.slice(0, length - 18)}\n[output truncated]`
}

const renderPrimitive = value => {
  if (value === null || value === undefined) return 'Unavailable'
  if (typeof value === 'boolean') return value ? 'Yes' : 'No'
  return String(value)
}

const humanize = key => String(key).replace(/[_-]+/g, ' ').replace(/\b\w/g, character => character.toUpperCase())

export const formatData = (data, depth = 0) => {
  if (data === null || data === undefined) return 'No result data was returned.'
  if (typeof data !== 'object') return renderPrimitive(data)
  if (Array.isArray(data)) {
    if (!data.length) return 'No results found.'
    return data.slice(0, 8).map((item, index) => {
      const rendered = formatData(item, depth + 1)
      return `${index + 1}. ${rendered.replace(/\n/g, '\n   ')}`
    }).join('\n\n')
  }
  const entries = Object.entries(data).filter(([, value]) => value !== null && value !== undefined)
  if (!entries.length) return 'No result data was returned.'
  return entries.slice(0, depth ? 10 : 16).map(([key, value]) => {
    if (typeof value === 'object') return `${humanize(key)}:\n${formatData(value, depth + 1).split('\n').map(line => `  ${line}`).join('\n')}`
    return `${humanize(key)}: ${renderPrimitive(value)}`
  }).join('\n')
}

export const apiResult = (title, response) => truncate(`${title}\n\n${formatData(response.data)}`)

export const fetchJson = async (url, options = {}) => {
  const response = await safeFetch(url, { ...options, headers: { accept: 'application/json', ...(options.headers || {}) } })
  const text = await response.text()
  if (!response.ok) throw new AppError(`Remote service returned HTTP ${response.status}`, 502, 'REMOTE_SERVICE_ERROR')
  if (text.length > 2_000_000) throw new AppError('Remote response exceeded the safe size limit', 502, 'REMOTE_RESPONSE_TOO_LARGE')
  try {
    return JSON.parse(text)
  } catch {
    throw new AppError('Remote service returned invalid JSON', 502, 'REMOTE_INVALID_JSON')
  }
}

export const parseToggle = input => {
  const value = String(input || '').trim().toLowerCase()
  if (['on', 'enable', 'enabled', '1', 'true'].includes(value)) return true
  if (['off', 'disable', 'disabled', '0', 'false'].includes(value)) return false
  throw new AppError('Use on or off', 400, 'INVALID_TOGGLE')
}

export const formatDuration = milliseconds => {
  const seconds = Math.floor(milliseconds / 1000)
  const days = Math.floor(seconds / 86400)
  const hours = Math.floor((seconds % 86400) / 3600)
  const minutes = Math.floor((seconds % 3600) / 60)
  const remaining = seconds % 60
  return [days && `${days}d`, hours && `${hours}h`, minutes && `${minutes}m`, `${remaining}s`].filter(Boolean).join(' ')
}
