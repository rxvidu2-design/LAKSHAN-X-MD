import { AppError } from '../../utils/AppError.js'
import { executeAi } from './aiActions.js'
import { executeDownload } from './downloadActions.js'
import { executeFun } from './funActions.js'
import { executeGroup } from './groupActions.js'
import { executeGroupSetting } from './groupSettingActions.js'
import { executeMedia } from './mediaActions.js'
import { executeOwner } from './ownerActions.js'
import { executeSearch } from './searchActions.js'
import { executeSystem } from './systemActions.js'
import { executeUtility } from './utilityActions.js'
import { executeWhatsApp } from './whatsappActions.js'

const executors = Object.freeze({
  system: executeSystem,
  media: executeMedia,
  downloader: executeDownload,
  search: executeSearch,
  ai: executeAi,
  group: executeGroup,
  admin: executeGroupSetting,
  owner: executeOwner,
  utility: executeUtility,
  fun: executeFun,
  whatsapp: executeWhatsApp
})

export const executeCommand = async (name, context) => {
  const executor = executors[context.command.category]
  if (!executor) throw new AppError(`No executor exists for category ${context.command.category}`, 500, 'COMMAND_ACTION_MISSING')
  const result = await executor(name, context)
  if (result !== null && result !== undefined && result !== '') await context.reply(String(result))
  return result
}
