import { Ban, GroupSetting, Warning } from '../../models/index.js'
import { AppError } from '../../utils/AppError.js'
import { jidNumber, resolveTargets } from '../../utils/message.js'
import { downloadMessageMedia } from '../mediaService.js'
import { requireInput } from './helpers.js'

const targetsOrThrow = context => {
  const targets = resolveTargets(context)
  if (!targets.length) throw new AppError('Mention, reply to, or provide a phone number for at least one participant', 400, 'PARTICIPANT_REQUIRED')
  return targets
}

const updateParticipants = async (context, action) => {
  const targets = targetsOrThrow(context)
  const result = await context.sock.groupParticipantsUpdate(context.chatJid, targets, action)
  const failures = result.filter(item => item.status && String(item.status) !== '200')
  return `${action} requested for ${targets.length} participant(s).${failures.length ? `\n${failures.length} operation(s) were rejected by WhatsApp.` : ''}`
}

export const executeGroup = async (name, context) => {
  if (['tagall', 'hidetag', 'everyone'].includes(name)) {
    const participants = context.groupMetadata.participants.map(participant => participant.id)
    const message = name === 'hidetag' ? (context.text || 'Group announcement') : `${context.text || 'Group announcement'}\n\n${participants.map(jid => `@${jidNumber(jid)}`).join(' ')}`
    await context.send({ text: message, mentions: participants })
    return null
  }
  if (name === 'kick') return updateParticipants(context, 'remove')
  if (name === 'add') return updateParticipants(context, 'add')
  if (name === 'promote') return updateParticipants(context, 'promote')
  if (name === 'demote') return updateParticipants(context, 'demote')
  if (['mute', 'close'].includes(name)) {
    await context.sock.groupSettingUpdate(context.chatJid, 'announcement')
    return 'Group messaging is now restricted to administrators.'
  }
  if (['unmute', 'open'].includes(name)) {
    await context.sock.groupSettingUpdate(context.chatJid, 'not_announcement')
    return 'Group messaging is now open to all participants.'
  }
  if (name === 'warn') {
    const target = targetsOrThrow(context)[0]
    const reason = context.args.filter(arg => !arg.startsWith('@') && !/^\+?\d{8,15}$/.test(arg)).join(' ') || 'Group rule violation'
    await Warning.create({ sessionId: context.session.sessionId, groupJid: context.chatJid, userJid: target, reason, issuedBy: context.senderJid })
    const count = await Warning.countDocuments({ sessionId: context.session.sessionId, groupJid: context.chatJid, userJid: target, active: true })
    return `Warning issued to @${jidNumber(target)}. Active warnings: ${count}.`
  }
  if (name === 'unwarn') {
    const target = targetsOrThrow(context)[0]
    const warning = await Warning.findOneAndUpdate({ sessionId: context.session.sessionId, groupJid: context.chatJid, userJid: target, active: true }, { $set: { active: false } }, { sort: { createdAt: -1 }, new: true })
    if (!warning) throw new AppError('No active warning was found for that participant', 404, 'WARNING_NOT_FOUND')
    return `Latest warning removed for @${jidNumber(target)}.`
  }
  if (name === 'warnings') {
    const target = resolveTargets(context)[0] || context.senderJid
    const warnings = await Warning.find({ sessionId: context.session.sessionId, groupJid: context.chatJid, userJid: target, active: true }).sort({ createdAt: -1 }).limit(10).lean()
    if (!warnings.length) return `@${jidNumber(target)} has no active warnings.`
    return `Warnings for @${jidNumber(target)}\n\n${warnings.map((warning, index) => `${index + 1}. ${warning.reason}\n${warning.createdAt.toISOString()}`).join('\n\n')}`
  }
  if (name === 'ban') {
    const target = targetsOrThrow(context)[0]
    const reason = context.args.filter(arg => !arg.startsWith('@') && !/^\+?\d{8,15}$/.test(arg)).join(' ') || 'Banned by a group administrator'
    await Ban.findOneAndUpdate({ sessionId: context.session.sessionId, targetJid: target, scope: 'group', groupJid: context.chatJid }, { $set: { reason, active: true, createdBy: context.senderJid, expiresAt: null } }, { upsert: true, new: true })
    return `@${jidNumber(target)} is now blocked from using bot commands in this group.`
  }
  if (name === 'unban') {
    const target = targetsOrThrow(context)[0]
    const result = await Ban.updateMany({ sessionId: context.session.sessionId, targetJid: target, scope: 'group', groupJid: context.chatJid, active: true }, { $set: { active: false } })
    if (!result.modifiedCount) throw new AppError('No active group ban was found', 404, 'BAN_NOT_FOUND')
    return `Command ban removed for @${jidNumber(target)}.`
  }
  if (name === 'groupinfo') {
    const metadata = context.groupMetadata
    return `${metadata.subject}\nJID: ${metadata.id}\nParticipants: ${metadata.participants.length}\nOwner: ${metadata.ownerPn || metadata.owner || 'Unknown'}\nCreated: ${metadata.creation ? new Date(metadata.creation * 1000).toISOString() : 'Unknown'}\nRestricted: ${metadata.restrict ? 'Yes' : 'No'}\nAnnouncements only: ${metadata.announce ? 'Yes' : 'No'}\n\n${metadata.desc || 'No group description.'}`
  }
  if (name === 'setname') {
    const subject = requireInput(context, 'Enter a new group name').slice(0, 100)
    await context.sock.groupUpdateSubject(context.chatJid, subject)
    return `Group name changed to: ${subject}`
  }
  if (name === 'setdesc') {
    const description = requireInput(context, 'Enter a new group description').slice(0, 2000)
    await context.sock.groupUpdateDescription(context.chatJid, description)
    return 'Group description updated.'
  }
  if (name === 'setphoto') {
    const media = await downloadMessageMedia(context.sock, context.message)
    if (!/image/i.test(media.type)) throw new AppError('Reply to an image', 400, 'IMAGE_REQUIRED')
    await context.sock.updateProfilePicture(context.chatJid, media.buffer)
    return 'Group profile picture updated.'
  }
  if (name === 'approve') {
    if (typeof context.sock.groupRequestParticipantsList !== 'function') throw new AppError('Join-request management is unavailable in this Baileys build', 503, 'GROUP_REQUESTS_UNAVAILABLE')
    const requests = await context.sock.groupRequestParticipantsList(context.chatJid)
    const jids = requests.map(request => request.jid).filter(Boolean)
    if (!jids.length) return 'There are no pending join requests.'
    await context.sock.groupRequestParticipantsUpdate(context.chatJid, jids, 'approve')
    return `${jids.length} pending join request(s) approved.`
  }
  throw new AppError(`Group action is not implemented: ${name}`, 500, 'COMMAND_ACTION_MISSING')
}
