import os from 'node:os'
import { APP_STARTED_AT, APP_VERSION, BOT_IDENTITY } from '../../config/constants.js'
import { env } from '../../config/env.js'
import { AppError } from '../../utils/AppError.js'
import { formatDuration } from './helpers.js'

const groupedCommands = registry => {
  const grouped = new Map()
  for (const command of registry.list()) {
    if (!grouped.has(command.category)) grouped.set(command.category, [])
    grouped.get(command.category).push(command)
  }
  return grouped
}

export const executeSystem = async (name, context) => {
  const uptime = Date.now() - APP_STARTED_AT
  if (name === 'menu') {
    const groups = [...groupedCommands(context.registry).entries()]
      .map(([category, commands]) => `${category.toUpperCase()}\n${commands.map(command => `${context.prefix}${command.name}`).join('  ')}`)
      .join('\n\n')
    return `${BOT_IDENTITY.name}\nCommand Center\n\n${groups}\n\nUse ${context.prefix}help <command> for details.`
  }
  if (name === 'help') {
    const requested = context.args[0]?.replace(context.prefix, '').toLowerCase()
    if (!requested) return `Use ${context.prefix}help <command> or ${context.prefix}menu.`
    const command = context.registry.get(requested)
    if (!command) throw new AppError('Command not found', 404, 'COMMAND_NOT_FOUND')
    return `${context.prefix}${command.name}\n${command.description}\nCategory: ${command.category}\nPermission: ${command.permission}\nCooldown: ${command.cooldown}s\nUsage: ${context.prefix}${command.name}${command.usage ? ` ${command.usage}` : ''}`
  }
  if (['commands', 'listcmd'].includes(name)) {
    const commands = context.registry.list()
    return `${commands.length} registered commands\n\n${commands.map(command => `${context.prefix}${command.name} — ${command.description}`).join('\n')}`
  }
  if (['ping', 'speed'].includes(name)) {
    const latency = Math.max(0, Date.now() - context.receivedAt)
    const started = process.hrtime.bigint()
    await Promise.resolve()
    const execution = Number(process.hrtime.bigint() - started) / 1e6
    return `Response latency: ${latency} ms\nExecution check: ${execution.toFixed(2)} ms`
  }
  if (name === 'alive') return `${BOT_IDENTITY.name} is online.\nSession: ${context.session.status}\nUptime: ${formatDuration(uptime)}`
  if (['runtime', 'uptime'].includes(name)) return `Uptime: ${formatDuration(uptime)}`
  if (name === 'status') return `Session: ${context.session.status}\nConnected number: ${context.session.connectedNumber || 'Not connected'}\nCommands: ${context.session.stats?.commandsExecuted || 0}\nMessages: ${context.session.stats?.messagesReceived || 0}`
  if (name === 'version') return `${BOT_IDENTITY.name} v${APP_VERSION}\nNode.js ${process.version}\nBaileys 7.x`
  if (['owner', 'dev'].includes(name)) return `${BOT_IDENTITY.owner}\nwa.me/${BOT_IDENTITY.ownerNumber}`
  if (['repo', 'source'].includes(name)) {
    if (!env.isConfigured(env.sourceUrl)) throw new AppError('Source repository URL is not configured', 503, 'SOURCE_URL_NOT_CONFIGURED')
    return env.sourceUrl
  }
  if (name === 'channel') return BOT_IDENTITY.channelUrl
  if (name === 'support') return `${context.globalSettings?.supportMessage || 'Contact the official support channel.'}\n${BOT_IDENTITY.supportUrl}`
  if (['botinfo', 'info', 'about'].includes(name)) {
    return `${BOT_IDENTITY.name} v${APP_VERSION}\nOwner: ${BOT_IDENTITY.owner}\nPrefix: ${context.prefix}\nCommands: ${context.registry.size}\nRuntime: ${formatDuration(uptime)}\nPlatform: ${os.platform()} ${os.arch()}\nSession: ${context.session.status}\nChannel: ${BOT_IDENTITY.channelUrl}`
  }
  throw new AppError(`System action is not implemented: ${name}`, 500, 'COMMAND_ACTION_MISSING')
}
