import { env } from '../../config/env.js'
import { AppError } from '../../utils/AppError.js'
import { extractText, getQuotedMessage, resolveTargets } from '../../utils/message.js'
import { fetchBuffer } from '../networkService.js'
import {
  blurImage, compressImage, createMeme, createQuoteCard, cropImage, downloadMessageMedia, enhanceImage, imageToSticker,
  readQrFromImage, resizeImage, stickerToImage, transcode, videoToSticker
} from '../mediaService.js'

const extensionFor = media => {
  if (media.mimeType.includes('webp')) return 'webp'
  if (media.mimeType.includes('ogg')) return 'ogg'
  if (media.mimeType.includes('mpeg')) return 'mp3'
  if (media.mimeType.includes('mp4')) return 'mp4'
  if (media.mimeType.includes('png')) return 'png'
  return 'bin'
}

const resend = async context => {
  const media = await downloadMessageMedia(context.sock, context.message)
  if (/image/i.test(media.type)) await context.send({ image: media.buffer, caption: 'Recovered media' })
  else if (/video/i.test(media.type)) await context.send({ video: media.buffer, caption: 'Recovered media' })
  else if (/audio/i.test(media.type)) await context.send({ audio: media.buffer, mimetype: media.mimeType || 'audio/ogg', ptt: false })
  else if (/sticker/i.test(media.type)) await context.send({ sticker: media.buffer })
  else await context.send({ document: media.buffer, mimetype: media.mimeType || 'application/octet-stream', fileName: media.fileName || 'recovered-file' })
  return null
}

const removeBackground = async buffer => {
  if (!env.isConfigured(env.removeBgApiKey)) throw new AppError('REMOVE_BG_API_KEY is not configured', 503, 'REMOVE_BG_NOT_CONFIGURED')
  const form = new FormData()
  form.append('image_file', new Blob([buffer]), 'image.png')
  form.append('size', 'auto')
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), 90000)
  try {
    const response = await fetch('https://api.remove.bg/v1.0/removebg', { method: 'POST', headers: { 'x-api-key': env.removeBgApiKey }, body: form, signal: controller.signal })
    if (!response.ok) {
      const data = await response.json().catch(() => ({}))
      throw new AppError(data.errors?.[0]?.title || `Remove.bg returned HTTP ${response.status}`, 502, 'REMOVE_BG_FAILED')
    }
    return Buffer.from(await response.arrayBuffer())
  } catch (error) {
    if (error.name === 'AbortError') throw new AppError('Background removal timed out', 504, 'REMOVE_BG_TIMEOUT')
    throw error
  } finally {
    clearTimeout(timer)
  }
}

export const executeMedia = async (name, context) => {
  if (['vv', 'save'].includes(name)) return resend(context)
  if (['getdp', 'getpp'].includes(name)) {
    const target = resolveTargets(context)[0] || context.senderJid
    let url
    try { url = await context.sock.profilePictureUrl(target, 'image') } catch { throw new AppError('Profile picture is unavailable or private', 404, 'PROFILE_PICTURE_UNAVAILABLE') }
    const { buffer } = await fetchBuffer(url, { maxBytes: 8 * 1024 * 1024 })
    await context.send({ image: buffer, caption: `Profile picture: ${target}` })
    return null
  }
  if (name === 'quote') {
    const quoted = getQuotedMessage(context.message)
    const text = quoted ? extractText(quoted.message) : context.text
    if (!text) throw new AppError('Reply to a text message or provide quote text', 400, 'QUOTE_TEXT_REQUIRED')
    const card = await createQuoteCard({ quote: text, author: context.args.join(' ') || context.senderName })
    await context.send({ image: card, caption: env.botName })
    return null
  }
  const media = await downloadMessageMedia(context.sock, context.message)
  if (['sticker', 's'].includes(name)) {
    const sticker = /video/i.test(media.type) ? await videoToSticker(media.buffer) : await imageToSticker(media.buffer)
    await context.send({ sticker })
    return null
  }
  if (name === 'take') {
    if (!/sticker/i.test(media.type)) throw new AppError('Reply to a sticker', 400, 'STICKER_REQUIRED')
    const image = await stickerToImage(media.buffer)
    await context.send({ sticker: await imageToSticker(image, env.botName, env.botOwnerName) })
    return null
  }
  if (name === 'toimg') {
    if (!/sticker/i.test(media.type)) throw new AppError('Reply to a sticker', 400, 'STICKER_REQUIRED')
    await context.send({ image: await stickerToImage(media.buffer), caption: 'Converted from sticker' })
    return null
  }
  if (name === 'toaudio' || name === 'mp3') {
    const output = await transcode(media.buffer, extensionFor(media), 'mp3', ['-vn', '-ac', '2', '-ar', '44100', '-b:a', '192k'])
    await context.send({ audio: output, mimetype: 'audio/mpeg', ptt: false, fileName: 'sasa-dev-audio.mp3' })
    return null
  }
  if (name === 'tovideo' || name === 'mp4') {
    const output = await transcode(media.buffer, extensionFor(media), 'mp4', ['-movflags', '+faststart', '-pix_fmt', 'yuv420p', '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2', '-c:v', 'libx264', '-c:a', 'aac'])
    await context.send({ video: output, mimetype: 'video/mp4', caption: 'Converted video' })
    return null
  }
  if (name === 'gif') {
    const output = await transcode(media.buffer, extensionFor(media), 'gif', ['-t', '12', '-vf', 'fps=12,scale=480:-1:flags=lanczos'])
    await context.send({ document: output, mimetype: 'image/gif', fileName: 'sasa-dev.gif' })
    return null
  }
  if (!/(image|sticker)/i.test(media.type)) throw new AppError('Reply to an image', 400, 'IMAGE_REQUIRED')
  let output
  if (name === 'crop') output = await cropImage(media.buffer)
  else if (name === 'resize') {
    const match = context.text.match(/^(\d{2,4})(?:x|\s)(\d{2,4})$/i)
    if (!match) throw new AppError('Use dimensions such as 800x600', 400, 'INVALID_DIMENSIONS')
    const width = Math.min(4096, Number(match[1]))
    const height = Math.min(4096, Number(match[2]))
    output = await resizeImage(media.buffer, width, height)
  } else if (name === 'compress') {
    const quality = Math.min(95, Math.max(20, Number(context.args[0]) || 70))
    output = await compressImage(media.buffer, quality)
  } else if (name === 'blur') {
    const strength = Math.min(20, Math.max(1, Number(context.args[0]) || 8))
    output = await blurImage(media.buffer, strength)
  } else if (['enhance', 'remini'].includes(name)) output = await enhanceImage(media.buffer)
  else if (name === 'removebg') output = await removeBackground(media.buffer)
  else if (name === 'meme') {
    const [top = '', bottom = ''] = context.text.split('|').map(value => value.trim())
    if (!top && !bottom) throw new AppError('Use: top text | bottom text', 400, 'MEME_TEXT_REQUIRED')
    output = await createMeme(media.buffer, top, bottom)
  } else if (name === 'readqr') return readQrFromImage(media.buffer)
  else throw new AppError(`Media action is not implemented: ${name}`, 500, 'COMMAND_ACTION_MISSING')
  await context.send({ image: output, caption: `${name} completed` })
  return null
}
