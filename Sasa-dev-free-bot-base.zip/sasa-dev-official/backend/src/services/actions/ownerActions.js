import vm from 'node:vm'
import { spawn } from 'node:child_process'
import { env } from '../../config/env.js'
import { Ban, Bot, GroupSetting, Log, Session, Setting } from '../../models/index.js'
import { AppError } from '../../utils/AppError.js'
import { normalizePhoneNumber } from '../../utils/validation.js'
import { fetchBuffer, validatePublicUrl } from '../networkService.js'
import { requireInput, truncate } from './helpers.js'

const delay = milliseconds => new Promise(resolve => setTimeout(resolve, milliseconds))

const splitCommandLine = input => {
  const tokens = []
  const pattern = /"([^"\\]*(?:\\.[^"\\]*)*)"|'([^'\\]*(?:\\.[^'\\]*)*)'|([^\s]+)/g
  let match
  while ((match = pattern.exec(input))) tokens.push((match[1] ?? match[2] ?? match[3]).replace(/\\([\\"'])/g, '$1'))
  return tokens
}

const runExecutable = async input => {
  if (!env.enableDangerousCommands) throw new AppError('Maintenance execution is disabled by configuration', 403, 'DANGEROUS_COMMANDS_DISABLED')
  const [executable, ...args] = splitCommandLine(input)
  if (!executable || !env.allowedShellCommands.includes(executable)) throw new AppError(`Executable is not allow-listed. Allowed: ${env.allowedShellCommands.join(', ')}`, 403, 'EXECUTABLE_NOT_ALLOWED')
  return new Promise((resolve, reject) => {
    const child = spawn(executable, args, { cwd: process.cwd(), shell: false, env: { PATH: process.env.PATH, NODE_ENV: env.nodeEnv, HOME: process.env.HOME }, stdio: ['ignore', 'pipe', 'pipe'] })
    let output = ''
    let errorOutput = ''
    const collect = target => chunk => {
      const next = chunk.toString()
      if (target === 'stdout') output = (output + next).slice(-12000)
      else errorOutput = (errorOutput + next).slice(-12000)
    }
    child.stdout.on('data', collect('stdout'))
    child.stderr.on('data', collect('stderr'))
    const timer = setTimeout(() => child.kill('SIGKILL'), 30000)
    child.on('error', error => { clearTimeout(timer); reject(new AppError(error.message, 500, 'EXECUTION_FAILED')) })
    child.on('close', code => {
      clearTimeout(timer)
      resolve(`Exit code: ${code}\n\n${output || '[no stdout]'}${errorOutput ? `\nSTDERR\n${errorOutput}` : ''}`)
    })
  })
}

const updateSudo = async (operation, number, userId) => {
  const setting = await Setting.findOne({ scope: 'global', scopeId: 'global', key: 'sudoNumbers' })
  const values = new Set(Array.isArray(setting?.value) ? setting.value : [])
  if (operation === 'add') values.add(number)
  else if (operation === 'remove') values.delete(number)
  else throw new AppError('Use add or remove', 400, 'INVALID_OPERATION')
  await Setting.findOneAndUpdate({ scope: 'global', scopeId: 'global', key: 'sudoNumbers' }, { $set: { value: [...values], updatedBy: userId } }, { upsert: true })
  return [...values]
}

export const executeOwner = async (name, context) => {
  if (['broadcast', 'bc'].includes(name)) {
    if (!env.enableBroadcast) throw new AppError('Broadcasting is disabled by configuration', 403, 'BROADCAST_DISABLED')
    const text = requireInput(context, 'Enter a broadcast message').slice(0, 3500)
    const optedIn = await GroupSetting.find({ sessionId: context.session.sessionId, broadcastOptIn: true }).select('groupJid').limit(100).lean()
    if (!optedIn.length) return 'No groups have opted in to administrative broadcasts.'
    let delivered = 0
    for (const group of optedIn) {
      try {
        await context.sock.sendMessage(group.groupJid, { text: `${env.botName}\n\n${text}` })
        delivered += 1
      } catch {}
      await delay(1500)
    }
    return `Broadcast delivered to ${delivered} of ${optedIn.length} opted-in groups.`
  }
  if (name === 'eval') {
    if (!env.enableDangerousCommands) throw new AppError('Restricted evaluation is disabled by configuration', 403, 'DANGEROUS_COMMANDS_DISABLED')
    const code = requireInput(context, 'Enter a JavaScript expression')
    if (code.length > 2000) throw new AppError('Expression is too long', 413, 'EXPRESSION_TOO_LONG')
    const sandbox = Object.create(null)
    sandbox.Math = Math
    sandbox.JSON = JSON
    sandbox.Date = Date
    sandbox.input = Object.freeze({ args: [...context.args], text: context.text, sender: context.senderJid, chat: context.chatJid })
    const result = vm.runInNewContext(`'use strict'; (${code})`, sandbox, { timeout: 750, codeGeneration: { strings: false, wasm: false } })
    return truncate(typeof result === 'string' ? result : JSON.stringify(result, null, 2))
  }
  if (['exec', 'shell'].includes(name)) return truncate(await runExecutable(requireInput(context, 'Enter an allow-listed maintenance command')))
  if (name === 'restart') {
    await context.reply('Restart requested. The process manager should start a clean instance.')
    setTimeout(() => process.kill(process.pid, 'SIGTERM'), 500)
    return null
  }
  if (name === 'shutdown') {
    await context.reply('Graceful shutdown requested.')
    setTimeout(() => process.kill(process.pid, 'SIGTERM'), 500)
    return null
  }
  if (name === 'update') {
    const result = await runExecutable('git pull --ff-only')
    return `Update workflow finished.\n\n${truncate(result, 3000)}`
  }
  if (name === 'setbotname') {
    const value = requireInput(context, 'Enter a bot name').slice(0, 100)
    if (typeof context.sock.updateProfileName === 'function') await context.sock.updateProfileName(value)
    await Bot.updateOne({ sessionId: context.session.sessionId }, { $set: { name: value } })
    return `Bot name updated to ${value}.`
  }
  if (['setbio', 'setstatus'].includes(name)) {
    const value = requireInput(context, 'Enter a profile status').slice(0, 139)
    await context.sock.updateProfileStatus(value)
    return 'Bot profile status updated.'
  }
  if (name === 'setlogo') {
    const value = (await validatePublicUrl(requireInput(context, 'Enter a public image URL'))).toString()
    const { buffer } = await fetchBuffer(value, { maxBytes: 8 * 1024 * 1024 })
    await context.sock.updateProfilePicture(context.sock.user.id, buffer)
    await Bot.updateOne({ sessionId: context.session.sessionId }, { $set: { logoUrl: value } })
    return 'Bot logo and WhatsApp profile picture updated.'
  }
  if (name === 'setsudo') {
    const [operation, rawNumber] = context.args
    const number = normalizePhoneNumber(rawNumber)
    const values = await updateSudo(operation?.toLowerCase(), number, context.session.userId)
    return `Sudo list updated. Active numbers: ${values.length}.`
  }
  if (name === 'sessions') {
    const sessions = await Session.find({ active: true }).sort({ createdAt: -1 }).select('-credentials').lean()
    return sessions.length ? sessions.map((session, index) => `${index + 1}. ${session.label}\nID: ${session.sessionId}\nStatus: ${session.status}\nNumber: ${session.connectedNumber || 'Not connected'}`).join('\n\n') : 'No active sessions.'
  }
  if (name === 'delsession') {
    const sessionId = requireInput(context, 'Enter a session ID')
    if (sessionId === context.session.sessionId) {
      await context.reply('Current session deletion scheduled. This connection will close.')
      setTimeout(() => context.sessionManager.deleteSession(sessionId).catch(() => {}), 750)
      return null
    }
    await context.sessionManager.deleteSession(sessionId)
    return `Session ${sessionId} deleted.`
  }
  if (['banuser', 'unbanuser'].includes(name)) {
    const number = normalizePhoneNumber(context.args[0])
    const targetJid = `${number}@s.whatsapp.net`
    if (name === 'banuser') {
      const reason = context.args.slice(1).join(' ') || 'Banned by bot owner'
      await Ban.findOneAndUpdate({ sessionId: context.session.sessionId, targetJid, scope: 'session', groupJid: null }, { $set: { active: true, reason, createdBy: context.senderJid, expiresAt: null } }, { upsert: true })
      return `${number} is banned from bot commands.`
    }
    const result = await Ban.updateMany({ sessionId: context.session.sessionId, targetJid, active: true }, { $set: { active: false } })
    if (!result.modifiedCount) throw new AppError('No active user ban was found', 404, 'BAN_NOT_FOUND')
    return `${number} is no longer banned.`
  }
  if (['block', 'unblock'].includes(name)) {
    const number = normalizePhoneNumber(context.args[0])
    await context.sock.updateBlockStatus(`${number}@s.whatsapp.net`, name === 'block' ? 'block' : 'unblock')
    return `${number} has been ${name === 'block' ? 'blocked' : 'unblocked'}.`
  }
  if (name === 'clearlogs') {
    const result = await Log.deleteMany({})
    return `${result.deletedCount} retained log entries deleted.`
  }
  throw new AppError(`Owner action is not implemented: ${name}`, 500, 'COMMAND_ACTION_MISSING')
}
