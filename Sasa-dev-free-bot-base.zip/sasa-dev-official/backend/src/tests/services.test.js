import { describe, expect, it } from 'vitest'
import { normalizeSasaResponse } from '../services/sasaApi.js'
import { assertPublicHostname, validatePublicUrl } from '../services/networkService.js'

describe('Sasa Dev API normalization', () => {
  it('normalizes successful result payloads', () => {
    expect(normalizeSasaResponse({ status: true, creator: 'Sasa Dev', result: { value: 1 } }).data).toEqual({ value: 1 })
  })

  it('rejects provider error payloads without inventing results', () => {
    expect(() => normalizeSasaResponse({ status: false, error: 'Invalid key' })).toThrow('Invalid key')
  })
})

describe('network safety', () => {
  it('blocks local and private network targets', async () => {
    await expect(assertPublicHostname('localhost')).rejects.toMatchObject({ code: 'PRIVATE_ADDRESS_BLOCKED' })
    await expect(assertPublicHostname('127.0.0.1')).rejects.toMatchObject({ code: 'PRIVATE_ADDRESS_BLOCKED' })
    await expect(validatePublicUrl('http://192.168.1.5/admin')).rejects.toMatchObject({ code: 'PRIVATE_ADDRESS_BLOCKED' })
  })

  it('rejects non-http protocols and URL credentials', async () => {
    await expect(validatePublicUrl('file:///etc/passwd')).rejects.toMatchObject({ code: 'INVALID_URL_PROTOCOL' })
    await expect(validatePublicUrl('https://user:pass@example.com')).rejects.toMatchObject({ code: 'INVALID_URL_PROTOCOL' })
  })
})
