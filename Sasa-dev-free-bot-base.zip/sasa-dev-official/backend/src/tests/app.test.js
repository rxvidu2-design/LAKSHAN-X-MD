import { describe, expect, it } from 'vitest'
import request from 'supertest'
import { createApplication } from '../app.js'

const registry = { size: 200, publicList: () => [], get: () => null }
const manager = {
  listSessions: async () => [], getSession: async () => null, startQr: async () => null, startPair: async () => null,
  reconnectSession: async () => null, refreshQr: async () => null, stopSession: async () => null, deleteSession: async () => null
}
const app = createApplication({ registry, sessionManager: manager })

describe('public API contract', () => {
  it('returns a structured health response even without MongoDB', async () => {
    const response = await request(app).get('/api/health').expect(200)
    expect(response.body.success).toBe(true)
    expect(response.body.data).toHaveProperty('status')
    expect(response.body.data).toHaveProperty('database')
  })

  it('returns all public commands through the consistent envelope', async () => {
    const response = await request(app).get('/api/commands').expect(200)
    expect(response.body).toEqual(expect.objectContaining({ success: true, message: 'Commands loaded', data: [] }))
    expect(response.body.meta.total).toBe(200)
  })

  it('normalizes unknown API routes', async () => {
    const response = await request(app).get('/api/not-a-route').expect(404)
    expect(response.body).toEqual(expect.objectContaining({ success: false, error: 'NOT_FOUND' }))
  })
})
