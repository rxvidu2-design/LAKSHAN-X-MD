import { describe, expect, it } from 'vitest'
import { normalizePhoneNumber, normalizeJid, safeText } from '../utils/validation.js'
import { extractText, getQuotedMessage, unwrapMessage } from '../utils/message.js'

describe('input normalization', () => {
  it('normalizes international phone numbers', () => {
    expect(normalizePhoneNumber('+94 78-416-7385')).toBe('94784167385')
    expect(normalizeJid('94784167385')).toBe('94784167385@s.whatsapp.net')
  })

  it('rejects invalid phone numbers', () => {
    expect(() => normalizePhoneNumber('123')).toThrow('valid phone number')
    expect(() => normalizePhoneNumber('94-abcd')).toThrow('valid phone number')
  })

  it('removes control characters and limits text', () => {
    expect(safeText('  hello\u0000 world  ', 20)).toBe('hello world')
    expect(safeText('abcdef', 3)).toBe('abc')
  })
})

describe('WhatsApp message parsing', () => {
  it('unwraps ephemeral and view-once messages', () => {
    const message = { ephemeralMessage: { message: { viewOnceMessageV2: { message: { imageMessage: { caption: 'inside' } } } } } }
    expect(unwrapMessage(message)).toEqual({ imageMessage: { caption: 'inside' } })
    expect(extractText(message)).toBe('inside')
  })

  it('extracts quoted message metadata', () => {
    const message = { extendedTextMessage: { text: 'reply', contextInfo: { stanzaId: 'A1', participant: '1@s.whatsapp.net', quotedMessage: { conversation: 'original' } } } }
    expect(getQuotedMessage(message).key.id).toBe('A1')
    expect(extractText(getQuotedMessage(message).message)).toBe('original')
  })
})
