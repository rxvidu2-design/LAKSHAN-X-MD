import { describe, expect, it, beforeAll } from 'vitest'
import { commandRegistry } from '../services/commandRegistry.js'

beforeAll(async () => {
  await commandRegistry.load()
})

describe('command registry', () => {
  it('loads exactly 200 unique command modules', () => {
    expect(commandRegistry.size).toBe(200)
    expect(new Set(commandRegistry.list().map(command => command.name)).size).toBe(200)
  })

  it('contains all permission-protected critical commands', () => {
    expect(commandRegistry.get('kick').permission).toBe('admin')
    expect(commandRegistry.get('eval').permission).toBe('owner')
    expect(commandRegistry.get('restart').permission).toBe('owner')
    expect(commandRegistry.get('ai').permission).toBe('public')
    expect(commandRegistry.get('getdp').permission).toBe('public')
  })

  it('provides complete metadata and executable handlers', () => {
    for (const command of commandRegistry.list()) {
      expect(command.description.length).toBeGreaterThan(8)
      expect(command.category).toBeTruthy()
      expect(command.permission).toBeTruthy()
      expect(command.cooldown).toBeGreaterThanOrEqual(0)
      expect(command.execute).toBeTypeOf('function')
    }
  })
})
