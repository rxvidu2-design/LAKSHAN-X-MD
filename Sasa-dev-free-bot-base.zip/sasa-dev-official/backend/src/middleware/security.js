import crypto from 'node:crypto'
import { AppError } from '../utils/AppError.js'
import { env } from '../config/env.js'

const sanitizeObject = value => {
  if (Array.isArray(value)) return value.map(sanitizeObject)
  if (!value || typeof value !== 'object') return value
  const clean = {}
  for (const [key, child] of Object.entries(value)) {
    if (key.startsWith('$') || key.includes('.')) throw new AppError('Unsafe request field detected', 400, 'UNSAFE_INPUT')
    clean[key] = sanitizeObject(child)
  }
  return clean
}

export const requestContext = (req, res, next) => {
  req.id = req.headers['x-request-id']?.toString().slice(0, 100) || crypto.randomUUID()
  res.setHeader('x-request-id', req.id)
  next()
}

export const sanitizeRequest = (req, res, next) => {
  try {
    if (req.body) req.body = sanitizeObject(req.body)
    next()
  } catch (error) {
    next(error)
  }
}

export const verifyOrigin = (req, res, next) => {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next()
  const origin = req.headers.origin
  if (!origin) return next()
  const forwardedProtocol = String(req.headers['x-forwarded-proto'] || req.protocol).split(',')[0].trim()
  const expected = `${forwardedProtocol}://${req.get('host')}`
  const allowed = new Set([expected, ...env.corsOrigins, env.webUrl, env.apiUrl].filter(value => env.isConfigured(value)))
  if (!allowed.has(origin)) return next(new AppError('Request origin is not allowed', 403, 'ORIGIN_NOT_ALLOWED'))
  next()
}

export const noCache = (req, res, next) => {
  res.setHeader('cache-control', 'no-store, max-age=0')
  res.setHeader('pragma', 'no-cache')
  next()
}
