import { isDatabaseReady } from '../database/connection.js'
import { AppError } from '../utils/AppError.js'

export const requireDatabase = (req, res, next) => {
  if (!isDatabaseReady()) return next(new AppError('MongoDB is currently unavailable', 503, 'DATABASE_UNAVAILABLE'))
  next()
}
