import { AppError } from '../utils/AppError.js'

export const validate = schemas => (req, res, next) => {
  try {
    for (const [location, schema] of Object.entries(schemas)) {
      const result = schema.safeParse(req[location])
      if (!result.success) {
        const details = result.error.issues.map(issue => ({ path: issue.path.join('.'), message: issue.message }))
        throw new AppError('Request validation failed', 400, 'VALIDATION_ERROR', details)
      }
      req[location] = result.data
    }
    next()
  } catch (error) {
    next(error)
  }
}
