import { verifyAccessToken } from '../services/adminService.js'
import { User } from '../models/index.js'
import { AppError } from '../utils/AppError.js'
import { asyncHandler } from '../utils/asyncHandler.js'

const extractToken = req => {
  const authorization = req.headers.authorization || ''
  if (authorization.startsWith('Bearer ')) return authorization.slice(7)
  return req.cookies?.sasa_access || null
}

export const requireAuth = asyncHandler(async (req, res, next) => {
  const token = extractToken(req)
  if (!token) throw new AppError('Authentication is required', 401, 'AUTH_REQUIRED')
  const payload = verifyAccessToken(token)
  const user = await User.findOne({ _id: payload.sub, active: true }).lean()
  if (!user) throw new AppError('Authentication is no longer valid', 401, 'AUTH_INVALID')
  req.user = user
  next()
})

export const requireRole = (...roles) => (req, res, next) => {
  if (!req.user || !roles.includes(req.user.role)) return next(new AppError('You do not have permission for this action', 403, 'FORBIDDEN'))
  next()
}
