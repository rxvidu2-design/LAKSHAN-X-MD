import { AppError } from '../utils/AppError.js'
import { logger } from '../config/logger.js'
import { env } from '../config/env.js'
import { failure } from '../utils/response.js'

export const notFound = (req, res, next) => next(new AppError('Route not found', 404, 'NOT_FOUND'))

export const errorHandler = (error, req, res, next) => {
  if (res.headersSent) return next(error)
  const operational = error instanceof AppError || error.isOperational
  const statusCode = operational ? error.statusCode : 500
  const code = operational ? error.code : 'INTERNAL_ERROR'
  const message = operational ? error.message : 'Something went wrong'
  const log = { err: error, requestId: req.id, method: req.method, path: req.originalUrl, statusCode }
  if (statusCode >= 500) logger.error(log, 'Request failed')
  else logger.warn(log, 'Request rejected')
  const details = operational ? error.details : env.isProduction ? undefined : { stack: error.stack }
  return failure(res, message, code, statusCode, details)
}
