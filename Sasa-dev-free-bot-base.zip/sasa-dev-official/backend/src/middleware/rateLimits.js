import { rateLimit } from 'express-rate-limit'

const response = message => ({ success: false, message, error: 'RATE_LIMITED' })

export const apiLimiter = rateLimit({
  windowMs: 60_000,
  limit: 180,
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  handler: (req, res) => res.status(429).json(response('Too many requests; try again shortly'))
})

export const authLimiter = rateLimit({
  windowMs: 15 * 60_000,
  limit: 8,
  skipSuccessfulRequests: true,
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  handler: (req, res) => res.status(429).json(response('Too many sign-in attempts; try again later'))
})

export const pairingLimiter = rateLimit({
  windowMs: 10 * 60_000,
  limit: 10,
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  handler: (req, res) => res.status(429).json(response('Too many connection attempts; try again later'))
})
