import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "headers",
  "aliases": [],
  "description": "Inspect safe public response headers",
  "category": "utility",
  "usage": "<https-url>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('headers', context))
