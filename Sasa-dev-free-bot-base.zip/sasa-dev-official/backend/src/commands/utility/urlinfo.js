import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "urlinfo",
  "aliases": [],
  "description": "Inspect safe public URL metadata",
  "category": "utility",
  "usage": "<https-url>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('urlinfo', context))
