import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "encode",
  "aliases": [],
  "description": "URL-encode supplied text",
  "category": "utility",
  "usage": "<text>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('encode', context))
