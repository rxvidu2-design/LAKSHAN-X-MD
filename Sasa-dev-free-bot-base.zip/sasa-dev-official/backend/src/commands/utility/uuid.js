import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "uuid",
  "aliases": [],
  "description": "Generate a random UUID",
  "category": "utility",
  "usage": "",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('uuid', context))
