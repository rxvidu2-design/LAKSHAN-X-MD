import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "password",
  "aliases": [],
  "description": "Generate a strong random password",
  "category": "utility",
  "usage": "[length]",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('password', context))
