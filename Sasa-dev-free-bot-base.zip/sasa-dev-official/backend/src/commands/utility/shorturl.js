import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "shorturl",
  "aliases": [],
  "description": "Shorten a public URL",
  "category": "utility",
  "usage": "<https-url>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('shorturl', context))
