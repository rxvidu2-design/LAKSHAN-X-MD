import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "calc",
  "aliases": [],
  "description": "Evaluate a mathematical expression safely",
  "category": "utility",
  "usage": "<expression>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('calc', context))
