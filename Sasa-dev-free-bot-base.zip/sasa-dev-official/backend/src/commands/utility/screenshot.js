import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "screenshot",
  "aliases": [],
  "description": "Create a website screenshot URL",
  "category": "utility",
  "usage": "<https-url>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('screenshot', context))
