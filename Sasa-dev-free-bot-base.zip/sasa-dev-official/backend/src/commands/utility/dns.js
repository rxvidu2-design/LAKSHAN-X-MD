import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "dns",
  "aliases": [],
  "description": "Resolve DNS records for a domain",
  "category": "utility",
  "usage": "<domain> [type]",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('dns', context))
