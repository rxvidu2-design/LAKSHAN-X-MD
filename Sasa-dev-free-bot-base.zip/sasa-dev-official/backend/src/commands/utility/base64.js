import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "base64",
  "aliases": [],
  "description": "Encode text as Base64",
  "category": "utility",
  "usage": "<text>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('base64', context))
