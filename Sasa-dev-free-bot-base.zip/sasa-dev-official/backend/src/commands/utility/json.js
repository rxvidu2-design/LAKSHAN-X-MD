import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "json",
  "aliases": [],
  "description": "Validate and format JSON",
  "category": "utility",
  "usage": "<json>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('json', context))
