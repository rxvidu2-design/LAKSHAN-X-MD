import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "qr",
  "aliases": [],
  "description": "Generate a QR code image",
  "category": "utility",
  "usage": "<text>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('qr', context))
