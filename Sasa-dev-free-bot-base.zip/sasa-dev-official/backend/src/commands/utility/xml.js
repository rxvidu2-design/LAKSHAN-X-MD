import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "xml",
  "aliases": [],
  "description": "Parse XML into JSON",
  "category": "utility",
  "usage": "<xml>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('xml', context))
