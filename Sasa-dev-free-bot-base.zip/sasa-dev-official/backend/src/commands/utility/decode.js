import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "decode",
  "aliases": [],
  "description": "Decode URL or Base64 text",
  "category": "utility",
  "usage": "<text>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('decode', context))
