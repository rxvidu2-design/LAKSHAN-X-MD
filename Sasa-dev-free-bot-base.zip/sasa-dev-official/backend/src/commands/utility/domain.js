import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "domain",
  "aliases": [],
  "description": "Resolve public domain information",
  "category": "utility",
  "usage": "<domain>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('domain', context))
