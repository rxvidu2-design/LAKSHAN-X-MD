import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "readqr",
  "aliases": [],
  "description": "Read a QR code from an image",
  "category": "utility",
  "usage": "",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('readqr', context))
