import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "html",
  "aliases": [],
  "description": "Convert HTML into readable text",
  "category": "utility",
  "usage": "<html>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('html', context))
