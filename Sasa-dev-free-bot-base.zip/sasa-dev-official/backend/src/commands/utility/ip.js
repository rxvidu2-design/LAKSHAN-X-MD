import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "ip",
  "aliases": [],
  "description": "Look up public IP information",
  "category": "utility",
  "usage": "<public-ip>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('ip', context))
