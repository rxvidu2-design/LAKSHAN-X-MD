import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "hash",
  "aliases": [],
  "description": "Generate a cryptographic text hash",
  "category": "utility",
  "usage": "[algorithm] | <text>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('hash', context))
