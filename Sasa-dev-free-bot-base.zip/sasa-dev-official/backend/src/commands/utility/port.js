import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "port",
  "aliases": [],
  "description": "Test a public TCP port",
  "category": "utility",
  "usage": "<host> <port>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('port', context))
