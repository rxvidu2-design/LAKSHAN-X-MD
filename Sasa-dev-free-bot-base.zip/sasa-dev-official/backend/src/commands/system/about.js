import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "about",
  "aliases": [],
  "description": "Describe Sasa Dev Official",
  "category": "system",
  "usage": "",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('about', context))
