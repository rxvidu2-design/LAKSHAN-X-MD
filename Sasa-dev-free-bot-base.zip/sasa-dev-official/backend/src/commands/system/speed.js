import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "speed",
  "aliases": [],
  "description": "Run a response-speed measurement",
  "category": "system",
  "usage": "",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('speed', context))
