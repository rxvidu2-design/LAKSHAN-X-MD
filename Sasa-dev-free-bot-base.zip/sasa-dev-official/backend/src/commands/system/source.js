import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "source",
  "aliases": [],
  "description": "Show the configured project source",
  "category": "system",
  "usage": "",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('source', context))
