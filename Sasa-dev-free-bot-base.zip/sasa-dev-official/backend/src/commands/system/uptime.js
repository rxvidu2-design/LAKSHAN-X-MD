import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "uptime",
  "aliases": [],
  "description": "Show the current process uptime",
  "category": "system",
  "usage": "",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('uptime', context))
