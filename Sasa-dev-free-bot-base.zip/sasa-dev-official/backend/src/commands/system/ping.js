import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "ping",
  "aliases": [],
  "description": "Measure command response latency",
  "category": "system",
  "usage": "",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('ping', context))
