import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "help",
  "aliases": [],
  "description": "Show usage details for a command",
  "category": "system",
  "usage": "[command]",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('help', context))
