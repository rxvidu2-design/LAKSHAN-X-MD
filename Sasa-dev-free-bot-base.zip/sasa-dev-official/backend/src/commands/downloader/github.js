import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "github",
  "aliases": [],
  "description": "Resolve a GitHub repository archive",
  "category": "downloader",
  "usage": "<repository-url>",
  "permission": "public",
  "cooldown": 8
}, context => executeCommand('github', context))
