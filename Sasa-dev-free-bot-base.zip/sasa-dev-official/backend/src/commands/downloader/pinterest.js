import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "pinterest",
  "aliases": [],
  "description": "Download Pinterest media",
  "category": "downloader",
  "usage": "<url>",
  "permission": "public",
  "cooldown": 8
}, context => executeCommand('pinterest', context))
