import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "twitter",
  "aliases": [],
  "description": "Resolve downloadable X or Twitter media",
  "category": "downloader",
  "usage": "<url>",
  "permission": "public",
  "cooldown": 8
}, context => executeCommand('twitter', context))
