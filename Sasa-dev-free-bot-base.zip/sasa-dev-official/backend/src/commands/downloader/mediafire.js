import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "mediafire",
  "aliases": [],
  "description": "Resolve a MediaFire download",
  "category": "downloader",
  "usage": "<url>",
  "permission": "public",
  "cooldown": 8
}, context => executeCommand('mediafire', context))
