import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "ytmp3",
  "aliases": [],
  "description": "Download YouTube media as audio",
  "category": "downloader",
  "usage": "<youtube-url>",
  "permission": "public",
  "cooldown": 8
}, context => executeCommand('ytmp3', context))
