import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "yta",
  "aliases": [],
  "description": "Download YouTube audio",
  "category": "downloader",
  "usage": "<youtube-url>",
  "permission": "public",
  "cooldown": 8
}, context => executeCommand('yta', context))
