import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "song",
  "aliases": [],
  "description": "Search YouTube for a song",
  "category": "downloader",
  "usage": "<query>",
  "permission": "public",
  "cooldown": 8
}, context => executeCommand('song', context))
