import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "play",
  "aliases": [],
  "description": "Search YouTube and return playable results",
  "category": "downloader",
  "usage": "<query>",
  "permission": "public",
  "cooldown": 8
}, context => executeCommand('play', context))
