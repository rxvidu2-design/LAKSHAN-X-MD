import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "mega",
  "aliases": [],
  "description": "Resolve a Mega link through a configured adapter",
  "category": "downloader",
  "usage": "<url>",
  "permission": "public",
  "cooldown": 8
}, context => executeCommand('mega', context))
