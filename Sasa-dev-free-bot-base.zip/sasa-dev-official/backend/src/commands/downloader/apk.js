import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "apk",
  "aliases": [],
  "description": "Search for an Android APK",
  "category": "downloader",
  "usage": "<app name>",
  "permission": "public",
  "cooldown": 8
}, context => executeCommand('apk', context))
