import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "ig",
  "aliases": [],
  "description": "Resolve downloadable Instagram media",
  "category": "downloader",
  "usage": "<url>",
  "permission": "public",
  "cooldown": 8
}, context => executeCommand('ig', context))
