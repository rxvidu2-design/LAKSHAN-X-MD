import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "ytv",
  "aliases": [],
  "description": "Download YouTube video",
  "category": "downloader",
  "usage": "<youtube-url>",
  "permission": "public",
  "cooldown": 8
}, context => executeCommand('ytv', context))
