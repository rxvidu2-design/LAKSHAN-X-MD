import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "pin",
  "aliases": [],
  "description": "Search Pinterest",
  "category": "downloader",
  "usage": "<query>",
  "permission": "public",
  "cooldown": 8
}, context => executeCommand('pin', context))
