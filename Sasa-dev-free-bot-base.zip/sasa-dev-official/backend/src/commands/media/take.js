import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "take",
  "aliases": [],
  "description": "Repackage a sticker with bot metadata",
  "category": "media",
  "usage": "",
  "permission": "public",
  "cooldown": 8
}, context => executeCommand('take', context))
