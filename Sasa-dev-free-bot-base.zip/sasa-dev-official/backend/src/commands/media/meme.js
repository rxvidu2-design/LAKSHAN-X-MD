import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "meme",
  "aliases": [],
  "description": "Create a meme from replied image and text",
  "category": "media",
  "usage": "<top text> | <bottom text>",
  "permission": "public",
  "cooldown": 8
}, context => executeCommand('meme', context))
