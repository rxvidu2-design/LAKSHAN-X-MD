import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "remini",
  "aliases": [],
  "description": "Enhance a low-quality image locally",
  "category": "media",
  "usage": "",
  "permission": "public",
  "cooldown": 8
}, context => executeCommand('remini', context))
