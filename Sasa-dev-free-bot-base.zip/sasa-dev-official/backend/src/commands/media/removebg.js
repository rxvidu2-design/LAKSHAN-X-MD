import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "removebg",
  "aliases": [],
  "description": "Remove an image background using the configured API",
  "category": "media",
  "usage": "",
  "permission": "public",
  "cooldown": 8
}, context => executeCommand('removebg', context))
