import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "resize",
  "aliases": [],
  "description": "Resize an image to the requested dimensions",
  "category": "media",
  "usage": "<width>x<height>",
  "permission": "public",
  "cooldown": 8
}, context => executeCommand('resize', context))
