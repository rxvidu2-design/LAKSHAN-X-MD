import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "toaudio",
  "aliases": [],
  "description": "Extract audio from replied media",
  "category": "media",
  "usage": "",
  "permission": "public",
  "cooldown": 8
}, context => executeCommand('toaudio', context))
