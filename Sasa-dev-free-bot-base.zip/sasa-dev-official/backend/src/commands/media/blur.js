import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "blur",
  "aliases": [],
  "description": "Apply a blur effect to an image",
  "category": "media",
  "usage": "[strength 1-20]",
  "permission": "public",
  "cooldown": 8
}, context => executeCommand('blur', context))
