import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "gif",
  "aliases": [],
  "description": "Convert a short video into GIF",
  "category": "media",
  "usage": "",
  "permission": "public",
  "cooldown": 8
}, context => executeCommand('gif', context))
