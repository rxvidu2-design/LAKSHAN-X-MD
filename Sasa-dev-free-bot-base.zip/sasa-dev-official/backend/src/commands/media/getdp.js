import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "getdp",
  "aliases": [],
  "description": "Fetch a WhatsApp profile picture",
  "category": "media",
  "usage": "[@user|number]",
  "permission": "public",
  "cooldown": 8
}, context => executeCommand('getdp', context))
