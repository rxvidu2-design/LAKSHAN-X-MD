import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "compress",
  "aliases": [],
  "description": "Compress an image with controlled quality",
  "category": "media",
  "usage": "[quality 20-95]",
  "permission": "public",
  "cooldown": 8
}, context => executeCommand('compress', context))
