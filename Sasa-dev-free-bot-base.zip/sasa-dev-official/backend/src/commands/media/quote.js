import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "quote",
  "aliases": [],
  "description": "Create a quote card from replied text",
  "category": "media",
  "usage": "[author]",
  "permission": "public",
  "cooldown": 8
}, context => executeCommand('quote', context))
