import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "lyrics",
  "aliases": [],
  "description": "Search song lyrics",
  "category": "search",
  "usage": "<song or artist - title>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('lyrics', context))
