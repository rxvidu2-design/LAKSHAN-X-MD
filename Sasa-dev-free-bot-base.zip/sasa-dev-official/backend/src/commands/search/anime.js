import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "anime",
  "aliases": [],
  "description": "Search for anime",
  "category": "search",
  "usage": "<title>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('anime', context))
