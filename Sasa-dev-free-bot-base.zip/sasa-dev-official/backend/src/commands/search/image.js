import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "image",
  "aliases": [],
  "description": "Search for images",
  "category": "search",
  "usage": "<query>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('image', context))
