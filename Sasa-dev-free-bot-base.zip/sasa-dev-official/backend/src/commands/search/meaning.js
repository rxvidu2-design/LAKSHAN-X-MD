import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "meaning",
  "aliases": [],
  "description": "Look up an English word meaning",
  "category": "search",
  "usage": "<word>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('meaning', context))
