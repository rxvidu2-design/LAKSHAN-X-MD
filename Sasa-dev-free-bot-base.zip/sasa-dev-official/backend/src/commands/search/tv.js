import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "tv",
  "aliases": [],
  "description": "Search for a television series",
  "category": "search",
  "usage": "<title>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('tv', context))
