import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "bing",
  "aliases": [],
  "description": "Search the web with Bing RSS",
  "category": "search",
  "usage": "<query>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('bing', context))
