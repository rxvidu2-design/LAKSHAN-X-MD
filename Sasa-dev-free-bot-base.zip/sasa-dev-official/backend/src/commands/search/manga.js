import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "manga",
  "aliases": [],
  "description": "Search for manga",
  "category": "search",
  "usage": "<title>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('manga', context))
