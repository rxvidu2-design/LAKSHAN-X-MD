import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "npm",
  "aliases": [],
  "description": "Search the npm registry",
  "category": "search",
  "usage": "<package>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('npm', context))
