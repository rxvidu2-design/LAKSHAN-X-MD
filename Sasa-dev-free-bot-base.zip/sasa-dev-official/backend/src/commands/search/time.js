import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "time",
  "aliases": [],
  "description": "Get the current time in an IANA timezone",
  "category": "search",
  "usage": "<Area/City>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('time', context))
