import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "movie",
  "aliases": [],
  "description": "Search for a movie",
  "category": "search",
  "usage": "<title>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('movie', context))
