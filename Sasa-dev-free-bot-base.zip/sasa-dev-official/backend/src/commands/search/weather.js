import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "weather",
  "aliases": [],
  "description": "Get current weather for a location",
  "category": "search",
  "usage": "<location>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('weather', context))
