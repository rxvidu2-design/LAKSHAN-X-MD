import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "currency",
  "aliases": [],
  "description": "Convert currencies using current reference rates",
  "category": "search",
  "usage": "<amount> <FROM> <TO>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('currency', context))
