import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "wikipedia",
  "aliases": [],
  "description": "Search Wikipedia",
  "category": "search",
  "usage": "<query>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('wikipedia', context))
