import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "githubsearch",
  "aliases": [],
  "description": "Search public GitHub repositories",
  "category": "search",
  "usage": "<query>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('githubsearch', context))
