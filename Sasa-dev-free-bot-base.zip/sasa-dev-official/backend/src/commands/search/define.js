import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "define",
  "aliases": [],
  "description": "Look up an English dictionary definition",
  "category": "search",
  "usage": "<word>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('define', context))
