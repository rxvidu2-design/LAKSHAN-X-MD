import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "crypto",
  "aliases": [],
  "description": "Get current cryptocurrency prices",
  "category": "search",
  "usage": "<coin>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('crypto', context))
