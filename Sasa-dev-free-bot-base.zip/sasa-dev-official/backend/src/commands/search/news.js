import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "news",
  "aliases": [],
  "description": "Fetch current news results",
  "category": "search",
  "usage": "[query]",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('news', context))
