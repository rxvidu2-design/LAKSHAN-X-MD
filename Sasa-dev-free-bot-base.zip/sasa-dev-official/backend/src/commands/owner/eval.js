import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "eval",
  "aliases": [],
  "description": "Evaluate JavaScript in a restricted owner sandbox",
  "category": "owner",
  "usage": "<expression>",
  "permission": "owner",
  "cooldown": 5
}, context => executeCommand('eval', context))
