import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "unbanuser",
  "aliases": [],
  "description": "Remove a user command ban",
  "category": "owner",
  "usage": "<number>",
  "permission": "owner",
  "cooldown": 5
}, context => executeCommand('unbanuser', context))
