import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "unblock",
  "aliases": [],
  "description": "Unblock a WhatsApp contact",
  "category": "owner",
  "usage": "<number>",
  "permission": "owner",
  "cooldown": 5
}, context => executeCommand('unblock', context))
