import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "setbio",
  "aliases": [],
  "description": "Update the bot profile biography",
  "category": "owner",
  "usage": "<bio>",
  "permission": "owner",
  "cooldown": 5
}, context => executeCommand('setbio', context))
