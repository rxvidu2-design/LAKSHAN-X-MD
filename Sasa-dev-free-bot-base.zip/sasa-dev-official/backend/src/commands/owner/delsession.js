import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "delsession",
  "aliases": [],
  "description": "Securely delete a bot session",
  "category": "owner",
  "usage": "<session-id>",
  "permission": "owner",
  "cooldown": 5
}, context => executeCommand('delsession', context))
