import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "sessions",
  "aliases": [],
  "description": "List managed bot sessions",
  "category": "owner",
  "usage": "",
  "permission": "owner",
  "cooldown": 5
}, context => executeCommand('sessions', context))
