import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "exec",
  "aliases": [],
  "description": "Run an allow-listed maintenance executable",
  "category": "owner",
  "usage": "<allow-listed command>",
  "permission": "owner",
  "cooldown": 5
}, context => executeCommand('exec', context))
