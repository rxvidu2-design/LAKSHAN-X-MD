import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "setsudo",
  "aliases": [],
  "description": "Add or remove a trusted sudo number",
  "category": "owner",
  "usage": "<add|remove> <number>",
  "permission": "owner",
  "cooldown": 5
}, context => executeCommand('setsudo', context))
