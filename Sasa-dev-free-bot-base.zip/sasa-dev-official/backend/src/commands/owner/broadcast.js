import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "broadcast",
  "aliases": [],
  "description": "Send a rate-limited message to opted-in groups",
  "category": "owner",
  "usage": "<message>",
  "permission": "owner",
  "cooldown": 300
}, context => executeCommand('broadcast', context))
