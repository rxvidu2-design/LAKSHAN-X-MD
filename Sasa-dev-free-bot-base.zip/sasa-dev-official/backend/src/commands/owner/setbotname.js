import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "setbotname",
  "aliases": [],
  "description": "Update the bot display name",
  "category": "owner",
  "usage": "<name>",
  "permission": "owner",
  "cooldown": 5
}, context => executeCommand('setbotname', context))
