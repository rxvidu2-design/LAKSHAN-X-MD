import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "banuser",
  "aliases": [],
  "description": "Ban a user from bot commands",
  "category": "owner",
  "usage": "<number> [reason]",
  "permission": "owner",
  "cooldown": 5
}, context => executeCommand('banuser', context))
