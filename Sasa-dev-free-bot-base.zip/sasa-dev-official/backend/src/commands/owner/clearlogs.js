import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "clearlogs",
  "aliases": [],
  "description": "Delete retained command logs",
  "category": "owner",
  "usage": "",
  "permission": "owner",
  "cooldown": 5
}, context => executeCommand('clearlogs', context))
