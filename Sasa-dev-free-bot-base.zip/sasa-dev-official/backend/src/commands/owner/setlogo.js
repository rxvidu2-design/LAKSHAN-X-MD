import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "setlogo",
  "aliases": [],
  "description": "Update the bot logo configuration",
  "category": "owner",
  "usage": "<https-url>",
  "permission": "owner",
  "cooldown": 5
}, context => executeCommand('setlogo', context))
