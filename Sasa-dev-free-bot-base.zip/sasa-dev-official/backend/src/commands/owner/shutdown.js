import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "shutdown",
  "aliases": [],
  "description": "Gracefully stop the bot process",
  "category": "owner",
  "usage": "",
  "permission": "owner",
  "cooldown": 5
}, context => executeCommand('shutdown', context))
