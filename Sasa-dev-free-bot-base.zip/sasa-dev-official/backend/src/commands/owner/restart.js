import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "restart",
  "aliases": [],
  "description": "Request a clean process restart",
  "category": "owner",
  "usage": "",
  "permission": "owner",
  "cooldown": 5
}, context => executeCommand('restart', context))
