import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "update",
  "aliases": [],
  "description": "Run the safe project update workflow",
  "category": "owner",
  "usage": "",
  "permission": "owner",
  "cooldown": 5
}, context => executeCommand('update', context))
