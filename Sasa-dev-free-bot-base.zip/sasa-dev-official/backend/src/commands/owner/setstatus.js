import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "setstatus",
  "aliases": [],
  "description": "Update the bot profile status",
  "category": "owner",
  "usage": "<status>",
  "permission": "owner",
  "cooldown": 5
}, context => executeCommand('setstatus', context))
