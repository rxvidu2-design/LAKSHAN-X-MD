import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "explain",
  "aliases": [],
  "description": "Explain a topic or code clearly",
  "category": "ai",
  "usage": "<topic>",
  "permission": "public",
  "cooldown": 10
}, context => executeCommand('explain', context))
