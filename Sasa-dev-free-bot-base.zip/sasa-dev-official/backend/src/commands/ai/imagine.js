import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "imagine",
  "aliases": [],
  "description": "Generate an image from a prompt",
  "category": "ai",
  "usage": "<prompt>",
  "permission": "public",
  "cooldown": 10
}, context => executeCommand('imagine', context))
