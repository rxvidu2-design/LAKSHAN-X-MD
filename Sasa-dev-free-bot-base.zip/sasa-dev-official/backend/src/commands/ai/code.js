import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "code",
  "aliases": [],
  "description": "Get coding assistance",
  "category": "ai",
  "usage": "<request>",
  "permission": "public",
  "cooldown": 10
}, context => executeCommand('code', context))
