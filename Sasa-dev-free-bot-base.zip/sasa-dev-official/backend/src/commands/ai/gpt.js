import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "gpt",
  "aliases": [],
  "description": "Ask the GPT-compatible provider",
  "category": "ai",
  "usage": "<question>",
  "permission": "public",
  "cooldown": 10
}, context => executeCommand('gpt', context))
