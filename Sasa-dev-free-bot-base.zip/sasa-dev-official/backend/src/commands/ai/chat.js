import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "chat",
  "aliases": [],
  "description": "Chat with the configured AI assistant",
  "category": "ai",
  "usage": "<message>",
  "permission": "public",
  "cooldown": 10
}, context => executeCommand('chat', context))
