import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "translate",
  "aliases": [],
  "description": "Translate text into a target language",
  "category": "ai",
  "usage": "<language> | <text>",
  "permission": "public",
  "cooldown": 10
}, context => executeCommand('translate', context))
