import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "ask",
  "aliases": [],
  "description": "Ask the configured AI assistant",
  "category": "ai",
  "usage": "<question>",
  "permission": "public",
  "cooldown": 10
}, context => executeCommand('ask', context))
