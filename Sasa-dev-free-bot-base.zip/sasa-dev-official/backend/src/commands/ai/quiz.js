import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "quiz",
  "aliases": [],
  "description": "Generate a quiz on a topic",
  "category": "ai",
  "usage": "<topic>",
  "permission": "public",
  "cooldown": 10
}, context => executeCommand('quiz', context))
