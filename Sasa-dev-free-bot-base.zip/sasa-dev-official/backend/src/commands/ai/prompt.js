import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "prompt",
  "aliases": [],
  "description": "Improve an AI prompt",
  "category": "ai",
  "usage": "<draft prompt>",
  "permission": "public",
  "cooldown": 10
}, context => executeCommand('prompt', context))
