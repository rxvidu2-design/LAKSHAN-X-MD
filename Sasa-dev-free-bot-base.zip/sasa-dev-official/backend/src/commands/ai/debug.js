import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "debug",
  "aliases": [],
  "description": "Analyze and debug code",
  "category": "ai",
  "usage": "<code or error>",
  "permission": "public",
  "cooldown": 10
}, context => executeCommand('debug', context))
