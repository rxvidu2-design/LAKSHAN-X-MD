import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "tts",
  "aliases": [],
  "description": "Convert text to speech",
  "category": "ai",
  "usage": "[language] | <text>",
  "permission": "public",
  "cooldown": 10
}, context => executeCommand('tts', context))
