import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "story",
  "aliases": [],
  "description": "Generate a short story",
  "category": "ai",
  "usage": "<topic>",
  "permission": "public",
  "cooldown": 10
}, context => executeCommand('story', context))
