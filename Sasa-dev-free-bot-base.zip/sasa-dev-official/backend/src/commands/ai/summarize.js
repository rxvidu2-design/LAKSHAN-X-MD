import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "summarize",
  "aliases": [],
  "description": "Summarize supplied text",
  "category": "ai",
  "usage": "<text>",
  "permission": "public",
  "cooldown": 10
}, context => executeCommand('summarize', context))
