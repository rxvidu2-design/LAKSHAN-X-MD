import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "vision",
  "aliases": [],
  "description": "Analyze an image with a vision model",
  "category": "ai",
  "usage": "<question; reply to image>",
  "permission": "public",
  "cooldown": 10
}, context => executeCommand('vision', context))
