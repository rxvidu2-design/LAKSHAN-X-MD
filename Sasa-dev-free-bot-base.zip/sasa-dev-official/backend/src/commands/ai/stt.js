import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "stt",
  "aliases": [],
  "description": "Transcribe replied audio",
  "category": "ai",
  "usage": "<reply to audio>",
  "permission": "public",
  "cooldown": 10
}, context => executeCommand('stt', context))
