import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "gemini",
  "aliases": [],
  "description": "Ask the Gemini provider",
  "category": "ai",
  "usage": "<question>",
  "permission": "public",
  "cooldown": 10
}, context => executeCommand('gemini', context))
