import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "ocr",
  "aliases": [],
  "description": "Extract visible text from an image",
  "category": "ai",
  "usage": "<reply to image>",
  "permission": "public",
  "cooldown": 10
}, context => executeCommand('ocr', context))
