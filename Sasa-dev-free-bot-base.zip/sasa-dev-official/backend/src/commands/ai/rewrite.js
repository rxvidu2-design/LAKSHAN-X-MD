import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "rewrite",
  "aliases": [],
  "description": "Rewrite text in a requested tone",
  "category": "ai",
  "usage": "<tone> | <text>",
  "permission": "public",
  "cooldown": 10
}, context => executeCommand('rewrite', context))
