import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "groq",
  "aliases": [],
  "description": "Ask the Groq-compatible provider",
  "category": "ai",
  "usage": "<question>",
  "permission": "public",
  "cooldown": 10
}, context => executeCommand('groq', context))
