import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "getstatus",
  "aliases": [],
  "description": "Fetch a WhatsApp profile status",
  "category": "whatsapp",
  "usage": "",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('getstatus', context))
