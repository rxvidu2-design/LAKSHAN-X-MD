import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "number",
  "aliases": [],
  "description": "Show the selected WhatsApp number",
  "category": "whatsapp",
  "usage": "",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('number', context))
