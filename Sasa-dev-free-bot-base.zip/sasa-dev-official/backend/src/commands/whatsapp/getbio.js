import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "getbio",
  "aliases": [],
  "description": "Fetch a WhatsApp profile biography",
  "category": "whatsapp",
  "usage": "",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('getbio', context))
