import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "report",
  "aliases": [],
  "description": "Send an issue report to the bot owner log",
  "category": "whatsapp",
  "usage": "<issue description>",
  "permission": "user",
  "cooldown": 3
}, context => executeCommand('report', context))
