import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "profile",
  "aliases": [],
  "description": "Display a WhatsApp profile summary",
  "category": "whatsapp",
  "usage": "",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('profile', context))
