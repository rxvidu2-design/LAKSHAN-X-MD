import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "quoted",
  "aliases": [],
  "description": "Inspect the replied message content",
  "category": "whatsapp",
  "usage": "",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('quoted', context))
