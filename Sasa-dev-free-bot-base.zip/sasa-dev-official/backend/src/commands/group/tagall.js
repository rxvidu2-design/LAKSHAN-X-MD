import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "tagall",
  "aliases": [],
  "description": "Mention every group participant with visible text",
  "category": "group",
  "usage": "",
  "permission": "admin",
  "cooldown": 3
}, context => executeCommand('tagall', context))
