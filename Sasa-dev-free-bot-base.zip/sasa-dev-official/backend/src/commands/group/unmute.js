import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "unmute",
  "aliases": [],
  "description": "Allow all participants to send group messages",
  "category": "group",
  "usage": "",
  "permission": "admin",
  "cooldown": 3
}, context => executeCommand('unmute', context))
