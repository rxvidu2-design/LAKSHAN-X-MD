import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "add",
  "aliases": [],
  "description": "Add phone numbers to the group",
  "category": "group",
  "usage": "<country-code number>",
  "permission": "admin",
  "cooldown": 3
}, context => executeCommand('add', context))
