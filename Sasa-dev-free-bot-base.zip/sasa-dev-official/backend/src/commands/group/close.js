import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "close",
  "aliases": [],
  "description": "Close the group to participant messages",
  "category": "group",
  "usage": "",
  "permission": "admin",
  "cooldown": 3
}, context => executeCommand('close', context))
