import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "groupinfo",
  "aliases": [],
  "description": "Display current group metadata",
  "category": "group",
  "usage": "",
  "permission": "group",
  "cooldown": 3
}, context => executeCommand('groupinfo', context))
