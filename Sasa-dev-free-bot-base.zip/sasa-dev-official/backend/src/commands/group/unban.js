import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "unban",
  "aliases": [],
  "description": "Remove a group command ban",
  "category": "group",
  "usage": "<@user>",
  "permission": "admin",
  "cooldown": 3
}, context => executeCommand('unban', context))
