import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "ban",
  "aliases": [],
  "description": "Ban a participant from bot commands in this group",
  "category": "group",
  "usage": "<@user> [reason]",
  "permission": "admin",
  "cooldown": 3
}, context => executeCommand('ban', context))
