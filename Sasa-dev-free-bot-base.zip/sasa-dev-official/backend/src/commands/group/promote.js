import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "promote",
  "aliases": [],
  "description": "Promote selected participants to admin",
  "category": "group",
  "usage": "<@user>",
  "permission": "admin",
  "cooldown": 3
}, context => executeCommand('promote', context))
