import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "everyone",
  "aliases": [],
  "description": "Mention every group participant",
  "category": "group",
  "usage": "",
  "permission": "admin",
  "cooldown": 3
}, context => executeCommand('everyone', context))
