import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "setdesc",
  "aliases": [],
  "description": "Change the group description",
  "category": "group",
  "usage": "<new description>",
  "permission": "admin",
  "cooldown": 3
}, context => executeCommand('setdesc', context))
