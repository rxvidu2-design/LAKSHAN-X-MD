import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "kick",
  "aliases": [],
  "description": "Remove selected participants from the group",
  "category": "group",
  "usage": "<@user>",
  "permission": "admin",
  "cooldown": 3
}, context => executeCommand('kick', context))
