import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "warnings",
  "aliases": [],
  "description": "Show active warnings for a participant",
  "category": "group",
  "usage": "[@user]",
  "permission": "group",
  "cooldown": 3
}, context => executeCommand('warnings', context))
