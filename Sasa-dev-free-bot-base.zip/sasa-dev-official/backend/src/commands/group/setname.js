import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "setname",
  "aliases": [],
  "description": "Change the group subject",
  "category": "group",
  "usage": "<new name>",
  "permission": "admin",
  "cooldown": 3
}, context => executeCommand('setname', context))
