import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "hidetag",
  "aliases": [],
  "description": "Mention every group participant without a visible list",
  "category": "group",
  "usage": "",
  "permission": "admin",
  "cooldown": 3
}, context => executeCommand('hidetag', context))
