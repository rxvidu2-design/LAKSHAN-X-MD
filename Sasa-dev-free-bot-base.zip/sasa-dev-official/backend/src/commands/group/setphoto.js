import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "setphoto",
  "aliases": [],
  "description": "Change the group profile picture",
  "category": "group",
  "usage": "<reply to image>",
  "permission": "admin",
  "cooldown": 3
}, context => executeCommand('setphoto', context))
