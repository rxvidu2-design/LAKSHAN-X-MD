import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "warn",
  "aliases": [],
  "description": "Issue a group warning to a participant",
  "category": "group",
  "usage": "<@user> [reason]",
  "permission": "admin",
  "cooldown": 3
}, context => executeCommand('warn', context))
