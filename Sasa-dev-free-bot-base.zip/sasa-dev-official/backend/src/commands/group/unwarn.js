import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "unwarn",
  "aliases": [],
  "description": "Remove the latest active warning",
  "category": "group",
  "usage": "<@user>",
  "permission": "admin",
  "cooldown": 3
}, context => executeCommand('unwarn', context))
