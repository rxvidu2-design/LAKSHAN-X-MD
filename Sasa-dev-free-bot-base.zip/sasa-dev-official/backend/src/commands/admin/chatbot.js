import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "chatbot",
  "aliases": [],
  "description": "Enable or disable group AI chat mode",
  "category": "admin",
  "usage": "<on|off>",
  "permission": "admin",
  "cooldown": 3
}, context => executeCommand('chatbot', context))
