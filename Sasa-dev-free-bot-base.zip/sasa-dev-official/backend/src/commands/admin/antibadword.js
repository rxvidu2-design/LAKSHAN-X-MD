import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "antibadword",
  "aliases": [],
  "description": "Enable or disable bad-word filtering",
  "category": "admin",
  "usage": "<on|off>",
  "permission": "admin",
  "cooldown": 3
}, context => executeCommand('antibadword', context))
