import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "antiflood",
  "aliases": [],
  "description": "Enable or disable flood protection",
  "category": "admin",
  "usage": "<on|off>",
  "permission": "admin",
  "cooldown": 3
}, context => executeCommand('antiflood', context))
