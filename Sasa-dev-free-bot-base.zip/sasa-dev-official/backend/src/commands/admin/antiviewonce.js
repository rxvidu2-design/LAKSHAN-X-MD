import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "antiviewonce",
  "aliases": [],
  "description": "Enable or disable view-once protection",
  "category": "admin",
  "usage": "<on|off>",
  "permission": "admin",
  "cooldown": 3
}, context => executeCommand('antiviewonce', context))
