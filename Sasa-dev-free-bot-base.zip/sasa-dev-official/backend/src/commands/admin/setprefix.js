import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "setprefix",
  "aliases": [],
  "description": "Set this group command prefix",
  "category": "admin",
  "usage": "<prefix>",
  "permission": "admin",
  "cooldown": 3
}, context => executeCommand('setprefix', context))
