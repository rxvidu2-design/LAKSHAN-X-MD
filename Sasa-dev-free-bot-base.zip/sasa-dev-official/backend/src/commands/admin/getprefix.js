import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "getprefix",
  "aliases": [],
  "description": "Show this group command prefix",
  "category": "admin",
  "usage": "",
  "permission": "admin",
  "cooldown": 3
}, context => executeCommand('getprefix', context))
