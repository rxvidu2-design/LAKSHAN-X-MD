import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "resetsettings",
  "aliases": [],
  "description": "Reset all group settings to safe defaults",
  "category": "admin",
  "usage": "",
  "permission": "admin",
  "cooldown": 3
}, context => executeCommand('resetsettings', context))
