import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "antispam",
  "aliases": [],
  "description": "Enable or disable spam protection",
  "category": "admin",
  "usage": "<on|off>",
  "permission": "admin",
  "cooldown": 3
}, context => executeCommand('antispam', context))
