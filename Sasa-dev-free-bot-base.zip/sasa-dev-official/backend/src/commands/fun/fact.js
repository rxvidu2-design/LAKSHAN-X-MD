import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "fact",
  "aliases": [],
  "description": "Fetch a random fact",
  "category": "fun",
  "usage": "",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('fact', context))
