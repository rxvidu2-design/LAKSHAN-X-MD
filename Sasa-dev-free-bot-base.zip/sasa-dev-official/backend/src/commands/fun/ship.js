import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "ship",
  "aliases": [],
  "description": "Calculate a deterministic compatibility score",
  "category": "fun",
  "usage": "",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('ship', context))
