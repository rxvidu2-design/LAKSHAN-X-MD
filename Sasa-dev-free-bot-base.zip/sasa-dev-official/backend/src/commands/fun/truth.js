import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "truth",
  "aliases": [],
  "description": "Get a random truth question",
  "category": "fun",
  "usage": "",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('truth', context))
