import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "love",
  "aliases": [],
  "description": "Calculate a deterministic love score",
  "category": "fun",
  "usage": "",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('love', context))
