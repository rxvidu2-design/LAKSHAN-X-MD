import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "rate",
  "aliases": [],
  "description": "Generate a deterministic rating",
  "category": "fun",
  "usage": "<subject>",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('rate', context))
