import { defineCommand } from '../_shared/defineCommand.js'
import { executeCommand } from '../../services/actions/index.js'

export default defineCommand({
  "name": "dare",
  "aliases": [],
  "description": "Get a random safe dare",
  "category": "fun",
  "usage": "",
  "permission": "public",
  "cooldown": 3
}, context => executeCommand('dare', context))
