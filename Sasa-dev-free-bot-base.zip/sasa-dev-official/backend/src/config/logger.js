import pino from 'pino'
import { env } from './env.js'

export const logger = pino({
  level: env.logLevel,
  base: { service: 'sasa-dev-official', environment: env.nodeEnv },
  timestamp: pino.stdTimeFunctions.isoTime,
  redact: {
    paths: [
      'req.headers.authorization',
      'req.headers.cookie',
      'res.headers["set-cookie"]',
      'password',
      'passwordHash',
      '*.password',
      '*.token',
      '*.apiKey',
      '*.credentials',
      '*.auth'
    ],
    censor: '[REDACTED]'
  }
})

export const baileysLogger = logger.child({ component: 'baileys' }, { level: env.logLevel === 'debug' ? 'debug' : 'warn' })
