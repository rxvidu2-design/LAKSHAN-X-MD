import 'dotenv/config'

const text = (name, fallback = '') => process.env[name]?.trim() || fallback
const integer = (name, fallback, min = 0, max = Number.MAX_SAFE_INTEGER) => {
  const value = Number.parseInt(process.env[name] || '', 10)
  return Number.isFinite(value) ? Math.min(max, Math.max(min, value)) : fallback
}
const boolean = (name, fallback = false) => {
  const value = process.env[name]
  if (value === undefined) return fallback
  return ['1', 'true', 'yes', 'on'].includes(value.toLowerCase())
}
const list = (name, fallback = []) => {
  const value = text(name)
  return value ? value.split(',').map(item => item.trim()).filter(Boolean) : fallback
}
const placeholder = value => !value || /^<.*>$/.test(value) || value.includes('<YOUR_')

export const env = Object.freeze({
  port: integer('PORT', 3000, 1, 65535),
  nodeEnv: text('NODE_ENV', 'development'),
  mongodbUri: text('MONGODB_URI'),
  botOwnerName: text('BOT_OWNER_NAME', 'Sasa Dev'),
  botOwnerNumber: text('BOT_OWNER_NUMBER', '94784167385').replace(/\D/g, ''),
  botName: text('BOT_NAME', 'Sasa Dev Official'),
  botPrefix: text('BOT_PREFIX', '.'),
  botLogoUrl: text('BOT_LOGO_URL', 'https://i.ibb.co/4wqFXbTk/191090.jpg'),
  botChannelUrl: text('BOT_CHANNEL_URL', 'https://whatsapp.com/channel/0029Vb69K9665yDEFt3DRR0D'),
  botSupportUrl: text('BOT_SUPPORT_URL', 'https://whatsapp.com/channel/0029Vb69K9665yDEFt3DRR0D'),
  sourceUrl: text('SOURCE_URL'),
  sessionSecret: text('SESSION_SECRET'),
  jwtSecret: text('JWT_SECRET'),
  pairCodeSecret: text('PAIR_CODE_SECRET'),
  sasaApiBaseUrl: text('SASA_API_BASE_URL', 'https://www.sasa-dev-api.xyz').replace(/\/$/, ''),
  sasaApiKey: text('SASA_API_KEY'),
  groqApiKey: text('GROQ_API_KEY'),
  geminiApiKey: text('GEMINI_API_KEY'),
  openaiApiKey: text('OPENAI_API_KEY'),
  removeBgApiKey: text('REMOVE_BG_API_KEY'),
  tenorApiKey: text('TENOR_API_KEY'),
  tmdbApiKey: text('TMDB_API_KEY'),
  youtubeApiKey: text('YOUTUBE_API_KEY'),
  adminUsername: text('ADMIN_USERNAME'),
  adminPassword: text('ADMIN_PASSWORD'),
  adminPasswordHash: text('ADMIN_PASSWORD_HASH'),
  webUrl: text('WEB_URL'),
  apiUrl: text('API_URL'),
  corsOrigins: list('CORS_ORIGIN'),
  logLevel: text('LOG_LEVEL', 'info'),
  logRetentionDays: integer('LOG_RETENTION_DAYS', 30, 1, 365),
  maxSessions: integer('MAX_SESSIONS', 5, 1, 100),
  maxMediaMb: integer('MAX_MEDIA_MB', 25, 1, 100),
  apiTimeoutMs: integer('API_TIMEOUT_MS', 20000, 2000, 120000),
  apiRetryLimit: integer('API_RETRY_LIMIT', 2, 0, 5),
  jwtExpiresIn: text('JWT_EXPIRES_IN', '8h'),
  enableDangerousCommands: boolean('ENABLE_DANGEROUS_COMMANDS'),
  enableBroadcast: boolean('ENABLE_BROADCAST'),
  allowedShellCommands: list('ALLOWED_SHELL_COMMANDS', ['git', 'npm', 'node']),
  screenshotApiUrl: text('SCREENSHOT_API_URL', 'https://image.thum.io/get/width/1280/crop/720/noanimate'),
  isProduction: text('NODE_ENV', 'development') === 'production',
  isConfigured: value => !placeholder(value)
})

export const configurationReport = () => ({
  database: env.isConfigured(env.mongodbUri),
  sessionEncryption: env.isConfigured(env.sessionSecret) && env.sessionSecret.length >= 32 && env.isConfigured(env.pairCodeSecret) && env.pairCodeSecret.length >= 32,
  authentication: env.isConfigured(env.jwtSecret) && env.jwtSecret.length >= 32,
  administrator: env.isConfigured(env.adminUsername) && (env.isConfigured(env.adminPasswordHash) || env.isConfigured(env.adminPassword)),
  sasaApi: env.isConfigured(env.sasaApiKey)
})
