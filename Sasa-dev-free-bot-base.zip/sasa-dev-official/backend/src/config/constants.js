import { env } from './env.js'

export const APP_VERSION = '1.0.0'
export const APP_STARTED_AT = Date.now()
export const BOT_IDENTITY = Object.freeze({
  name: env.botName,
  owner: env.botOwnerName,
  ownerNumber: env.botOwnerNumber,
  prefix: env.botPrefix,
  logoUrl: env.botLogoUrl,
  channelUrl: env.botChannelUrl,
  supportUrl: env.botSupportUrl
})
export const SESSION_STATUSES = Object.freeze([
  'initializing',
  'waiting_qr',
  'waiting_pair',
  'connecting',
  'connected',
  'reconnecting',
  'disconnected',
  'logged_out',
  'failed',
  'stopped'
])
export const ACTIVE_SESSION_STATUSES = Object.freeze(['connecting', 'connected', 'reconnecting', 'disconnected'])
export const PERMISSIONS = Object.freeze(['public', 'user', 'group', 'admin', 'owner', 'sudo'])
