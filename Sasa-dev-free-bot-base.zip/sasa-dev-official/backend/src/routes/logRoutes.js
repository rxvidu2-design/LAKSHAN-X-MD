import { Router } from 'express'
import { z } from 'zod'
import { Log } from '../models/index.js'
import { requireAuth } from '../middleware/auth.js'
import { requireDatabase } from '../middleware/database.js'
import { validate } from '../middleware/validate.js'
import { asyncHandler } from '../utils/asyncHandler.js'
import { success } from '../utils/response.js'

const querySchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(30),
  level: z.enum(['info', 'warn', 'error', 'audit']).optional(),
  status: z.string().trim().max(40).optional(),
  command: z.string().trim().max(40).optional(),
  sessionId: z.string().uuid().optional()
})

export const logRoutes = Router()
logRoutes.get('/logs', requireDatabase, requireAuth, validate({ query: querySchema }), asyncHandler(async (req, res) => {
  const { page, limit, ...filters } = req.query
  const query = Object.fromEntries(Object.entries(filters).filter(([, value]) => value !== undefined && value !== ''))
  const [items, total] = await Promise.all([
    Log.find(query).sort({ timestamp: -1 }).skip((page - 1) * limit).limit(limit).lean(),
    Log.countDocuments(query)
  ])
  return success(res, items, 'Logs loaded', 200, { page, limit, total, pages: Math.ceil(total / limit) })
}))
