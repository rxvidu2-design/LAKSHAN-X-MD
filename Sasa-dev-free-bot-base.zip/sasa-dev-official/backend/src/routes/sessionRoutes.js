import { Router } from 'express'
import { z } from 'zod'
import { requireAuth, requireRole } from '../middleware/auth.js'
import { requireDatabase } from '../middleware/database.js'
import { pairingLimiter } from '../middleware/rateLimits.js'
import { validate } from '../middleware/validate.js'
import { asyncHandler } from '../utils/asyncHandler.js'
import { success } from '../utils/response.js'
import { Session } from '../models/index.js'
import { AppError } from '../utils/AppError.js'

const idSchema = z.object({ id: z.string().uuid() })
const label = z.string().trim().min(1).max(80).optional()
const qrSchema = z.object({ label, ownerNumber: z.string().trim().max(30).optional() }).strict()
const pairSchema = z.object({ label, phoneNumber: z.string().trim().min(8).max(30) }).strict()
const createSchema = z.discriminatedUnion('method', [
  z.object({ method: z.literal('qr'), label, ownerNumber: z.string().trim().max(30).optional() }).strict(),
  z.object({ method: z.literal('pair'), label, phoneNumber: z.string().trim().min(8).max(30) }).strict()
])

export const createSessionRoutes = sessionManager => {
  const router = Router()
  const secure = [requireDatabase, requireAuth, requireRole('admin', 'operator')]
  const ensureAccess = asyncHandler(async (req, res, next) => {
    if (req.user.role === 'admin') return next()
    const allowed = await Session.exists({ sessionId: req.params.id, userId: req.user._id })
    if (!allowed) throw new AppError('Session not found', 404, 'SESSION_NOT_FOUND')
    next()
  })

  const startQr = asyncHandler(async (req, res) => {
    const session = await sessionManager.startQr({ ...req.body, userId: req.user._id })
    return success(res, session, 'QR session created', 201)
  })
  const startPair = asyncHandler(async (req, res) => {
    const result = await sessionManager.startPair({ ...req.body, userId: req.user._id })
    return success(res, { ...result.session, pairCode: result.pairCode }, 'Pairing code generated', 201)
  })

  router.get('/sessions', ...secure, asyncHandler(async (req, res) => success(res, await sessionManager.listSessions(req.user.role === 'admin' ? null : req.user._id))))
  router.post('/session/create', ...secure, pairingLimiter, validate({ body: createSchema }), asyncHandler(async (req, res) => {
    if (req.body.method === 'qr') {
      const session = await sessionManager.startQr({ ...req.body, userId: req.user._id })
      return success(res, session, 'QR session created', 201)
    }
    const result = await sessionManager.startPair({ ...req.body, userId: req.user._id })
    return success(res, { ...result.session, pairCode: result.pairCode }, 'Pairing code generated', 201)
  }))
  router.post(['/session/qr', '/sessions/qr'], ...secure, pairingLimiter, validate({ body: qrSchema }), startQr)
  router.post(['/session/pair', '/sessions/pair'], ...secure, pairingLimiter, validate({ body: pairSchema }), startPair)
  router.get(['/session/:id', '/sessions/:id'], ...secure, validate({ params: idSchema }), ensureAccess, asyncHandler(async (req, res) => success(res, await sessionManager.getSession(req.params.id))))
  router.post(['/session/:id/reconnect', '/sessions/:id/reconnect'], ...secure, pairingLimiter, validate({ params: idSchema }), ensureAccess, asyncHandler(async (req, res) => success(res, await sessionManager.reconnectSession(req.params.id), 'Reconnect started')))
  router.post(['/session/:id/refresh-qr', '/sessions/:id/refresh-qr'], ...secure, pairingLimiter, validate({ params: idSchema }), ensureAccess, asyncHandler(async (req, res) => success(res, await sessionManager.refreshQr(req.params.id), 'QR refresh started')))
  router.post(['/session/:id/stop', '/sessions/:id/stop'], ...secure, validate({ params: idSchema }), ensureAccess, asyncHandler(async (req, res) => success(res, await sessionManager.stopSession(req.params.id), 'Session stopped')))
  router.delete(['/session/:id', '/sessions/:id'], ...secure, validate({ params: idSchema }), ensureAccess, asyncHandler(async (req, res) => {
    await sessionManager.deleteSession(req.params.id)
    return success(res, null, 'Session deleted')
  }))
  return router
}
