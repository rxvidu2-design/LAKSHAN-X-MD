import { Router } from 'express'
import { z } from 'zod'
import { authenticateAdministrator, createAccessToken } from '../services/adminService.js'
import { asyncHandler } from '../utils/asyncHandler.js'
import { success } from '../utils/response.js'
import { validate } from '../middleware/validate.js'
import { authLimiter } from '../middleware/rateLimits.js'
import { requireDatabase } from '../middleware/database.js'
import { requireAuth } from '../middleware/auth.js'
import { env } from '../config/env.js'

export const authRoutes = Router()

const loginSchema = z.object({ username: z.string().trim().min(3).max(64), password: z.string().min(8).max(200) }).strict()

authRoutes.post('/login', authLimiter, requireDatabase, validate({ body: loginSchema }), asyncHandler(async (req, res) => {
  const user = await authenticateAdministrator(req.body.username, req.body.password, req.ip)
  const token = createAccessToken(user)
  res.cookie('sasa_access', token, {
    httpOnly: true,
    secure: env.isProduction,
    sameSite: 'lax',
    path: '/',
    maxAge: 8 * 60 * 60 * 1000
  })
  return success(res, { id: user.id, username: user.username, displayName: user.displayName, role: user.role }, 'Signed in successfully')
}))

authRoutes.post('/logout', (req, res) => {
  res.clearCookie('sasa_access', { httpOnly: true, secure: env.isProduction, sameSite: 'lax', path: '/' })
  return success(res, null, 'Signed out successfully')
})

authRoutes.get('/me', requireDatabase, requireAuth, (req, res) => success(res, {
  id: req.user._id,
  username: req.user.username,
  displayName: req.user.displayName,
  role: req.user.role,
  lastLoginAt: req.user.lastLoginAt
}))
