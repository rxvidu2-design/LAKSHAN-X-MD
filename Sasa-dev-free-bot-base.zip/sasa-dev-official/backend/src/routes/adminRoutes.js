import { Router } from 'express'
import { z } from 'zod'
import { Bot, Group, Session, User } from '../models/index.js'
import { requireAuth, requireRole } from '../middleware/auth.js'
import { requireDatabase } from '../middleware/database.js'
import { validate } from '../middleware/validate.js'
import { asyncHandler } from '../utils/asyncHandler.js'
import { success } from '../utils/response.js'
import { AppError } from '../utils/AppError.js'
import { databaseState } from '../database/connection.js'
import { configurationReport } from '../config/env.js'
import { sasaApi } from '../services/sasaApi.js'

const querySchema = z.object({ page: z.coerce.number().int().min(1).default(1), limit: z.coerce.number().int().min(1).max(100).default(30) })
const idSchema = z.object({ id: z.string().regex(/^[a-f0-9]{24}$/i) })
const userUpdateSchema = z.object({ active: z.boolean().optional(), role: z.enum(['admin', 'operator', 'viewer']).optional() }).strict().refine(value => Object.keys(value).length > 0)
const activeUpdateSchema = z.object({ active: z.boolean() }).strict()
const botUpdateSchema = z.object({ enabled: z.boolean() }).strict()
const paginate = async (Model, query, filter = {}, select = '') => {
  const { page, limit } = query
  const [items, total] = await Promise.all([
    Model.find(filter).select(select).sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit).lean(),
    Model.countDocuments(filter)
  ])
  return { items, meta: { page, limit, total, pages: Math.ceil(total / limit) } }
}

export const createAdminRoutes = sessionManager => {
const adminRoutes = Router()
adminRoutes.get('/admin/users', requireDatabase, requireAuth, requireRole('admin'), validate({ query: querySchema }), asyncHandler(async (req, res) => {
  const result = await paginate(User, req.query, {}, '-passwordHash')
  return success(res, result.items, 'Users loaded', 200, result.meta)
}))
adminRoutes.get('/admin/groups', requireDatabase, requireAuth, requireRole('admin'), validate({ query: querySchema }), asyncHandler(async (req, res) => {
  const result = await paginate(Group, req.query, {})
  return success(res, result.items, 'Groups loaded', 200, result.meta)
}))
adminRoutes.get('/admin/bots', requireDatabase, requireAuth, requireRole('admin'), validate({ query: querySchema }), asyncHandler(async (req, res) => {
  const result = await paginate(Bot, req.query, {})
  return success(res, result.items, 'Bots loaded', 200, result.meta)
}))
adminRoutes.patch('/admin/users/:id', requireDatabase, requireAuth, requireRole('admin'), validate({ params: idSchema, body: userUpdateSchema }), asyncHandler(async (req, res) => {
  if (String(req.user._id) === req.params.id && (req.body.active === false || (req.body.role && req.body.role !== 'admin'))) {
    throw new AppError('You cannot deactivate or demote your current administrator account', 409, 'SELF_LOCKOUT_BLOCKED')
  }
  const user = await User.findByIdAndUpdate(req.params.id, { $set: req.body }, { new: true, runValidators: true }).select('-passwordHash').lean()
  if (!user) throw new AppError('User not found', 404, 'USER_NOT_FOUND')
  return success(res, user, 'User updated')
}))
adminRoutes.patch('/admin/bots/:id', requireDatabase, requireAuth, requireRole('admin'), validate({ params: idSchema, body: botUpdateSchema }), asyncHandler(async (req, res) => {
  const existing = await Bot.findById(req.params.id).lean()
  if (!existing) throw new AppError('Bot not found', 404, 'BOT_NOT_FOUND')
  if (req.body.enabled) await sessionManager.reconnectSession(existing.sessionId)
  else await sessionManager.stopSession(existing.sessionId)
  const bot = await Bot.findByIdAndUpdate(req.params.id, { $set: req.body }, { new: true, runValidators: true }).lean()
  return success(res, bot, 'Bot updated')
}))
adminRoutes.patch('/admin/groups/:id', requireDatabase, requireAuth, requireRole('admin'), validate({ params: idSchema, body: activeUpdateSchema }), asyncHandler(async (req, res) => {
  const group = await Group.findByIdAndUpdate(req.params.id, { $set: req.body }, { new: true, runValidators: true }).lean()
  if (!group) throw new AppError('Group not found', 404, 'GROUP_NOT_FOUND')
  return success(res, group, 'Group updated')
}))
adminRoutes.get('/admin/overview', requireDatabase, requireAuth, requireRole('admin'), asyncHandler(async (req, res) => {
  const [users, sessions, bots, groups] = await Promise.all([User.countDocuments(), Session.countDocuments({ active: true }), Bot.countDocuments(), Group.countDocuments({ active: true })])
  return success(res, { counts: { users, sessions, bots, groups }, database: databaseState(), configuration: configurationReport() })
}))
adminRoutes.get('/admin/api-status', requireDatabase, requireAuth, requireRole('admin'), asyncHandler(async (req, res) => success(res, await sasaApi.health())))
return adminRoutes
}
