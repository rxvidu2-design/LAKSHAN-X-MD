import { Router } from 'express'
import { z } from 'zod'
import { Setting } from '../models/index.js'
import { requireAuth, requireRole } from '../middleware/auth.js'
import { requireDatabase } from '../middleware/database.js'
import { validate } from '../middleware/validate.js'
import { asyncHandler } from '../utils/asyncHandler.js'
import { success } from '../utils/response.js'
import { AppError } from '../utils/AppError.js'

const allowed = new Set(['dashboardTitle', 'maintenanceMode', 'defaultPrefix', 'supportMessage', 'sudoNumbers'])
const updateSchema = z.object({ key: z.string().trim().min(1).max(60), value: z.union([z.string().max(2000), z.boolean(), z.number(), z.array(z.string().max(100)).max(100), z.null()]) }).strict()

export const settingRoutes = Router()
settingRoutes.get('/settings', requireDatabase, requireAuth, requireRole('admin'), asyncHandler(async (req, res) => {
  const settings = await Setting.find({ scope: 'global', scopeId: 'global', key: { $in: [...allowed] } }).select('key value updatedAt').lean()
  return success(res, Object.fromEntries(settings.map(setting => [setting.key, setting.value])))
}))
settingRoutes.put('/settings', requireDatabase, requireAuth, requireRole('admin'), validate({ body: updateSchema }), asyncHandler(async (req, res) => {
  if (!allowed.has(req.body.key)) throw new AppError('This setting cannot be changed through the dashboard', 403, 'SETTING_NOT_ALLOWED')
  const document = await Setting.findOneAndUpdate(
    { scope: 'global', scopeId: 'global', key: req.body.key },
    { $set: { value: req.body.value, updatedBy: req.user._id } },
    { upsert: true, new: true }
  ).select('key value updatedAt').lean()
  return success(res, document, 'Setting updated')
}))
