import { Router } from 'express'
import { databaseState, isDatabaseReady } from '../database/connection.js'
import { APP_STARTED_AT, APP_VERSION, BOT_IDENTITY } from '../config/constants.js'
import { configurationReport } from '../config/env.js'
import { Session } from '../models/index.js'
import { asyncHandler } from '../utils/asyncHandler.js'
import { success } from '../utils/response.js'

export const systemRoutes = Router()

systemRoutes.get('/health', asyncHandler(async (req, res) => {
  const database = databaseState()
  const status = isDatabaseReady() ? 'healthy' : 'degraded'
  return success(res, {
    status,
    version: APP_VERSION,
    uptime: Math.floor((Date.now() - APP_STARTED_AT) / 1000),
    timestamp: new Date().toISOString(),
    database: { status: database.status, readyState: database.readyState },
    configuration: configurationReport()
  }, status === 'healthy' ? 'Service is healthy' : 'Service is running in degraded mode')
}))

systemRoutes.get('/status', asyncHandler(async (req, res) => {
  let sessions = { total: 0, connected: 0 }
  if (isDatabaseReady()) {
    const [total, connected] = await Promise.all([
      Session.countDocuments({ active: true }),
      Session.countDocuments({ active: true, status: 'connected' })
    ])
    sessions = { total, connected }
  }
  return success(res, {
    bot: BOT_IDENTITY,
    version: APP_VERSION,
    uptime: Math.floor((Date.now() - APP_STARTED_AT) / 1000),
    database: databaseState().status,
    sessions
  })
}))
