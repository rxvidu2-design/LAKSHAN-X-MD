import { Router } from 'express'
import { Bot, Command, Group, Log, Session, UserData } from '../models/index.js'
import { requireAuth } from '../middleware/auth.js'
import { requireDatabase } from '../middleware/database.js'
import { asyncHandler } from '../utils/asyncHandler.js'
import { success } from '../utils/response.js'

export const statsRoutes = Router()
statsRoutes.get('/stats', requireDatabase, requireAuth, asyncHandler(async (req, res) => {
  const since = new Date(Date.now() - 24 * 60 * 60 * 1000)
  const [sessions, connected, groups, users, logs24h, errors24h, recentLogs, topCommands, commandTotals] = await Promise.all([
    Session.countDocuments({ active: true }),
    Session.countDocuments({ active: true, status: 'connected' }),
    Group.countDocuments({ active: true }),
    UserData.countDocuments(),
    Log.countDocuments({ timestamp: { $gte: since } }),
    Log.countDocuments({ timestamp: { $gte: since }, level: 'error' }),
    Log.find().sort({ timestamp: -1 }).limit(8).lean(),
    Command.find({ executions: { $gt: 0 } }).sort({ executions: -1 }).limit(8).select('name category executions successes failures averageResponseTime').lean(),
    Command.aggregate([{ $group: { _id: null, executions: { $sum: '$executions' }, successes: { $sum: '$successes' }, failures: { $sum: '$failures' } } }])
  ])
  return success(res, {
    overview: { sessions, connected, groups, users, logs24h, errors24h, commands: commandTotals[0] || { executions: 0, successes: 0, failures: 0 } },
    recentLogs,
    topCommands
  })
}))
