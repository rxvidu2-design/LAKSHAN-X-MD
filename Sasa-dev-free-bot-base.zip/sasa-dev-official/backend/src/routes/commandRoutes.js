import { Router } from 'express'
import { z } from 'zod'
import { Command } from '../models/index.js'
import { requireAuth, requireRole } from '../middleware/auth.js'
import { requireDatabase } from '../middleware/database.js'
import { validate } from '../middleware/validate.js'
import { asyncHandler } from '../utils/asyncHandler.js'
import { success } from '../utils/response.js'

const paramsSchema = z.object({ name: z.string().regex(/^[a-z0-9_-]{1,40}$/) })
const updateSchema = z.object({ enabled: z.boolean().optional(), cooldown: z.number().int().min(0).max(3600).optional() }).strict().refine(value => Object.keys(value).length > 0)

export const createCommandRoutes = registry => {
  const router = Router()
  router.get('/commands', (req, res) => success(res, registry.publicList(), 'Commands loaded', 200, { total: registry.size }))
  router.patch('/commands/:name', requireDatabase, requireAuth, requireRole('admin'), validate({ params: paramsSchema, body: updateSchema }), asyncHandler(async (req, res) => {
    const command = registry.get(req.params.name)
    if (!command) return res.status(404).json({ success: false, message: 'Command not found', error: 'COMMAND_NOT_FOUND' })
    const document = await Command.findOneAndUpdate({ name: command.name }, { $set: req.body }, { new: true }).lean()
    if (req.body.enabled !== undefined) registry.setEnabled(command.name, req.body.enabled)
    return success(res, document, 'Command updated')
  }))
  return router
}
