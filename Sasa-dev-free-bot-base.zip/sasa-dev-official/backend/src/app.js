import path from 'node:path'
import { existsSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import express, { Router } from 'express'
import compression from 'compression'
import cookieParser from 'cookie-parser'
import cors from 'cors'
import helmet from 'helmet'
import pinoHttp from 'pino-http'
import { env } from './config/env.js'
import { apiLimiter } from './middleware/rateLimits.js'
import { errorHandler, notFound } from './middleware/errorHandler.js'
import { noCache, requestContext, sanitizeRequest, verifyOrigin } from './middleware/security.js'
import { authRoutes } from './routes/authRoutes.js'
import { systemRoutes } from './routes/systemRoutes.js'
import { createSessionRoutes } from './routes/sessionRoutes.js'
import { createCommandRoutes } from './routes/commandRoutes.js'
import { logRoutes } from './routes/logRoutes.js'
import { statsRoutes } from './routes/statsRoutes.js'
import { settingRoutes } from './routes/settingRoutes.js'
import { createAdminRoutes } from './routes/adminRoutes.js'

const currentDirectory = path.dirname(fileURLToPath(import.meta.url))
const frontendDirectory = path.resolve(currentDirectory, '..', '..', 'frontend', 'dist')

const corsOptions = {
  credentials: true,
  origin(origin, callback) {
    if (!origin) return callback(null, true)
    const allowed = new Set([...env.corsOrigins, env.webUrl, env.apiUrl].filter(value => env.isConfigured(value)))
    if (!env.isProduction || allowed.has(origin)) return callback(null, true)
    return callback(null, false)
  }
}

export const createApplication = ({ registry, sessionManager }) => {
  const app = express()
  app.set('trust proxy', 1)
  app.disable('x-powered-by')
  app.use(requestContext)
  app.use(pinoHttp({
    level: env.logLevel,
    customProps: req => ({ requestId: req.id, service: 'sasa-dev-official' }),
    redact: {
      paths: ['req.headers.authorization', 'req.headers.cookie', 'res.headers["set-cookie"]'],
      censor: '[REDACTED]'
    }
  }))
  app.use(helmet({
    crossOriginResourcePolicy: { policy: 'same-origin' },
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", 'data:', 'blob:'],
        connectSrc: ["'self'", 'ws:', 'wss:'],
        fontSrc: ["'self'", 'data:'],
        objectSrc: ["'none'"],
        frameAncestors: ["'none'"]
      }
    }
  }))
  app.use(cors(corsOptions))
  app.use(compression())
  app.use(cookieParser())
  app.use(verifyOrigin)
  app.use(express.json({ limit: '256kb' }))
  app.use(express.urlencoded({ extended: false, limit: '64kb' }))
  app.use(sanitizeRequest)

  const api = Router()
  api.use(systemRoutes)
  api.use(noCache)
  api.use(apiLimiter)
  api.use('/auth', authRoutes)
  api.use(createSessionRoutes(sessionManager))
  api.use(createCommandRoutes(registry))
  api.use(logRoutes)
  api.use(statsRoutes)
  api.use(settingRoutes)
  api.use(createAdminRoutes(sessionManager))
  api.use(notFound)
  app.use('/api', api)

  if (existsSync(frontendDirectory)) {
    app.use(express.static(frontendDirectory, { index: false, maxAge: env.isProduction ? '1d' : 0, immutable: false }))
    app.get('/{*splat}', (req, res, next) => {
      if (req.path.startsWith('/api') || req.path.startsWith('/socket.io')) return next()
      return res.sendFile(path.join(frontendDirectory, 'index.html'))
    })
  } else {
    app.get('/', (req, res) => res.json({ success: true, message: 'Sasa Dev Official API', data: { documentation: '/api/health' } }))
  }

  app.use(notFound)
  app.use(errorHandler)
  return app
}
